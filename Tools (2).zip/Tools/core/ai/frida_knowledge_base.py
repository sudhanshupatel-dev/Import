"""
Frida Script Knowledge Base - Curated patterns for mobile security testing.

Each entry contains:
- category: Protection type
- subcategory: Specific technique
- platform: Android/iOS/Both
- description: What the bypass targets
- trigger_patterns: Scan findings that indicate this protection
- frida_script: Complete Frida script for this bypass
- references: OWASP MASTG test IDs
"""

KNOWLEDGE_BASE = [
    # ═══════════════════════════════════════════════════════════════
    # ROOT DETECTION BYPASS (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_root_file_check",
        "category": "root_detection",
        "subcategory": "filesystem_check",
        "platform": "android",
        "description": "Bypass root detection that checks for su binary, SuperSU, Magisk files",
        "trigger_patterns": ["/system/bin/su", "/system/xbin/su", "Superuser.apk", "Magisk", "BusyBox", "/su/bin", "RootBeer", "root detection"],
        "references": ["MSTG-RESILIENCE-1"],
        "frida_script": r"""
// Root Detection Bypass - Filesystem Checks
// Blocks detection of su binary, SuperSU, Magisk, and other root indicators

var rootPaths = [
    "/system/bin/su", "/system/xbin/su", "/sbin/su",
    "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
    "/system/bin/failsafe/su", "/data/local/su",
    "/su/bin/su", "/su/bin",
    "/system/app/Superuser.apk", "/system/app/SuperSU.apk",
    "/system/app/SuperSU", "/system/app/Superuser",
    "/data/data/com.topjohnwu.magisk",
    "/data/data/com.koushikdutta.superuser",
    "/data/data/com.thirdparty.superuser",
    "/data/data/eu.chainfire.supersu",
    "/system/etc/.rooted", "/system/etc/.su",
    "/system/vendor/bin/su",
    "/system/app/SuperSU.apk", "/system/app/RootBeer",
    "/data/adb/magisk"
];

function bypassFileCheck() {
    var File = Java.use("java.io.File");

    File.exists.implementation = function() {
        var path = this.getAbsolutePath();
        for (var i = 0; i < rootPaths.length; i++) {
            if (path.indexOf(rootPaths[i]) !== -1) {
                console.log("[ROOT-BYPASS] Blocked file check: " + path);
                return false;
            }
        }
        return this.exists();
    };

    File.canRead.implementation = function() {
        var path = this.getAbsolutePath();
        for (var i = 0; i < rootPaths.length; i++) {
            if (path.indexOf(rootPaths[i]) !== -1) {
                return false;
            }
        }
        return this.canRead();
    };

    File.canWrite.implementation = function() {
        var path = this.getAbsolutePath();
        for (var i = 0; i < rootPaths.length; i++) {
            if (path.indexOf(rootPaths[i]) !== -1) {
                return false;
            }
        }
        return this.canWrite();
    };
}

function bypassProcessCheck() {
    var Runtime = Java.use("java.lang.Runtime");
    Runtime.exec.overload("[Ljava.lang.String;").implementation = function(commands) {
        var cmd = commands.join(" ");
        if (cmd.indexOf("su") !== -1 || cmd.indexOf("which") !== -1) {
            console.log("[ROOT-BYPASS] Blocked exec: " + cmd);
            throw Java.use("java.io.IOException").$new("Cannot run program");
        }
        return this.exec(commands);
    };

    Runtime.exec.overload("java.lang.String").implementation = function(command) {
        if (command.indexOf("su") !== -1 || command.indexOf("which") !== -1) {
            console.log("[ROOT-BYPASS] Blocked exec: " + command);
            throw Java.use("java.io.IOException").$new("Cannot run program");
        }
        return this.exec(command);
    };
}

Java.perform(function() {
    bypassFileCheck();
    bypassProcessCheck();
    console.log("[ROOT-BYPASS] Filesystem & process checks patched");
});
""",
    },
    {
        "id": "android_root_native_check",
        "category": "root_detection",
        "subcategory": "native_library",
        "platform": "android",
        "description": "Bypass root detection via native JNI calls (fopen, access, stat)",
        "trigger_patterns": ["native", "JNI", "fopen", "access(", "stat("],
        "references": ["MSTG-RESILIENCE-1"],
        "frida_script": r"""
// Root Detection Bypass - Native Library Checks
Interceptor.attach(Module.findExportByName("libc.so", "fopen"), {
    onEnter: function(args) {
        this.path = args[0].readUtf8String();
    },
    onLeave: function(retval) {
        if (this.path) {
            var blocked = ["/su", "/system/bin/su", "/system/xbin/su",
                           "/sbin/su", "Superuser.apk", "Magisk"];
            for (var i = 0; i < blocked.length; i++) {
                if (this.path.indexOf(blocked[i]) !== -1) {
                    console.log("[ROOT-BYPASS] Blocked fopen: " + this.path);
                    retval.replace(ptr(0));
                    return;
                }
            }
        }
    }
});

Interceptor.attach(Module.findExportByName("libc.so", "access"), {
    onEnter: function(args) {
        this.path = args[0].readUtf8String();
    },
    onLeave: function(retval) {
        if (this.path) {
            var blocked = ["/su", "/system/bin/su", "/system/xbin/su",
                           "/sbin/su", "Superuser.apk", "Magisk"];
            for (var i = 0; i < blocked.length; i++) {
                if (this.path.indexOf(blocked[i]) !== -1) {
                    console.log("[ROOT-BYPASS] Blocked access: " + this.path);
                    retval.replace(ptr(-1));
                    return;
                }
            }
        }
    }
});

Interceptor.attach(Module.findExportByName("libc.so", "stat"), {
    onEnter: function(args) {
        this.path = args[0].readUtf8String();
    },
    onLeave: function(retval) {
        if (this.path) {
            var blocked = ["/su", "/system/bin/su", "/system/xbin/su"];
            for (var i = 0; i < blocked.length; i++) {
                if (this.path.indexOf(blocked[i]) !== -1) {
                    console.log("[ROOT-BYPASS] Blocked stat: " + this.path);
                    retval.replace(ptr(-1));
                    return;
                }
            }
        }
    }
});

console.log("[ROOT-BYPASS] Native libc hooks installed (fopen, access, stat)");
""",
    },
    {
        "id": "android_root_build_check",
        "category": "root_detection",
        "subcategory": "build_properties",
        "platform": "android",
        "description": "Bypass root detection that checks build props (ro.build.tags, ro.debuggable)",
        "trigger_patterns": ["ro.build.tags", "ro.debuggable", "ro.secure", "Build.TAGS", "test-keys"],
        "references": ["MSTG-RESILIENCE-1"],
        "frida_script": r"""
// Root Detection Bypass - Build Property Checks
Java.perform(function() {
    var SystemProperties = Java.use("android.os.SystemProperties");

    SystemProperties.get.overload("java.lang.String").implementation = function(key) {
        var spoofed = {
            "ro.build.tags": "release-keys",
            "ro.debuggable": "0",
            "ro.secure": "1",
            "ro.build.type": "user",
            "ro.build.display.id": "user release-keys",
            "ro.product.model": "SM-G991B",
            "ro.build.version.sdk": "31"
        };
        if (key in spoofed) {
            console.log("[ROOT-BYPASS] Spoofed " + key + " = " + spoofed[key]);
            return spoofed[key];
        }
        return this.get(key);
    };

    var Build = Java.use("android.os.Build");
    Build.TAGS.value = "release-keys";
    Build.TYPE.value = "user";

    console.log("[ROOT-BYPASS] Build properties spoofed");
});
""",
    },
    {
        "id": "android_root_magisk_hide",
        "category": "root_detection",
        "subcategory": "magisk_detection",
        "platform": "android",
        "description": "Bypass Magisk-specific detection (zygisk, modules, denylist)",
        "trigger_patterns": ["magisk", "zygisk", "denylist", "magisk.db", "magiskinit"],
        "references": ["MSTG-RESILIENCE-1"],
        "frida_script": r"""
// Magisk Detection Bypass
Java.perform(function() {
    var File = Java.use("java.io.File");
    var magiskPaths = [
        "/data/adb/magisk", "/data/adb/magisk.img",
        "/data/adb/modules", "/data/adb/modules.zip",
        "/data/adb/services.d", "/data/adb/post-fs-data.d",
        "/sbin/.magisk", "/cache/.disable_magisk"
    ];

    File.exists.implementation = function() {
        var path = this.getAbsolutePath();
        for (var i = 0; i < magiskPaths.length; i++) {
            if (path.indexOf(magiskPaths[i]) !== -1) return false;
        }
        return this.exists();
    };

    var PackageManager = Java.use("android.app.ApplicationPackageManager");
    PackageManager.getPackageInfo.overload("java.lang.String", "int").implementation = function(pkg, flags) {
        if (pkg === "com.topjohnwu.magisk") {
            throw Java.use("android.content.pm.PackageManager$NameNotFoundException").$new("Package not found");
        }
        return this.getPackageInfo(pkg, flags);
    };

    console.log("[ROOT-BYPASS] Magisk detection bypassed");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # SSL PINNING BYPASS (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_ssl_pinning_java",
        "category": "ssl_pinning",
        "subcategory": "java_trust_manager",
        "platform": "android",
        "description": "Bypass SSL pinning in Java TrustManager implementations",
        "trigger_patterns": ["TrustManager", "checkServerTrusted", "X509TrustManager", "SSLContext", "checkClientTrusted", "certificate pinning"],
        "references": ["MSTG-NETWORK-1"],
        "frida_script": r"""
// SSL Pinning Bypass - Java TrustManager
Java.perform(function() {
    var TrustManagerImpl = Java.use("com.android.org.conscrypt.TrustManagerImpl");
    if (TrustManagerImpl) {
        TrustManagerImpl.verifyChain.implementation = function(untrustedChain, trustAnchorChain, host, clientAuth, ocspData, tlsSctData) {
            console.log("[SSL-BYPASS] TrustManagerImpl.verifyChain bypassed for: " + host);
            return untrustedChain;
        };
    }

    var X509TrustManager = Java.use("javax.net.ssl.X509TrustManager");
    var SSLContext = Java.use("javax.net.ssl.SSLContext");

    var TrustManager = Java.registerClass({
        name: "com.mobiscan.TrustManager",
        implements: [X509TrustManager],
        methods: {
            checkClientTrusted: function(chain, authType) {},
            checkServerTrusted: function(chain, authType) {},
            getAcceptedIssuers: function() { return []; }
        }
    });

    var TrustManagers = [TrustManager.$new()];
    var SSLContextInit = SSLContext.init.overload(
        "[Ljavax.net.ssl.KeyManager;",
        "[Ljavax.net.ssl.TrustManager;",
        "java.security.SecureRandom"
    );
    SSLContextInit.implementation = function(keyManagers, trustManagers, secureRandom) {
        console.log("[SSL-BYPASS] SSLContext.init intercepted - using permissive TrustManager");
        SSLContextInit.call(this, keyManagers, TrustManagers, secureRandom);
    };

    // Bypass OkHttp CertificatePinner
    try {
        var CertificatePinner = Java.use("okhttp3.CertificatePinner");
        CertificatePinner.check.overload("java.lang.String", "java.util.List").implementation = function(hostname, peerCertificates) {
            console.log("[SSL-BYPASS] OkHttp3 CertificatePinner.check bypassed for: " + hostname);
        };
    } catch(e) {}

    try {
        var CertificatePinner2 = Java.use("okhttp3.CertificatePinner");
        CertificatePinner2["check$default"].implementation = function(hostname, peerCertificates, function0, int, Object) {
            console.log("[SSL-BYPASS] OkHttp3 CertificatePinner.check$default bypassed");
        };
    } catch(e) {}

    console.log("[SSL-BYPASS] Java SSL pinning hooks installed");
});
""",
    },
    {
        "id": "android_ssl_pinning_network_security",
        "category": "ssl_pinning",
        "subcategory": "network_security_config",
        "platform": "android",
        "description": "Bypass Network Security Configuration pinning",
        "trigger_patterns": ["network-security-config", "NetworkSecurityConfig", "pin-set", "pin-sha256"],
        "references": ["MSTG-NETWORK-1"],
        "frida_script": r"""
// SSL Pinning Bypass - Network Security Configuration
Java.perform(function() {
    var HostnameVerifier = Java.use("javax.net.ssl.HostnameVerifier");

    var FakeHostnameVerifier = Java.registerClass({
        name: "com.mobiscan.FakeHostnameVerifier",
        implements: [HostnameVerifier],
        methods: {
            verify: function(hostname, session) {
                console.log("[SSL-BYPASS] HostnameVerifier.verify bypassed: " + hostname);
                return true;
            }
        }
    });

    var HttpsURLConnection = Java.use("javax.net.ssl.HttpsURLConnection");
    HttpsURLConnection.setDefaultHostnameVerifier.implementation = function(verifier) {
        console.log("[SSL-BYPASS] Replaced default HostnameVerifier");
        HttpsURLConnection.setDefaultHostnameVerifier.call(this, FakeHostnameVerifier.$new());
    };

    HttpsURLConnection.setHostnameVerifier.implementation = function(verifier) {
        this.setHostnameVerifier(FakeHostnameVerifier.$new());
    };

    console.log("[SSL-BYPASS] Network Security Config bypass hooks installed");
});
""",
    },
    {
        "id": "android_ssl_pinning_webview",
        "category": "ssl_pinning",
        "subcategory": "webview_ssl",
        "platform": "android",
        "description": "Bypass WebView SSL error handling to intercept HTTPS in WebViews",
        "trigger_patterns": ["WebView", "onReceivedSslError", "SslError", "webViewClient", "loadUrl"],
        "references": ["MSTG-NETWORK-1"],
        "frida_script": r"""
// SSL Pinning Bypass - WebView SSL Error Handling
Java.perform(function() {
    var WebViewClient = Java.use("android.webkit.WebViewClient");

    WebViewClient.onReceivedSslError.implementation = function(view, handler, error) {
        console.log("[SSL-BYPASS] WebView SSL error ignored for: " + view.getUrl());
        handler.proceed();
    };

    WebViewClient.shouldOverrideUrlLoading.overload("android.webkit.WebView", "java.lang.String").implementation = function(view, url) {
        return false;
    };

    console.log("[SSL-BYPASS] WebView SSL bypass hooks installed");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # SSL PINNING BYPASS (iOS)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "ios_ssl_pinning_method_swizzle",
        "category": "ssl_pinning",
        "subcategory": "objc_method_swizzle",
        "platform": "ios",
        "description": "Bypass iOS SSL pinning via Objective-C method swizzling",
        "trigger_patterns": ["NSURLConnection", "NSURLSession", "didReceiveAuthenticationChallenge", "SecTrustEvaluate", "URLSession:didReceiveChallenge"],
        "references": ["MSTG-NETWORK-1"],
        "frida_script": r"""
// iOS SSL Pinning Bypass - Method Swizzling
if (ObjC.available) {
    try {
        var resolver = new ApiResolver("objc");
        resolver.enumerateMatches("-[* URLSession:didReceiveChallenge:completionHandler:]", {
            onMatch: function(match) {
                Interceptor.attach(match.address, {
                    onEnter: function(args) {
                        var challenge = new ObjC.Object(args[2]);
                        var protectionSpace = challenge.protectionSpace();
                        var authMethod = protectionSpace.authenticationMethod().toString();

                        if (authMethod === "NSURLAuthenticationMethodServerTrust") {
                            var serverTrust = protectionSpace.serverTrust();
                            var credential = ObjC.classes.NSURLCredential.credentialForTrust_(serverTrust);
                            var handler = new ObjC.Block(args[3]);
                            handler.implementation(0, credential);
                            console.log("[SSL-BYPASS] NSURLSession challenge bypassed");
                            this.skip = true;
                        }
                    },
                    onLeave: function(retval) {}
                });
            }
        });
    } catch(e) {
        console.log("[SSL-BYPASS] NSURLSession hook error: " + e);
    }

    console.log("[SSL-BYPASS] iOS SSL pinning bypass hooks installed");
}
""",
    },
    {
        "id": "ios_ssl_pinning_trust_eval",
        "category": "ssl_pinning",
        "subcategory": "trust_evaluation",
        "platform": "ios",
        "description": "Bypass SecTrustEvaluate and SecTrustEvaluateWithError for certificate pinning",
        "trigger_patterns": ["SecTrustEvaluate", "SecTrustEvaluateWithError", "SecTrustSetAnchorCertificates", "SSLSetPeerDomainName"],
        "references": ["MSTG-NETWORK-1"],
        "frida_script": r"""
// iOS SSL Pinning Bypass - Trust Evaluation
if (ObjC.available) {
    try {
        var SecTrustEvaluateWithError = Module.findExportByName("Security", "SecTrustEvaluateWithError");
        if (SecTrustEvaluateWithError) {
            Interceptor.attach(SecTrustEvaluateWithError, {
                onEnter: function(args) { this.result = args[1]; },
                onLeave: function(retval) {
                    if (this.result) this.result.writeU32(1);
                    retval.replace(ptr(1));
                    console.log("[SSL-BYPASS] SecTrustEvaluateWithError bypassed");
                }
            });
        }
    } catch(e) {}

    try {
        var SecTrustEvaluate = Module.findExportByName("Security", "SecTrustEvaluate");
        if (SecTrustEvaluate) {
            Interceptor.attach(SecTrustEvaluate, {
                onEnter: function(args) { this.result = args[1]; this.trustResultType = args[2]; },
                onLeave: function(retval) {
                    if (this.trustResultType) this.trustResultType.writeU32(1);
                    retval.replace(ptr(0));
                    console.log("[SSL-BYPASS] SecTrustEvaluate bypassed");
                }
            });
        }
    } catch(e) {}

    try {
        var SSLSetPeerDomainName = Module.findExportByName("Security", "SSLSetPeerDomainName");
        if (SSLSetPeerDomainName) {
            Interceptor.attach(SSLSetPeerDomainName, {
                onLeave: function(retval) { retval.replace(ptr(0)); }
            });
        }
    } catch(e) {}

    console.log("[SSL-BYPASS] iOS trust evaluation hooks installed");
}
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # ANTI-DEBUGGING BYPASS (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_anti_debug_ptrace",
        "category": "anti_debug",
        "subcategory": "ptrace_traceme",
        "platform": "android",
        "description": "Bypass anti-debugging via ptrace(PTRACE_TRACEME) and isDebuggerConnected",
        "trigger_patterns": ["ptrace", "PTRACE_TRACEME", "isDebuggerPresent", "Debug.isDebuggerConnected", "debugger"],
        "references": ["MSTG-RESILIENCE-3"],
        "frida_script": r"""
// Anti-Debug Bypass - ptrace and isDebuggerConnected
Java.perform(function() {
    var Debug = Java.use("android.os.Debug");
    Debug.isDebuggerConnected.implementation = function() {
        console.log("[DEBUG-BYPASS] isDebuggerConnected -> false");
        return false;
    };

    try {
        Debug.waitForDebugger.overload("long").implementation = function(timeout) {
            console.log("[DEBUG-BYPASS] waitForDebugger skipped");
        };
    } catch(e) {}
});

Interceptor.attach(Module.findExportByName(null, "ptrace"), {
    onEnter: function(args) {
        var request = args[0].toInt32();
        if (request === 0) {
            console.log("[DEBUG-BYPASS] ptrace(PTRACE_TRACEME) blocked");
        }
    },
    onLeave: function(retval) {
        retval.replace(ptr(0));
    }
});

console.log("[DEBUG-BYPASS] Anti-debugging hooks installed");
""",
    },
    {
        "id": "android_anti_debug_thread",
        "category": "anti_debug",
        "subcategory": "thread_check",
        "platform": "android",
        "description": "Bypass anti-debugging that spawns debugger detection threads (timing checks)",
        "trigger_patterns": ["Thread", "sleep", "debugger", "timing", "CheckThread"],
        "references": ["MSTG-RESILIENCE-3"],
        "frida_script": r"""
// Anti-Debug Bypass - Thread-based Detection
Java.perform(function() {
    var Thread = Java.use("java.lang.Thread");
    Thread.sleep.overload("long").implementation = function(ms) {
        console.log("[DEBUG-BYPASS] Thread.sleep(" + ms + ") skipped");
    };

    Thread.sleep.overload("long", "int").implementation = function(ms, nanos) {
        console.log("[DEBUG-BYPASS] Thread.sleep(" + ms + "," + nanos + ") skipped");
    };

    var System = Java.use("java.lang.System");
    var originalNanoTime = System.nanoTime;
    System.nanoTime.implementation = function() {
        var result = originalNanoTime.call(this);
        return result + Math.floor(Math.random() * 1000);
    };

    console.log("[DEBUG-BYPASS] Timing-based anti-debug hooks installed");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # ANTI-DEBUGGING BYPASS (iOS)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "ios_anti_debug_ptrace",
        "category": "anti_debug",
        "subcategory": "ptrace_self",
        "platform": "ios",
        "description": "Bypass iOS anti-debugging via ptrace(PT_TRACE_ME) and sysctl",
        "trigger_patterns": ["ptrace", "PT_TRACE_ME", "sysctl", "isDebuggerPresent", "getpid"],
        "references": ["MSTG-RESILIENCE-3"],
        "frida_script": r"""
// iOS Anti-Debug Bypass - ptrace
if (ObjC.available) {
    Interceptor.attach(Module.findExportByName(null, "ptrace"), {
        onEnter: function(args) {
            var request = args[0].toInt32();
            if (request === 0) {
                console.log("[DEBUG-BYPASS] ptrace(PT_TRACE_ME) blocked");
            }
        },
        onLeave: function(retval) { retval.replace(ptr(0)); }
    });

    Interceptor.attach(Module.findExportByName("libsystem_kernel.dylib", "sysctl"), {
        onEnter: function(args) {
            this.mib = args[0];
            this.oldp = args[2];
            this.oldlen = args[3];
        },
        onLeave: function(retval) {
            if (this.mib && this.oldp && this.oldlen.toInt32() > 0) {
                try {
                    var mib0 = this.mib.readS32();
                    var mib1 = this.mib.add(4).readS32();
                    if (mib0 === 1 && mib1 === 14) {
                        var flags = this.oldp.add(32).readS32();
                        flags &= ~0x00000800;
                        this.oldp.add(32).writeS32(flags);
                        console.log("[DEBUG-BYPASS] sysctl P_TRACED flag cleared");
                    }
                } catch(e) {}
            }
        }
    });

    console.log("[DEBUG-BYPASS] iOS anti-debug hooks installed");
}
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # JAILBREAK DETECTION BYPASS (iOS)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "ios_jailbreak_file_check",
        "category": "jailbreak_detection",
        "subcategory": "filesystem_check",
        "platform": "ios",
        "description": "Bypass jailbreak detection that checks for Cydia, Substrate, file paths",
        "trigger_patterns": ["/Applications/Cydia.app", "/Library/MobileSubstrate", "/usr/sbin/sshd", "/etc/apt", "sandbox_check", "Cydia", "jailbreak"],
        "references": ["MSTG-RESILIENCE-1"],
        "frida_script": r"""
// iOS Jailbreak Detection Bypass - Filesystem Checks
if (ObjC.available) {
    var jailbreakPaths = [
        "/Applications/Cydia.app", "/Library/MobileSubstrate/MobileSubstrate.dylib",
        "/usr/sbin/sshd", "/usr/bin/sshd", "/usr/bin/ssh",
        "/etc/apt", "/private/var/lib/apt/", "/private/var/lib/cydia",
        "/private/var/tmp/cydia.log", "/private/var/stash",
        "/bin/bash", "/bin/sh", "/usr/bin/env"
    ];

    var jailbreakBundleIds = [
        "com.saurik.Cydia", "com.saurik.substrate",
        "com.bigboss.cydia"
    ];

    var NSFileManager = ObjC.classes.NSFileManager;
    Interceptor.attach(NSFileManager["- fileExistsAtPath:"].implementation, {
        onEnter: function(args) {
            this.path = ObjC.Object(args[2]).toString();
        },
        onLeave: function(retval) {
            for (var i = 0; i < jailbreakPaths.length; i++) {
                if (this.path && this.path.indexOf(jailbreakPaths[i]) !== -1) {
                    retval.replace(ptr(0));
                    console.log("[JAILBREAK-BYPASS] Blocked file check: " + this.path);
                    return;
                }
            }
        }
    });

    Interceptor.attach(Module.findExportByName(null, "access"), {
        onEnter: function(args) {
            this.path = args[0].readUtf8String();
        },
        onLeave: function(retval) {
            if (this.path) {
                for (var i = 0; i < jailbreakPaths.length; i++) {
                    if (this.path.indexOf(jailbreakPaths[i]) !== -1) {
                        retval.replace(ptr(-1));
                        console.log("[JAILBREAK-BYPASS] Blocked access(): " + this.path);
                        return;
                    }
                }
            }
        }
    });

    console.log("[JAILBREAK-BYPASS] iOS jailbreak detection hooks installed");
}
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # TAMPER DETECTION / INTEGRITY BYPASS (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_integrity_check",
        "category": "tamper_detection",
        "subcategory": "signature_verification",
        "platform": "android",
        "description": "Bypass APK signature verification and integrity checks",
        "trigger_patterns": ["PackageManager.GET_SIGNATURES", "getPackageInfo", "signatures", "MessageDigest", "hash", "checksum"],
        "references": ["MSTG-RESILIENCE-5"],
        "frida_script": r"""
// Tamper Detection Bypass - APK Signature Verification
Java.perform(function() {
    var PackageManager = Java.use("android.app.ApplicationPackageManager");

    PackageManager.getPackageInfo.overload("java.lang.String", "int").implementation = function(pkg, flags) {
        var info = this.getPackageInfo(pkg, flags);
        if ((flags & 0x40) !== 0 || (flags & 0x40000000) !== 0) {
            var packageName = this.getApplicationInfo().$getPackageName();
            if (pkg === packageName) {
                console.log("[TAMPER-BYPASS] Signature check intercepted for: " + pkg);
                info.signatures.value = [];
            }
        }
        return info;
    };

    var MessageDigest = Java.use("java.security.MessageDigest");
    MessageDigest.isEqual.implementation = function(a, b) {
        console.log("[TAMPER-BYPASS] MessageDigest.isEqual bypassed");
        return true;
    };

    console.log("[TAMPER-BYPASS] Integrity check hooks installed");
});
""",
    },
    {
        "id": "android_integrity_play_integrity",
        "category": "tamper_detection",
        "subcategory": "play_integrity",
        "platform": "android",
        "description": "Bypass Google Play Integrity API / SafetyNet checks",
        "trigger_patterns": ["Play Integrity", "SafetyNet", "integrity_verdict", "requestVerdict", "MEETS_BASIC_INTEGRITY"],
        "references": ["MSTG-RESILIENCE-5"],
        "frida_script": r"""
// Tamper Detection Bypass - Play Integrity API
Java.perform(function() {
    try {
        var SafetyNet = Java.use("com.google.android.gms.safetynet.SafetyNet");
        SafetyNet.attest.overload("com.google.android.gms.common.api.GoogleApiClient", "[B").implementation = function(client, nonce) {
            console.log("[TAMPER-BYPASS] SafetyNet.attest intercepted");
            return null;
        };
    } catch(e) {}

    console.log("[TAMPER-BYPASS] Play Integrity hooks installed");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # WebView JavaScript Interface (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_webview_js_interface",
        "category": "code_vulnerability",
        "subcategory": "webview_javascript",
        "platform": "android",
        "description": "Intercept JavaScript bridge calls in WebView to enumerate exposed APIs",
        "trigger_patterns": ["addJavascriptInterface", "evaluateJavascript", "JavaScript enabled", "loadUrl("],
        "references": ["MSTG-CODE-8"],
        "frida_script": r"""
// WebView JavaScript Interface Monitor
// Enumerates exposed @JavascriptInterface methods
Java.perform(function() {
    var WebView = Java.use("android.webkit.WebView");

    // Hook addJavascriptInterface to log exposed objects
    WebView.addJavascriptInterface.implementation = function(obj, name) {
        console.log("[WEBVIEW] addJavascriptInterface: name=" + name + " class=" + obj.getClass().getName());

        // Enumerate @JavascriptInterface methods
        var methods = obj.getClass().getMethods();
        for (var i = 0; i < methods.length; i++) {
            var annotations = methods[i].getAnnotations();
            for (var j = 0; j < annotations.length; j++) {
                if (annotations[j].toString().indexOf("JavascriptInterface") !== -1) {
                    console.log("[WEBVIEW] Exposed method: " + name + "." + methods[i].getName() +
                        "(" + methods[i].getParameterTypes().length + " params)");
                }
            }
        }

        this.addJavascriptInterface(obj, name);
    };

    // Hook evaluateJavascript to log script execution
    WebView.evaluateJavascript.overload("java.lang.String", "android.webkit.ValueCallback").implementation = function(script, callback) {
        console.log("[WEBVIEW] evaluateJavascript: " + script.substring(0, Math.min(script.length, 200)));
        this.evaluateJavascript(script, callback);
    };

    // Hook loadUrl
    WebView.loadUrl.overload("java.lang.String").implementation = function(url) {
        console.log("[WEBVIEW] loadUrl: " + url);
        this.loadUrl(url);
    };

    console.log("[WEBVIEW] JavaScript interface monitoring active");
});
""",
    },
    {
        "id": "android_webview_rce",
        "category": "code_vulnerability",
        "subcategory": "webview_rce",
        "platform": "android",
        "description": "Detect and exploit potential RCE via WebView (file:// access, Intent scheme)",
        "trigger_patterns": ["WebView", "setAllowFileAccess", "setAllowContentAccess", "Intent"],
        "references": ["MSTG-CODE-8"],
        "frida_script": r"""
// WebView RCE Detection & Bypass
Java.perform(function() {
    var WebView = Java.use("android.webkit.WebView");

    WebView.setAllowFileAccess.implementation = function(allow) {
        console.log("[WEBVIEW-RCE] setAllowFileAccess(true) forced");
        this.setAllowFileAccess(true);
    };

    WebView.setAllowContentAccess.implementation = function(allow) {
        console.log("[WEBVIEW-RCE] setAllowContentAccess(true) forced");
        this.setAllowContentAccess(true);
    };

    try {
        WebView.setAllowFileAccessFromFileURLs.overload("boolean").implementation = function(allow) {
            console.log("[WEBVIEW-RCE] setAllowFileAccessFromFileURLs(true) forced");
            this.setAllowFileAccessFromFileURLs(true);
        };
    } catch(e) {}

    try {
        WebView.setAllowUniversalAccessFromFileURLs.overload("boolean").implementation = function(allow) {
            console.log("[WEBVIEW-RCE] setAllowUniversalAccessFromFileURLs(true) forced");
            this.setAllowUniversalAccessFromFileURLs(true);
        };
    } catch(e) {}

    // Hook WebViewClient.shouldInterceptRequest for file:// redirection
    try {
        var WebViewClient = Java.use("android.webkit.WebViewClient");
        WebViewClient.shouldInterceptRequest.overload("android.webkit.WebView", "java.lang.String").implementation = function(view, url) {
            if (url.indexOf("file://") !== -1 || url.indexOf("content://") !== -1) {
                console.log("[WEBVIEW-RCE] File access request: " + url);
            }
            return this.shouldInterceptRequest(view, url);
        };
    } catch(e) {}

    console.log("[WEBVIEW-RCE] WebView RCE monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # JNI MONITOR (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_jni_monitor",
        "category": "code_vulnerability",
        "subcategory": "jni_monitor",
        "platform": "android",
        "description": "Monitor JNI calls to detect native code operations and data flow",
        "trigger_patterns": ["JNI", "native", "System.loadLibrary", "fopen", "access(", "stat("],
        "references": ["MSTG-CODE-5"],
        "frida_script": r"""
// JNI Call Monitor
// Logs all JNI method registrations and native library loading
Java.perform(function() {
    var System = Java.use("java.lang.System");

    System.loadLibrary.overload("java.lang.String").implementation = function(libName) {
        console.log("[JNI-MONITOR] Loading native library: " + libName);
        this.loadLibrary(libName);
    };

    try {
        System.load.overload("java.lang.String").implementation = function(path) {
            console.log("[JNI-MONITOR] Loading native .so from: " + path);
            this.load(path);
        };
    } catch(e) {}

    // Monitor JNI_OnLoad via ProcessBuilder (indirect detection)
    try {
        var ProcessBuilder = Java.use("java.lang.ProcessBuilder");
        ProcessBuilder.$init.overload("[Ljava.lang.String;").implementation = function(commands) {
            var cmd = commands.join(" ");
            console.log("[JNI-MONITOR] ProcessBuilder: " + cmd);
            this.$init(commands);
        };
    } catch(e) {}

    console.log("[JNI-MONITOR] JNI monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # HARDCODED SECRETS (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_hardcoded_secrets",
        "category": "secret_detection",
        "subcategory": "hardcoded_keys",
        "platform": "android",
        "description": "Detect hardcoded secrets, API keys, and credentials at runtime",
        "trigger_patterns": ["hardcoded", "API_KEY", "SECRET", "password", "token", "credential"],
        "references": ["MSTG-CODE-2"],
        "frida_script": r"""
// Hardcoded Secrets Detector
// Monitors string construction and potential secret usage at runtime
Java.perform(function() {
    // Monitor String concatenation with sensitive keywords
    var String = Java.use("java.lang.String");
    var sensitiveKeywords = ["api_key", "secret", "password", "token", "auth",
                            "credential", "private_key", "access_key", "aws",
                            "firebase", "google_maps", "stripe", "paypal"];

    String.valueOf.overload("java.lang.Object").implementation = function(obj) {
        var result = this.valueOf(obj);
        if (result && typeof result === "string") {
            var lower = result.toLowerCase();
            for (var i = 0; i < sensitiveKeywords.length; i++) {
                if (lower.indexOf(sensitiveKeywords[i]) !== -1) {
                    console.log("[SECRET-DETECT] Potential secret in String.valueOf(): " + result.substring(0, 100));
                    break;
                }
            }
        }
        return result;
    };

    // Monitor SharedPreferences for secret storage
    try {
        var SharedPreferencesImpl = Java.use("android.app.SharedPreferencesImpl");
        SharedPreferencesImpl.getString.implementation = function(key, defValue) {
            var value = this.getString(key, defValue);
            if (value) {
                var lower = (key + value).toLowerCase();
                for (var i = 0; i < sensitiveKeywords.length; i++) {
                    if (lower.indexOf(sensitiveKeywords[i]) !== -1) {
                        console.log("[SECRET-DETECT] Sensitive SharedPreferences: " + key + " = " + value);
                        break;
                    }
                }
            }
            return value;
        };
    } catch(e) {}

    console.log("[SECRET-DETECT] Hardcoded secrets monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # LOGGING MONITOR (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_logging_monitor",
        "category": "code_vulnerability",
        "subcategory": "logging",
        "platform": "android",
        "description": "Monitor and bypass Android logging to detect sensitive data leakage",
        "trigger_patterns": ["Log.d", "Log.e", "Log.v", "Log.w", "Log.i", "System.out", "println"],
        "references": ["MSTG-CODE-3"],
        "frida_script": r"""
// Logging Monitor & Bypass
// Detects and optionally disables verbose logging
Java.perform(function() {
    var Log = Java.use("android.util.Log");

    Log.d.overload("java.lang.String", "java.lang.String").implementation = function(tag, msg) {
        console.log("[LOG] D/" + tag + ": " + msg);
        return this.d(tag, msg);
    };

    Log.e.overload("java.lang.String", "java.lang.String").implementation = function(tag, msg) {
        console.log("[LOG] E/" + tag + ": " + msg);
        return this.e(tag, msg);
    };

    Log.v.overload("java.lang.String", "java.lang.String").implementation = function(tag, msg) {
        console.log("[LOG] V/" + tag + ": " + msg);
        return this.v(tag, msg);
    };

    Log.i.overload("java.lang.String", "java.lang.String").implementation = function(tag, msg) {
        console.log("[LOG] I/" + tag + ": " + msg);
        return this.i(tag, msg);
    };

    Log.w.overload("java.lang.String", "java.lang.String").implementation = function(tag, msg) {
        console.log("[LOG] W/" + tag + ": " + msg);
        return this.w(tag, msg);
    };

    // Monitor System.out.println
    try {
        var PrintStream = Java.use("java.io.PrintStream");
        PrintStream.println.overload("java.lang.String").implementation = function(s) {
            console.log("[LOG] System.out: " + s);
            this.println(s);
        };
    } catch(e) {}

    console.log("[LOG] Logging monitor active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # DEBUG MONITOR (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_debug_monitor",
        "category": "code_vulnerability",
        "subcategory": "debug_info",
        "platform": "android",
        "description": "Monitor debug symbols and debug mode indicators in the app",
        "trigger_patterns": ["debuggable", "debug", "DEBUG", "BuildConfig"],
        "references": ["MSTG-CODE-1"],
        "frida_script": r"""
// Debug Mode Monitor
Java.perform(function() {
    // Check if app is debuggable
    var context = Java.use("android.app.ActivityThread").currentApplication();
    var appInfo = context.getApplicationInfo();
    var flags = appInfo.flags.value;
    var debuggable = (flags & 0x2) !== 0;
    console.log("[DEBUG-MONITOR] App debuggable: " + debuggable);

    // Spoof BuildConfig.DEBUG if present
    try {
        var pkg = appInfo.packageName.value;
        var BuildConfig = Java.use(pkg + ".BuildConfig");
        BuildConfig.DEBUG.value = false;
        console.log("[DEBUG-MONITOR] BuildConfig.DEBUG set to false");
    } catch(e) {
        console.log("[DEBUG-MONITOR] BuildConfig not found (obfuscated or no BuildConfig)");
    }

    // Monitor debug logging
    var Debug = Java.use("android.os.Debug");
    Debug.isDebuggerConnected.implementation = function() {
        var result = this.isDebuggerConnected();
        console.log("[DEBUG-MONITOR] isDebuggerConnected called -> " + result);
        return result;
    };

    console.log("[DEBUG-MONITOR] Debug monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # EXPORTED COMPONENTS (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_exported_components",
        "category": "platform_vulnerability",
        "subcategory": "exported_components",
        "platform": "android",
        "description": "Enumerate and interact with exported Activities, Services, BroadcastReceivers",
        "trigger_patterns": ["Exported", "exported", "intent-filter", "Activity", "Service"],
        "references": ["MSTG-PLATFORM-1"],
        "frida_script": r"""
// Exported Components Interceptor
// Logs and intercepts all exported component launches
Java.perform(function() {
    var Intent = Java.use("android.content.Intent");

    Intent.$init.overload("android.content.Context", "java.lang.Class").implementation = function(ctx, cls) {
        console.log("[EXPORTED] Intent to: " + cls.getName());
        this.$init(ctx, cls);
    };

    Intent.$init.overload("java.lang.String").implementation = function(action) {
        console.log("[EXPORTED] Intent action: " + action);
        this.$init(action);
    };

    // Monitor startActivity
    var Activity = Java.use("android.app.Activity");
    Activity.startActivity.overload("android.content.Intent").implementation = function(intent) {
        var target = intent.getComponent();
        if (target) {
            console.log("[EXPORTED] startActivity: " + target.getClassName());
        }
        this.startActivity(intent);
    };

    // Monitor sendBroadcast
    var Context = Java.use("android.content.Context");
    Context.sendBroadcast.overload("android.content.Intent").implementation = function(intent) {
        console.log("[EXPORTED] sendBroadcast: " + intent.toString().substring(0, 200));
        this.sendBroadcast(intent);
    };

    console.log("[EXPORTED] Exported components monitoring active");
});
""",
    },
    {
        "id": "android_intent_injection",
        "category": "platform_vulnerability",
        "subcategory": "intent_injection",
        "platform": "android",
        "description": "Inject custom Intents to test exported components for vulnerabilities",
        "trigger_patterns": ["Exported", "exported", "intent-filter", "startActivity"],
        "references": ["MSTG-PLATFORM-1"],
        "frida_script": r"""
// Intent Injection Testing
// Modifies Intent extras to test for injection vulnerabilities
Java.perform(function() {
    var Intent = Java.use("android.content.Intent");

    // Log all Intent extras when startActivity is called
    var Activity = Java.use("android.app.Activity");
    Activity.startActivity.overload("android.content.Intent").implementation = function(intent) {
        var extras = intent.getExtras();
        if (extras) {
            var keys = extras.keySet().toArray();
            console.log("[INTENT-INJECT] startActivity extras:");
            for (var i = 0; i < keys.length; i++) {
                var key = keys[i];
                var val = extras.get(key);
                console.log("[INTENT-INJECT]   " + key + " = " + (val ? val.toString() : "null"));
            }
        }
        this.startActivity(intent);
    };

    // Log extras from incoming Intents (onNewIntent)
    try {
        var Activity2 = Java.use("android.app.Activity");
        Activity2.onNewIntent.overload("android.content.Intent").implementation = function(intent) {
            var extras = intent.getExtras();
            if (extras) {
                var keys = extras.keySet().toArray();
                console.log("[INTENT-INJECT] onNewIntent extras:");
                for (var i = 0; i < keys.length; i++) {
                    var key = keys[i];
                    var val = extras.get(key);
                    console.log("[INTENT-INJECT]   " + key + " = " + (val ? val.toString() : "null"));
                }
            }
            this.onNewIntent(intent);
        };
    } catch(e) {}

    console.log("[INTENT-INJECT] Intent injection monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # IPC MONITOR (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_ipc_monitor",
        "category": "platform_vulnerability",
        "subcategory": "ipc_monitor",
        "platform": "android",
        "description": "Monitor IPC communication (ContentProvider, Binder, AIDL) for data leakage",
        "trigger_patterns": ["ContentProvider", "Binder", "AIDL", "IPC", "Messenger"],
        "references": ["MSTG-STORAGE-7"],
        "frida_script": r"""
// IPC Communication Monitor
Java.perform(function() {
    // Monitor ContentProvider queries
    try {
        var ContentResolver = Java.use("android.content.ContentResolver");
        ContentResolver.query.overload("android.net.Uri", "[Ljava.lang.String;", "java.lang.String", "[Ljava.lang.String;", "java.lang.String").implementation = function(uri, projection, selection, selectionArgs, sortOrder) {
            console.log("[IPC-MONITOR] ContentProvider query: " + uri.toString());
            if (selection) console.log("[IPC-MONITOR]   selection: " + selection);
            return this.query(uri, projection, selection, selectionArgs, sortOrder);
        };
    } catch(e) {}

    // Monitor Binder transactions
    try {
        var Binder = Java.use("android.os.Binder");
        Binder.transact.overload("int", "android.os.Parcel", "android.os.Parcel", "int").implementation = function(code, data, reply, flags) {
            console.log("[IPC-MONITOR] Binder transact: code=" + code + " flags=" + flags);
            return this.transact(code, data, reply, flags);
        };
    } catch(e) {}

    // Monitor AIDL service connections
    try {
        var ServiceConnection = Java.use("android.content.ServiceConnection");
        // This is an interface — we monitor the bindService call
        var Context = Java.use("android.content.Context");
        Context.bindService.overload("android.content.Intent", "android.content.ServiceConnection", "int").implementation = function(intent, conn, flags) {
            var target = intent.getComponent();
            console.log("[IPC-MONITOR] bindService: " + (target ? target.getClassName() : "unknown") + " flags=" + flags);
            return this.bindService(intent, conn, flags);
        };
    } catch(e) {}

    console.log("[IPC-MONITOR] IPC monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # BACKUP BYPASS (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_backup_bypass",
        "category": "storage_vulnerability",
        "subcategory": "backup_bypass",
        "platform": "android",
        "description": "Bypass Android backup restrictions (allowBackup=true) to extract app data",
        "trigger_patterns": ["allowBackup", "backup", "fullBackupContent"],
        "references": ["MSTG-STORAGE-5"],
        "frida_script": r"""
// Backup Bypass Monitor
// Detects and logs backup-related operations
Java.perform(function() {
    // Monitor backup agent calls
    try {
        var BackupAgent = Java.use("android.app.backup.BackupAgent");
        BackupAgent.onBackup.implementation = function(oldState, data, newState) {
            console.log("[BACKUP] onBackup triggered - app data being backed up!");
            this.onBackup(oldState, data, newState);
        };
    } catch(e) {}

    // Check allowBackup flag
    try {
        var context = Java.use("android.app.ActivityThread").currentApplication();
        var appInfo = context.getApplicationInfo();
        var allowBackup = (appInfo.flags.value & 0x8000) !== 0;
        console.log("[BACKUP] allowBackup = " + allowBackup);

        if (allowBackup) {
            console.log("[BACKUP] WARNING: App allows backup! Use 'adb backup -f backup.ab " + appInfo.packageName.value + "'");
        }
    } catch(e) {}

    // Monitor file access to common backup-extracted paths
    var File = Java.use("java.io.File");
    var sensitivePaths = [
        "/shared_prefs/", "/databases/", "/files/", "/cache/"
    ];

    File.exists.implementation = function() {
        var path = this.getAbsolutePath();
        for (var i = 0; i < sensitivePaths.length; i++) {
            if (path.indexOf(sensitivePaths[i]) !== -1 && path.indexOf("mobiscan") === -1) {
                console.log("[BACKUP] App data path accessed: " + path);
            }
        }
        return this.exists();
    };

    console.log("[BACKUP] Backup monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # KEYBOARD CACHE MONITOR (Android)
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_keyboard_monitor",
        "category": "storage_vulnerability",
        "subcategory": "keyboard_cache",
        "platform": "android",
        "description": "Monitor EditText input to detect sensitive data in keyboard cache",
        "trigger_patterns": ["inputType", "textPassword", "textVisiblePassword", "keyboard", "EditText"],
        "references": ["MSTG-STORAGE-3"],
        "frida_script": r"""
// Keyboard Cache Monitor
// Monitors text input fields for sensitive data handling
Java.perform(function() {
    // Hook EditText to log input type
    var EditText = Java.use("android.widget.EditText");

    EditText.setInputType.implementation = function(type) {
        var inputTypes = {
            0x81: "textPassword",
            0x91: "textVisiblePassword",
            0xE1: "textWebPassword",
            0x02: "textEmailAddress",
            0x03: "textPersonName"
        };
        var typeName = inputTypes[type] || "type_" + type;
        console.log("[KEYBOARD] EditText input type: " + typeName + " (0x" + type.toString(16) + ")");

        if ((type & 0x80) !== 0) {
            console.log("[KEYBOARD] WARNING: Password field detected but verify text is masked");
        }

        this.setInputType(type);
    };

    // Monitor text changes for potential secrets
    try {
        var TextWatcher = Java.use("android.text.TextWatcher");
        // We can't hook an interface, but we can hook the base class
    } catch(e) {}

    console.log("[KEYBOARD] Keyboard cache monitor active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # CRYPTOGRAPHIC MISUSE DETECTION
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_crypto_monitor",
        "category": "crypto_misuse",
        "subcategory": "hardcoded_keys",
        "platform": "android",
        "description": "Monitor and log cryptographic operations to detect hardcoded keys and weak algorithms",
        "trigger_patterns": ["DES", "MD5", "SHA1", "ECB", "hardcoded", "SecretKeySpec", "Cipher.getInstance", "SHA-1", "SHA1"],
        "references": ["MSTG-CRYPTO-1", "MSTG-CRYPTO-2", "MSTG-CRYPTO-3"],
        "frida_script": r"""
// Crypto Monitoring - Detect Hardcoded Keys and Weak Algorithms
Java.perform(function() {
    var Cipher = Java.use("javax.crypto.Cipher");
    Cipher.getInstance.overload("java.lang.String").implementation = function(transformation) {
        var weakAlgos = ["DES", "DESede", "RC4", "RC2", "Blowfish"];
        var modes = ["ECB"];

        for (var i = 0; i < weakAlgos.length; i++) {
            if (transformation.toUpperCase().indexOf(weakAlgos[i]) !== -1) {
                console.log("[CRYPTO-WARN] Weak algorithm detected: " + transformation);
            }
        }
        for (var i = 0; i < modes.length; i++) {
            if (transformation.toUpperCase().indexOf(modes[i]) !== -1) {
                console.log("[CRYPTO-WARN] Insecure mode detected: " + transformation);
            }
        }
        return this.getInstance(transformation);
    };

    var SecretKeySpec = Java.use("javax.crypto.spec.SecretKeySpec");
    SecretKeySpec.$init.overload("[B", "java.lang.String").implementation = function(key, algorithm) {
        var keyStr = "";
        for (var i = 0; i < Math.min(key.length, 32); i++) {
            keyStr += ("0" + (key[i] & 0xFF).toString(16)).slice(-2);
        }
        console.log("[CRYPTO-INFO] SecretKeySpec: algo=" + algorithm + " key_hex=" + keyStr + " len=" + key.length);
        this.$init(key, algorithm);
    };

    var MessageDigest = Java.use("java.security.MessageDigest");
    MessageDigest.getInstance.overload("java.lang.String").implementation = function(algorithm) {
        var weak = ["MD5", "SHA-1", "SHA1"];
        for (var i = 0; i < weak.length; i++) {
            if (algorithm.toUpperCase() === weak[i]) {
                console.log("[CRYPTO-WARN] Weak hash algorithm: " + algorithm);
            }
        }
        return this.getInstance(algorithm);
    };

    console.log("[CRYPTO-MONITOR] Cryptographic operation monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # NETWORK TRAFFIC MONITORING
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_network_monitor",
        "category": "network_monitoring",
        "subcategory": "http_logging",
        "platform": "android",
        "description": "Monitor HTTP/HTTPS requests made by the app for traffic analysis",
        "trigger_patterns": ["OkHttp", "Retrofit", "HttpURLConnection", "Volley", "okhttp3", "cleartext", "usesCleartextTraffic"],
        "references": ["MSTG-NETWORK-1"],
        "frida_script": r"""
// Network Traffic Monitor
Java.perform(function() {
    try {
        var Request = Java.use("okhttp3.Request");
        var RequestBuilder = Java.use("okhttp3.Request$Builder");

        RequestBuilder.build.implementation = function() {
            var req = this.build();
            var url = req.url().toString();
            var method = req.method();
            var headers = "";
            var headerNames = req.headers().names().toArray();
            for (var i = 0; i < headerNames.length; i++) {
                var name = headerNames[i];
                if (name.toLowerCase().indexOf("auth") !== -1 || name.toLowerCase().indexOf("token") !== -1) {
                    headers += name + ": " + req.header(name) + " ";
                }
            }
            console.log("[NET-MONITOR] " + method + " " + url + (headers ? " | " + headers : ""));
            return req;
        };
    } catch(e) {}

    try {
        var SSLSocket = Java.use("javax.net.ssl.SSLSocket");
        SSLSocket.startHandshake.implementation = function() {
            var host = this.getHandshakeSession().getPeerHost();
            var protocol = this.getSession().getProtocol();
            var cipher = this.getSession().getCipherSuite();
            console.log("[NET-MONITOR] TLS: host=" + host + " proto=" + protocol + " cipher=" + cipher);
            this.startHandshake();
        };
    } catch(e) {}

    console.log("[NET-MONITOR] HTTP traffic monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # STORAGE / SHARED PREFERENCES MONITORING
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "android_storage_monitor",
        "category": "storage_monitoring",
        "subcategory": "shared_prefs",
        "platform": "android",
        "description": "Monitor SharedPreferences and file I/O for sensitive data storage",
        "trigger_patterns": ["SharedPreferences", "getSharedPreferences", "MODE_WORLD_READABLE", "SQLite", "ContentProvider", "external storage", "External storage"],
        "references": ["MSTG-STORAGE-1", "MSTG-STORAGE-2"],
        "frida_script": r"""
// Storage Monitoring - SharedPreferences and File I/O
Java.perform(function() {
    var SharedPreferencesImpl = Java.use("android.app.SharedPreferencesImpl");

    SharedPreferencesImpl.getString.implementation = function(key, defValue) {
        var value = this.getString(key, defValue);
        console.log("[STORAGE-MONITOR] getString: " + key + " = " + (value || "(null)"));
        return value;
    };

    SharedPreferencesImpl.getInt.implementation = function(key, defValue) {
        var value = this.getInt(key, defValue);
        console.log("[STORAGE-MONITOR] getInt: " + key + " = " + value);
        return value;
    };

    SharedPreferencesImpl.getBoolean.implementation = function(key, defValue) {
        var value = this.getBoolean(key, defValue);
        console.log("[STORAGE-MONITOR] getBoolean: " + key + " = " + value);
        return value;
    };

    try {
        var EditorImpl = Java.use("android.app.SharedPreferencesImpl$EditorImpl");
        EditorImpl.putString.implementation = function(key, value) {
            var sensitive = ["password", "token", "secret", "key", "auth", "session", "cookie"];
            for (var i = 0; i < sensitive.length; i++) {
                if (key.toLowerCase().indexOf(sensitive[i]) !== -1) {
                    console.log("[STORAGE-WARN] SENSITIVE data written to SharedPreferences: " + key + " = " + value);
                }
            }
            console.log("[STORAGE-MONITOR] putString: " + key);
            return this.putString(key, value);
        };
    } catch(e) {}

    try {
        var SQLiteDatabase = Java.use("android.database.sqlite.SQLiteDatabase");
        SQLiteDatabase.execSQL.overload("java.lang.String").implementation = function(sql) {
            console.log("[STORAGE-MONITOR] SQL: " + sql.substring(0, Math.min(sql.length, 200)));
            this.execSQL(sql);
        };
    } catch(e) {}

    console.log("[STORAGE-MONITOR] Storage monitoring active");
});
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # iOS URL SCHEME BYPASS
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "ios_url_scheme_bypass",
        "category": "platform_vulnerability",
        "subcategory": "url_scheme",
        "platform": "ios",
        "description": "Monitor and intercept custom URL scheme handling for injection testing",
        "trigger_patterns": ["canOpenURL", "custom URL scheme", "CFBundleURLSchemes", "openURL"],
        "references": ["MSTG-PLATFORM-2"],
        "frida_script": r"""
// iOS URL Scheme Monitor
if (ObjC.available) {
    // Monitor canOpenURL
    try {
        var UIApplication = ObjC.classes.UIApplication;
        Interceptor.attach(UIApplication["- canOpenURL:"].implementation, {
            onEnter: function(args) {
                var url = ObjC.Object(args[2]).toString();
                console.log("[URL-SCHEME] canOpenURL: " + url);
            }
        });
    } catch(e) {}

    // Monitor openURL
    try {
        var UIApplication = ObjC.classes.UIApplication;
        Interceptor.attach(UIApplication["- openURL:"].implementation, {
            onEnter: function(args) {
                var url = ObjC.Object(args[2]).toString();
                console.log("[URL-SCHEME] openURL: " + url);
            }
        });
    } catch(e) {}

    console.log("[URL-SCHEME] URL scheme monitoring active");
}
""",
    },

    # ═══════════════════════════════════════════════════════════════
    # iOS IPC MONITOR
    # ═══════════════════════════════════════════════════════════════
    {
        "id": "ios_ipc_monitor",
        "category": "platform_vulnerability",
        "subcategory": "ipc_monitor",
        "platform": "ios",
        "description": "Monitor iOS IPC (NSXPC, pasteboard, keychain) for data leakage",
        "trigger_patterns": ["NSXPCConnection", "UIPasteboard", "keychain", "NSUbiquitousKeyValueStore"],
        "references": ["MSTG-PLATFORM-6"],
        "frida_script": r"""
// iOS IPC Monitor
if (ObjC.available) {
    // Monitor UIPasteboard writes
    try {
        var UIPasteboard = ObjC.classes.UIPasteboard;
        Interceptor.attach(UIPasteboard["- setData:forPasteboardType:"].implementation, {
            onEnter: function(args) {
                var type = ObjC.Object(args[3]).toString();
                console.log("[IPC-MONITOR] Pasteboard write: type=" + type);
            }
        });
    } catch(e) {}

    // Monitor NSXPCConnection
    try {
        var NSXPCConnection = ObjC.classes.NSXPCConnection;
        Interceptor.attach(NSXPCConnection["- resume"].implementation, {
            onEnter: function(args) {
                console.log("[IPC-MONITOR] XPC connection resumed: " + this.toString());
            }
        });
    } catch(e) {}

    // Monitor Keychain writes
    try {
        var SecItemAdd = Module.findExportByName("Security", "SecItemAdd");
        if (SecItemAdd) {
            Interceptor.attach(SecItemAdd, {
                onEnter: function(args) {
                    var dict = new ObjC.Object(args[0]);
                    try {
                        var service = dict.objectForKey_(ObjC.classes.NSString.stringWithString_("kSecAttrService"));
                        var account = dict.objectForKey_(ObjC.classes.NSString.stringWithString_("kSecAttrAccount"));
                        console.log("[IPC-MONITOR] Keychain write: service=" + service + " account=" + account);
                    } catch(e) {}
                }
            });
        }
    } catch(e) {}

    console.log("[IPC-MONITOR] iOS IPC monitoring active");
}
""",
    },
]

# Category metadata for UI display
CATEGORIES = {
    "root_detection": {
        "name": "Root Detection Bypass",
        "icon": "📱",
        "color": "#ff6b35",
        "description": "Bypass root/jailbreak detection mechanisms"
    },
    "ssl_pinning": {
        "name": "SSL Pinning Bypass",
        "icon": "🔒",
        "color": "#00c853",
        "description": "Bypass certificate pinning for traffic interception"
    },
    "anti_debug": {
        "name": "Anti-Debug Bypass",
        "icon": "🐛",
        "color": "#ffd600",
        "description": "Bypass debugger detection and anti-tampering"
    },
    "jailbreak_detection": {
        "name": "Jailbreak Detection Bypass",
        "icon": "🍎",
        "color": "#ff1744",
        "description": "Bypass iOS jailbreak detection mechanisms"
    },
    "tamper_detection": {
        "name": "Tamper Detection Bypass",
        "icon": "🛡️",
        "color": "#d500f9",
        "description": "Bypass integrity and signature verification"
    },
    "code_vulnerability": {
        "name": "Code Vulnerability Analysis",
        "icon": "💉",
        "color": "#ff6e40",
        "description": "Intercept and test WebView, JNI, logging, and debug issues"
    },
    "secret_detection": {
        "name": "Secret Detection",
        "icon": "🔑",
        "color": "#ff1744",
        "description": "Detect hardcoded secrets, API keys, and credentials"
    },
    "platform_vulnerability": {
        "name": "Platform Vulnerability",
        "icon": "📡",
        "color": "#6200ea",
        "description": "Test exported components, IPC, and URL schemes"
    },
    "storage_vulnerability": {
        "name": "Storage Vulnerability",
        "icon": "📂",
        "color": "#e65100",
        "description": "Test backup restrictions and keyboard cache handling"
    },
    "crypto_misuse": {
        "name": "Crypto Monitoring",
        "icon": "🔐",
        "color": "#2979ff",
        "description": "Monitor cryptographic operations for misuse"
    },
    "network_monitoring": {
        "name": "Network Monitoring",
        "icon": "🌐",
        "color": "#00bfa5",
        "description": "Monitor HTTP/HTTPS traffic and TLS connections"
    },
    "storage_monitoring": {
        "name": "Storage Monitoring",
        "icon": "💾",
        "color": "#ff9100",
        "description": "Monitor SharedPreferences, SQLite, and file I/O"
    },
}
