"""
Enhanced AI-Powered Frida Script Generator

Key improvements over v1:
1. Only generates scripts for FAIL and WARNING results (never PASS/INFO)
2. Direct MSTG test_id → script category mapping for instant matching
3. Evidence-based vulnerability extraction (understands what was actually found)
4. Two-phase scoring: direct match (high weight) + TF-IDF (supplementary)
5. Per-result severity weighting (FAIL > WARNING)
"""

import json
import math
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from collections import Counter


@dataclass
class GeneratedScript:
    """A generated Frida script with metadata."""
    script_id: str
    category: str
    name: str
    description: str
    platform: str
    confidence: float  # 0.0 - 1.0
    script_code: str
    matched_patterns: List[str] = field(default_factory=list)
    references: List[str] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)
    triggered_by: List[str] = field(default_factory=list)  # test_ids that triggered this
    severity: str = "WARNING"  # FAIL or WARNING


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MSTG Test ID → Script Category Direct Mapping
# This is the FAST path — instant match without TF-IDF
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MSTG_TO_SCRIPTS = {
    # Root / Jailbreak Detection
    "MSTG-RESILIENCE-1": ["android_root_file_check", "android_root_native_check",
                          "android_root_build_check", "android_root_magisk_hide",
                          "ios_jailbreak_file_check"],
    # Anti-Debug
    "MSTG-RESILIENCE-3": ["android_anti_debug_ptrace", "android_anti_debug_thread",
                          "ios_anti_debug_ptrace"],
    # Anti-Hooking / Tamper
    "MSTG-RESILIENCE-5": ["android_integrity_check", "android_integrity_play_integrity"],
    # Anti-Reversing (obfuscation = needs dynamic analysis)
    "MSTG-RESILIENCE-2": ["android_anti_debug_ptrace"],
    # SSL/TLS Pinning
    "MSTG-NETWORK-1": ["android_ssl_pinning_java", "android_ssl_pinning_network_security",
                        "android_ssl_pinning_webview",
                        "ios_ssl_pinning_method_swizzle", "ios_ssl_pinning_trust_eval"],
    "MSTG-NETWORK-4": ["android_ssl_pinning_java", "android_ssl_pinning_network_security",
                        "android_ssl_pinning_webview"],
    # Unencrypted communications
    "MSTG-NETWORK-2": ["android_network_monitor"],
    # Crypto misuse
    "MSTG-CRYPTO-1": ["android_crypto_monitor"],
    "MSTG-CRYPTO-2": ["android_crypto_monitor"],
    "MSTG-CRYPTO-3": ["android_crypto_monitor"],
    "MSTG-CRYPTO-4": ["android_crypto_monitor"],
    # WebView issues
    "MSTG-CODE-8": ["android_ssl_pinning_webview", "android_webview_js_interface",
                     "android_webview_rce"],
    "MSTG-CODE-08": ["android_ssl_pinning_webview", "android_webview_js_interface",
                      "android_webview_rce"],
    # Unsafe JNI
    "MSTG-CODE-5": ["android_jni_monitor"],
    "MSTG-CODE-05": ["android_jni_monitor"],
    # Hardcoded secrets
    "MSTG-CODE-2": ["android_hardcoded_secrets", "android_crypto_monitor"],
    "MSTG-CODE-02": ["android_hardcoded_secrets", "android_crypto_monitor"],
    # Logging
    "MSTG-CODE-3": ["android_logging_monitor"],
    "MSTG-CODE-03": ["android_logging_monitor"],
    # Debugging symbols
    "MSTG-CODE-1": ["android_debug_monitor"],
    "MSTG-CODE-01": ["android_debug_monitor"],
    # Exported components
    "MSTG-PLATFORM-1": ["android_exported_components", "android_intent_injection"],
    "MSTG-PLATFORM-01": ["android_exported_components", "android_intent_injection"],
    # IPC
    "MSTG-STORAGE-7": ["android_ipc_monitor"],
    "MSTG-STORAGE-07": ["android_ipc_monitor"],
    # Backups
    "MSTG-STORAGE-5": ["android_backup_bypass"],
    "MSTG-STORAGE-05": ["android_backup_bypass"],
    # Local storage
    "MSTG-STORAGE-1": ["android_storage_monitor"],
    "MSTG-STORAGE-01": ["android_storage_monitor"],
    # Temp files
    "MSTG-STORAGE-4": ["android_storage_monitor"],
    "MSTG-STORAGE-04": ["android_storage_monitor"],
    # Shared storage
    "MSTG-STORAGE-8": ["android_storage_monitor"],
    "MSTG-STORAGE-08": ["android_storage_monitor"],
    # Keyboard cache
    "MSTG-STORAGE-3": ["android_keyboard_monitor"],
    "MSTG-STORAGE-03": ["android_keyboard_monitor"],
    # iOS specific
    "MSTG-PLATFORM-2": ["ios_url_scheme_bypass"],
    "MSTG-PLATFORM-6": ["ios_ipc_monitor"],
    # Obfuscation check (CODE-07) → suggests anti-debug / dynamic analysis
    "MSTG-CODE-7": ["android_anti_debug_ptrace"],
    "MSTG-CODE-07": ["android_anti_debug_ptrace"],
}


# Evidence pattern → script ID mapping for more specific matching
EVIDENCE_TO_SCRIPTS = {
    # Root detection indicators
    "su binary": ["android_root_file_check"],
    "/system/bin/su": ["android_root_file_check"],
    "Superuser.apk": ["android_root_file_check"],
    "Magisk": ["android_root_file_check", "android_root_magisk_hide"],
    "BusyBox": ["android_root_file_check"],
    "RootBeer": ["android_root_file_check"],
    "root detection": ["android_root_file_check", "android_root_native_check"],
    # Native / JNI
    "JNI": ["android_jni_monitor"],
    "native": ["android_jni_monitor"],
    "System.loadLibrary": ["android_jni_monitor"],
    "fopen": ["android_root_native_check"],
    "access(": ["android_root_native_check"],
    "stat(": ["android_root_native_check"],
    # SSL / TLS
    "TrustManager": ["android_ssl_pinning_java"],
    "checkServerTrusted": ["android_ssl_pinning_java"],
    "SSLContext": ["android_ssl_pinning_java"],
    "certificate pinning": ["android_ssl_pinning_java"],
    "certificate": ["android_ssl_pinning_java"],
    "pinning": ["android_ssl_pinning_java"],
    "NetworkSecurityConfig": ["android_ssl_pinning_network_security"],
    "network-security-config": ["android_ssl_pinning_network_security"],
    "pin-set": ["android_ssl_pinning_network_security"],
    "pin-sha256": ["android_ssl_pinning_network_security"],
    "WebView": ["android_ssl_pinning_webview", "android_webview_js_interface"],
    "onReceivedSslError": ["android_ssl_pinning_webview"],
    "SslError": ["android_ssl_pinning_webview"],
    "SecTrustEvaluate": ["ios_ssl_pinning_trust_eval"],
    "NSURLSession": ["ios_ssl_pinning_method_swizzle"],
    "NSURLConnection": ["ios_ssl_pinning_method_swizzle"],
    # Anti-debug
    "isDebuggerPresent": ["android_anti_debug_ptrace", "ios_anti_debug_ptrace"],
    "Debug.isDebuggerConnected": ["android_anti_debug_ptrace"],
    "ptrace": ["android_anti_debug_ptrace", "ios_anti_debug_ptrace"],
    "PTRACE_TRACEME": ["android_anti_debug_ptrace"],
    "PT_TRACE_ME": ["ios_anti_debug_ptrace"],
    "debugger": ["android_anti_debug_ptrace"],
    "timing": ["android_anti_debug_thread"],
    # Tamper / Integrity
    "GET_SIGNATURES": ["android_integrity_check"],
    "MessageDigest": ["android_integrity_check"],
    "Play Integrity": ["android_integrity_play_integrity"],
    "SafetyNet": ["android_integrity_play_integrity"],
    # WebView specific
    "JavaScript enabled": ["android_webview_js_interface"],
    "addJavascriptInterface": ["android_webview_js_interface"],
    "loadUrl": ["android_ssl_pinning_webview"],
    "evaluateJavascript": ["android_webview_js_interface"],
    # Crypto
    "DES": ["android_crypto_monitor"],
    "MD5": ["android_crypto_monitor"],
    "ECB": ["android_crypto_monitor"],
    "hardcoded": ["android_hardcoded_secrets"],
    "SecretKeySpec": ["android_crypto_monitor"],
    # Network
    "OkHttp": ["android_network_monitor"],
    "Retrofit": ["android_network_monitor"],
    "HttpURLConnection": ["android_network_monitor"],
    "usesCleartextTraffic": ["android_network_monitor"],
    "cleartext": ["android_network_monitor"],
    # Storage
    "SharedPreferences": ["android_storage_monitor"],
    "getSharedPreferences": ["android_storage_monitor"],
    "MODE_WORLD_READABLE": ["android_storage_monitor"],
    "allowBackup": ["android_backup_bypass"],
    # Exported
    "Exported": ["android_exported_components"],
    "exported": ["android_exported_components"],
    "intent-filter": ["android_exported_components"],
    # Cydia / Jailbreak
    "Cydia": ["ios_jailbreak_file_check"],
    "MobileSubstrate": ["ios_jailbreak_file_check"],
    "jailbreak": ["ios_jailbreak_file_check"],
    # Logging
    "Log.d": ["android_logging_monitor"],
    "Log.e": ["android_logging_monitor"],
    "Log.v": ["android_logging_monitor"],
    "System.out": ["android_logging_monitor"],
    # Debug
    "debuggable": ["android_debug_monitor"],
    "debug": ["android_debug_monitor"],
    # URL schemes
    "canOpenURL": ["ios_url_scheme_bypass"],
    "custom URL scheme": ["ios_url_scheme_bypass"],
}


class TFIDFIndex:
    """Pure-numpy TF-IDF vectorizer + cosine similarity search."""

    def __init__(self):
        self.vocab: Dict[str, int] = {}
        self.idf: Dict[str, float] = {}
        self.vectors = None

    def _tokenize(self, text: str) -> List[str]:
        """Lowercase, split on non-alphanumeric, filter short tokens."""
        tokens = re.findall(r'[a-z0-9_]{2,}', text.lower())
        # Add bigrams
        for i in range(len(tokens) - 1):
            tokens.append(f"{tokens[i]}_{tokens[i+1]}")
        return tokens

    def fit(self, documents: List[str]):
        """Build vocabulary and compute IDF weights."""
        import numpy as np

        n_docs = len(documents)
        doc_freq: Counter = Counter()
        all_tokens = []

        for doc in documents:
            tokens = self._tokenize(doc)
            all_tokens.append(tokens)
            unique = set(tokens)
            for t in unique:
                doc_freq[t] += 1

        self.vocab = {}
        for term, freq in doc_freq.items():
            if freq >= 1:
                self.vocab[term] = len(self.vocab)

        vocab_size = len(self.vocab)
        self.vectors = np.zeros((n_docs, vocab_size), dtype=np.float32)

        for term, idx in self.vocab.items():
            df = doc_freq.get(term, 0)
            self.idf[term] = math.log(n_docs / (df + 1)) + 1

        for i, tokens in enumerate(all_tokens):
            tf = Counter(tokens)
            max_tf = max(tf.values()) if tf else 1
            for term, count in tf.items():
                if term in self.vocab:
                    tf_val = 0.5 + 0.5 * (count / max_tf)
                    self.vectors[i, self.vocab[term]] = tf_val * self.idf[term]

            norm = np.linalg.norm(self.vectors[i])
            if norm > 0:
                self.vectors[i] /= norm

    def search(self, query: str, top_k: int = 20) -> List[Tuple[int, float]]:
        """Return (doc_index, score) pairs sorted by similarity."""
        import numpy as np

        tokens = self._tokenize(query)
        tf = Counter(tokens)

        query_vec = np.zeros(len(self.vocab), dtype=np.float32)
        max_tf = max(tf.values()) if tf else 1
        for term, count in tf.items():
            if term in self.vocab:
                tf_val = 0.5 + 0.5 * (count / max_tf)
                query_vec[self.vocab[term]] = tf_val * self.idf.get(term, 1.0)

        norm = np.linalg.norm(query_vec)
        if norm > 0:
            query_vec /= norm

        scores = self.vectors @ query_vec

        top_indices = np.argsort(scores)[::-1][:top_k]
        results = []
        for idx in top_indices:
            score = float(scores[idx])
            if score > 0.01:
                results.append((int(idx), score))
        return results


class FridaAIGenerator:
    """
    Enhanced AI-powered Frida script generator.

    Only generates scripts for FAIL and WARNING scan results.
    Uses direct MSTG test_id mapping + TF-IDF for comprehensive coverage.
    """

    def __init__(self, knowledge_base: list = None):
        from core.ai.frida_knowledge_base import KNOWLEDGE_BASE, CATEGORIES

        self.kb = knowledge_base or KNOWLEDGE_BASE
        self.categories = CATEGORIES
        self._build_index()
        self._build_id_lookup()

    def _build_index(self):
        """Build TF-IDF index from knowledge base entries."""
        self.documents = []
        self.doc_entries = []

        for entry in self.kb:
            doc_text = " ".join(entry.get("trigger_patterns", []))
            doc_text += " " + entry.get("description", "")
            doc_text += " " + entry.get("category", "").replace("_", " ")
            doc_text += " " + entry.get("subcategory", "").replace("_", " ")
            doc_text += " " + " ".join(entry.get("references", []))
            self.documents.append(doc_text)
            self.doc_entries.append(entry)

        self.index = TFIDFIndex()
        self.index.fit(self.documents)

    def _build_id_lookup(self):
        """Build a quick lookup from script_id → entry."""
        self.id_to_entry = {}
        for entry in self.kb:
            self.id_to_entry[entry["id"]] = entry

    def _filter_actionable_results(self, scan_results: List[Dict]) -> List[Dict]:
        """
        Filter scan results to only FAIL and WARNING.
        These are the only ones that indicate actual issues found in the app.
        PASS = app doesn't have this issue → no script needed.
        INFO = informational only → no script needed.
        """
        actionable = []
        for r in scan_results:
            status = r.get("status", "").upper()
            if status in ("FAIL", "WARNING"):
                actionable.append(r)
        return actionable

    def _extract_evidence_text(self, result: Dict) -> str:
        """Extract meaningful text from a single scan result's evidence."""
        parts = []
        evidence = result.get("evidence", [])

        if isinstance(evidence, list):
            for e in evidence:
                parts.append(str(e))
        elif evidence:
            parts.append(str(evidence))

        # Also include details
        details = result.get("details", "")
        if isinstance(details, list):
            parts.extend(str(d) for d in details)
        elif details:
            parts.append(str(details))

        text = " ".join(parts)

        # Extract class names (com.example.ClassName)
        classes = re.findall(r'[a-z]+[\w]*(?:\.[a-z]+[\w]*)*\.[A-Z][a-zA-Z]+', text)
        parts.extend(classes)

        # Extract file paths
        paths = re.findall(r'/[\w/.-]+', text)
        parts.extend(paths)

        # Extract quoted strings
        strings = re.findall(r'["\']([^"\']{3,})["\']', text)
        parts.extend(strings)

        return " ".join(parts)

    def _direct_id_match(self, scan_results: List[Dict]) -> Dict[str, List[Dict]]:
        """
        Phase 1: Direct test_id → script mapping.
        Returns {script_id: [triggering_results]} for exact matches.
        """
        matches = {}  # script_id → list of (result, priority)

        for result in scan_results:
            test_id = result.get("test_id", "").strip()
            status = result.get("status", "").upper()

            # Normalize test_id (MSTG-CODE-8 vs MSTG-CODE-08)
            normalized_id = test_id
            if not re.search(r'-\d{2}$', test_id) and re.search(r'-\d$', test_id):
                normalized_id = test_id[:-1] + "0" + test_id[-1]

            if normalized_id in MSTG_TO_SCRIPTS:
                for script_id in MSTG_TO_SCRIPTS[normalized_id]:
                    if script_id not in matches:
                        matches[script_id] = []
                    matches[script_id].append(result)

            # Also check original ID
            if test_id in MSTG_TO_SCRIPTS and test_id != normalized_id:
                for script_id in MSTG_TO_SCRIPTS[test_id]:
                    if script_id not in matches:
                        matches[script_id] = []
                    matches[script_id].append(result)

        return matches

    def _evidence_match(self, scan_results: List[Dict]) -> Dict[str, List[Dict]]:
        """
        Phase 2: Evidence-based pattern matching.
        Scans evidence text for specific indicators.
        """
        matches = {}  # script_id → list of results

        for result in scan_results:
            evidence_text = self._extract_evidence_text(result).lower()

            for pattern, script_ids in EVIDENCE_TO_SCRIPTS.items():
                if pattern.lower() in evidence_text:
                    for script_id in script_ids:
                        if script_id not in matches:
                            matches[script_id] = []
                        if result not in matches[script_id]:
                            matches[script_id].append(result)

        return matches

    def _tfidf_match(self, findings_text: str, platform: str = None,
                      threshold: float = 0.05) -> List[Tuple[Dict, float, List[str]]]:
        """
        Phase 3: TF-IDF similarity search (supplementary).
        Catches patterns not covered by direct or evidence matching.
        """
        results = self.index.search(findings_text, top_k=20)

        scored = []
        for idx, score in results:
            entry = self.doc_entries[idx]
            if platform and entry.get("platform", "both") not in (platform, "both"):
                continue
            if score >= threshold:
                matched = [p for p in entry.get("trigger_patterns", [])
                           if p.lower() in findings_text.lower()]
                scored.append((entry, score, matched))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored

    def generate(self, scan_results: List[Dict], platform: str = "android",
                 categories: List[str] = None, min_confidence: float = 0.10,
                 max_scripts: int = 20) -> List[GeneratedScript]:
        """
        Generate Frida scripts based ONLY on scan results with issues.

        Process:
        1. Filter to FAIL and WARNING results only
        2. Direct test_id mapping (highest confidence)
        3. Evidence pattern matching (high confidence)
        4. TF-IDF supplementary matching (boosts existing or adds new)
        5. Merge, deduplicate, rank by confidence
        """
        # Step 1: Filter to actionable results only
        actionable = self._filter_actionable_results(scan_results)
        if not actionable:
            return []

        # Step 2: Direct test_id matching
        direct_matches = self._direct_id_match(actionable)

        # Step 3: Evidence pattern matching
        evidence_matches = self._evidence_match(actionable)

        # Step 4: TF-IDF matching on extracted findings
        all_findings = []
        for result in actionable:
            all_findings.append(self._extract_evidence_text(result))
        findings_text = " ".join(all_findings)

        tfidf_matches = {}
        if findings_text.strip():
            for entry, score, patterns in self._tfidf_match(findings_text, platform):
                eid = entry["id"]
                if eid not in tfidf_matches:
                    tfidf_matches[eid] = (entry, score, patterns)

        # Step 5: Merge all matches with combined confidence
        combined = {}  # script_id → {entry, confidence, triggered_by, patterns}

        for script_id, triggering_results in direct_matches.items():
            if script_id not in self.id_to_entry:
                continue
            entry = self.id_to_entry[script_id]
            if platform and entry.get("platform", "both") not in (platform, "both"):
                continue

            # Count FAIL vs WARNING triggers
            fail_count = sum(1 for r in triggering_results if r.get("status") == "FAIL")
            warn_count = sum(1 for r in triggering_results if r.get("status") == "WARNING")

            # FAIL triggers get higher confidence
            confidence = min(0.6 + (fail_count * 0.2) + (warn_count * 0.05), 1.0)

            combined[script_id] = {
                "entry": entry,
                "confidence": confidence,
                "triggered_by": [r.get("test_id", "") for r in triggering_results],
                "patterns": [],
                "match_type": "direct",
                "severity": "FAIL" if fail_count > 0 else "WARNING",
            }

        for script_id, triggering_results in evidence_matches.items():
            if script_id not in self.id_to_entry:
                continue
            entry = self.id_to_entry[script_id]
            if platform and entry.get("platform", "both") not in (platform, "both"):
                continue

            fail_count = sum(1 for r in triggering_results if r.get("status") == "FAIL")
            warn_count = sum(1 for r in triggering_results if r.get("status") == "WARNING")

            evidence_confidence = min(0.4 + (fail_count * 0.15) + (warn_count * 0.05), 0.9)

            if script_id in combined:
                # Boost existing entry
                existing = combined[script_id]
                existing["confidence"] = min(
                    max(existing["confidence"], evidence_confidence) + 0.1, 1.0
                )
                existing["patterns"] = list(set(
                    existing["patterns"] + [r.get("test_id", "") for r in triggering_results]
                ))
                if fail_count > 0:
                    existing["severity"] = "FAIL"
            else:
                combined[script_id] = {
                    "entry": entry,
                    "confidence": evidence_confidence,
                    "triggered_by": [r.get("test_id", "") for r in triggering_results],
                    "patterns": [],
                    "match_type": "evidence",
                    "severity": "FAIL" if fail_count > 0 else "WARNING",
                }

        for script_id, (entry, tfidf_score, patterns) in tfidf_matches.items():
            if platform and entry.get("platform", "both") not in (platform, "both"):
                continue

            tfidf_confidence = min(tfidf_score * 1.5, 0.8)

            if script_id in combined:
                existing = combined[script_id]
                existing["confidence"] = min(existing["confidence"] + 0.05, 1.0)
                existing["patterns"] = list(set(existing["patterns"] + patterns))
            else:
                # Only add TF-IDF matches if confidence is high enough
                if tfidf_confidence >= 0.15:
                    combined[script_id] = {
                        "entry": entry,
                        "confidence": tfidf_confidence,
                        "triggered_by": [],
                        "patterns": patterns,
                        "match_type": "tfidf",
                        "severity": "WARNING",
                    }

        # Step 6: Filter by minimum confidence and category, then sort
        generated = []
        seen = set()

        # Sort by confidence descending, FAIL severity first
        items = sorted(
            combined.items(),
            key=lambda x: (
                1 if x[1]["severity"] == "FAIL" else 0,
                x[1]["confidence"]
            ),
            reverse=True
        )

        for script_id, info in items:
            if len(generated) >= max_scripts:
                break
            if info["confidence"] < min_confidence:
                continue

            entry = info["entry"]
            cat = entry.get("category", "")
            if categories and cat not in categories:
                continue

            dedup = f"{cat}_{entry.get('subcategory', '')}"
            if dedup in seen:
                # If higher confidence, replace
                for g in generated:
                    if f"{g.category}_{g.script_id.replace(cat + '_', '')}" == dedup:
                        if info["confidence"] > g.confidence:
                            generated.remove(g)
                            seen.discard(dedup)
                            break
                else:
                    continue
            seen.add(dedup)

            generated.append(GeneratedScript(
                script_id=entry["id"],
                category=cat,
                name=self.categories.get(cat, {}).get("name", cat),
                description=entry.get("description", ""),
                platform=entry.get("platform", "both"),
                confidence=info["confidence"],
                script_code=entry.get("frida_script", "").strip(),
                matched_patterns=info["patterns"],
                references=entry.get("references", []),
                sources=[entry["id"]],
                triggered_by=info["triggered_by"],
                severity=info["severity"],
            ))

        return generated

    def generate_combined_script(self, scan_results: List[Dict], platform: str = "android",
                                  categories: List[str] = None) -> str:
        """Generate a single combined Frida script with all relevant bypasses."""
        scripts = self.generate(scan_results, platform, categories)

        if not scripts:
            return (
                "// No applicable bypass scripts found for this scan.\n"
                "// All tested protections either passed or were not present.\n"
                "// Review scan results manually if dynamic testing is needed."
            )

        now = __import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        fail_count = sum(1 for s in scripts if s.severity == "FAIL")
        warn_count = sum(1 for s in scripts if s.severity == "WARNING")

        lines = []
        lines.append("/**")
        lines.append(" * MobiScan AI-Generated Frida Script")
        lines.append(f" * Platform: {platform.title()}")
        lines.append(f" * Generated: {now}")
        lines.append(f" * Modules: {len(scripts)} ({fail_count} critical, {warn_count} advisory)")
        lines.append(f" * Categories: {', '.join(set(s.name for s in scripts))}")
        lines.append(" *")
        lines.append(" * This script is auto-generated based on actual scan findings.")
        lines.append(" * Only includes bypasses for issues detected in the app.")
        lines.append(" *")
        lines.append(" * Usage:")
        lines.append(" *   frida -U -f <package_name> -l mobiscan_frida.js --no-pause")
        lines.append(" *")
        lines.append(" * WARNING: For authorized security testing only!")
        lines.append(" */")
        lines.append("")
        lines.append("if (Java.available) {")
        lines.append("    console.log('[MobiScan] Android Frida script loaded');")
        lines.append(f"    console.log('[MobiScan] Modules: {len(scripts)}');")
        lines.append("} else if (ObjC.available) {")
        lines.append("    console.log('[MobiScan] iOS Frida script loaded');")
        lines.append(f"    console.log('[MobiScan] Modules: {len(scripts)}');")
        lines.append("}")
        lines.append("")

        for i, s in enumerate(scripts):
            severity_marker = "CRITICAL" if s.severity == "FAIL" else "ADVISORY"
            lines.append(f"// {'='*60}")
            lines.append(f"// Module {i+1}: {s.name} [{severity_marker}]")
            lines.append(f"// Confidence: {s.confidence:.0%} | Platform: {s.platform}")
            lines.append(f"// {s.description}")
            if s.triggered_by:
                lines.append(f"// Triggered by: {', '.join(s.triggered_by)}")
            if s.matched_patterns:
                lines.append(f"// Evidence: {', '.join(s.matched_patterns[:5])}")
            if s.references:
                lines.append(f"// OWASP: {', '.join(s.references)}")
            lines.append(f"// {'='*60}")
            lines.append("")
            lines.append(s.script_code)
            lines.append("")

        return "\n".join(lines)

    def get_stats(self) -> Dict:
        """Return statistics about the knowledge base."""
        cats = {}
        platforms = {"android": 0, "ios": 0, "both": 0}
        for entry in self.kb:
            cat = entry.get("category", "unknown")
            plat = entry.get("platform", "both")
            cats[cat] = cats.get(cat, 0) + 1
            platforms[plat] = platforms.get(plat, 0) + 1
        return {
            "total_scripts": len(self.kb),
            "categories": cats,
            "platforms": platforms,
            "category_details": self.categories,
        }


# Singleton
_generator_instance: Optional[FridaAIGenerator] = None


def get_generator() -> FridaAIGenerator:
    global _generator_instance
    if _generator_instance is None:
        _generator_instance = FridaAIGenerator()
    return _generator_instance
