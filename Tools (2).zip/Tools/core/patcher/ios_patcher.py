"""
IPA Patcher - iOS IPA patching for non-jailbroken device testing.
Supports dylib injection, plist modification, and re-signing.
"""
import os
import json
import shutil
import zipfile
import tempfile
import plistlib
import time
from pathlib import Path
from typing import Dict, List
from dataclasses import dataclass, field


@dataclass
class IosPatchOption:
    id: str
    name: str
    description: str
    category: str
    severity: str
    enabled: bool = False
    details: str = ""


@dataclass
class IosPatchResult:
    success: bool
    message: str
    patched_ipa_path: str = ""
    patches_applied: List[str] = field(default_factory=list)
    patches_failed: List[str] = field(default_factory=list)
    log: List[str] = field(default_factory=list)
    original_size: int = 0
    patched_size: int = 0


class IosPatcher:
    """
    Patches iOS IPA files for security testing on non-jailbroken devices.
    
    Features:
    - Modify Info.plist (bundle ID, version, etc.)
    - Patch entitlements for keychain access
    - Inject FridaGadget dylib for instrumentation
    - Re-sign with self-signed certificate
    - Remove ATS restrictions
    """

    # Patterns indicating security checks in the binary
    JAILBREAK_CHECK_PATTERNS = [
        b"/Applications/Cydia.app",
        b"/Library/MobileSubstrate",
        b"/usr/sbin/sshd",
        b"/usr/bin/sshd",
        b"/usr/bin/ssh",
        b"/etc/apt",
        b"/private/var/lib/apt/",
        b"URLsForClipboardboardTypes",
        b"sandbox_check",
    ]

    DEBUG_CHECK_PATTERNS = [
        b"isDebuggerPresent",
        b"getenv",
        b"ptrace",
        b"PTRACE_TRACEME",
    ]

    PATCH_CATEGORIES = {
        "bypass_jailbreak_detection": {
            "name": "Jailbreak Detection Bypass",
            "description": "Neutralize jailbreak detection checks (Cydia, MobileSubstrate, filesystem probes).",
            "category": "Resilience",
            "severity": "High",
        },
        "bypass_ats": {
            "name": "ATS Bypass (Allow HTTP)",
            "description": "Disable App Transport Security to allow HTTP traffic interception.",
            "category": "Network",
            "severity": "High",
        },
        "inject_frida_gadget": {
            "name": "Inject FridaGadget",
            "description": "Inject FridaGadget.dylib for dynamic instrumentation without jailbreak.",
            "category": "Resilience",
            "severity": "High",
        },
        "modify_bundle_id": {
            "name": "Change Bundle Identifier",
            "description": "Change the bundle ID to install alongside the original app.",
            "category": "Platform",
            "severity": "Low",
        },
        "bypass_debugger_detection": {
            "name": "Debugger Detection Bypass",
            "description": "Remove debugger detection checks.",
            "category": "Code Quality",
            "severity": "Medium",
        },
        "enable_keychain_access": {
            "name": "Enable Keychain Sharing",
            "description": "Add keychain-access-groups entitlement for keychain data extraction.",
            "category": "Storage",
            "severity": "High",
        },
    }

    def __init__(self, upload_dir: str = None):
        self.upload_dir = Path(upload_dir) if upload_dir else Path("uploads/patched")
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir = None

    def get_patch_options(self, ipa_path: str) -> List[IosPatchOption]:
        """Analyze IPA and return available patches."""
        options = []

        # Read binary content for pattern matching
        binary_content = b""
        plist_data = {}
        try:
            with zipfile.ZipFile(ipa_path, 'r') as zf:
                for name in zf.namelist():
                    if name.endswith('.app') and '/' not in name.replace('.app', '').split('/')[-1]:
                        continue
                    if name.endswith('.app'):
                        app_dir = name
                        # Read Info.plist
                        plist_path = f"{app_dir}/Info.plist"
                        if plist_path in zf.namelist():
                            plist_data = plistlib.loads(zf.read(plist_path))
                        # Read main binary
                        binary_name = plist_data.get('CFBundleExecutable', '')
                        if binary_name:
                            binary_path = f"{app_dir}/{binary_name}"
                            if binary_path in zf.namelist():
                                binary_content = zf.read(binary_path)
                        break
        except Exception:
            pass

        for patch_id, info in self.PATCH_CATEGORIES.items():
            detected = False
            details = ""

            if patch_id == "bypass_jailbreak_detection":
                found = [p for p in self.JAILBREAK_CHECK_PATTERNS if p in binary_content]
                detected = len(found) > 0
                details = f"Found {len(found)} jailbreak detection indicators" if detected else "No jailbreak detection found"

            elif patch_id == "bypass_ats":
                ats = plist_data.get('NSAppTransportSecurity', {})
                nsallows = ats.get('NSAllowsArbitraryLoads', False)
                detected = not nsallows
                details = f"NSAllowsArbitraryLoads = {nsallows}" if ats else "No ATS configuration (restricted by default)"

            elif patch_id == "inject_frida_gadget":
                detected = True
                details = "FridaGadget.dylib injection available for this IPA"

            elif patch_id == "modify_bundle_id":
                detected = True
                bid = plist_data.get('CFBundleIdentifier', 'Unknown')
                details = f"Current bundle ID: {bid}"

            elif patch_id == "bypass_debugger_detection":
                found = [p for p in self.DEBUG_CHECK_PATTERNS if p in binary_content]
                detected = len(found) > 0
                details = f"Found {len(found)} debugger detection indicators" if detected else "No debugger detection found"

            elif patch_id == "enable_keychain_access":
                detected = True
                kc = plist_data.get('keychain-access-groups', [])
                details = f"Existing keychain groups: {kc}" if kc else "No keychain access groups configured"

            options.append(IosPatchOption(
                id=patch_id,
                name=info["name"],
                description=info["description"],
                category=info["category"],
                severity=info["severity"],
                enabled=detected,
                details=details,
            ))

        return options

    def patch_ipa(
        self,
        ipa_path: str,
        patches: Dict[str, bool],
        output_name: str = None,
        new_bundle_id: str = None,
    ) -> IosPatchResult:
        """Patch an IPA with selected options."""
        result = IosPatchResult(success=False, message="", log=[])
        ipa_path = Path(ipa_path)

        if not ipa_path.exists():
            result.message = "IPA file not found"
            return result

        result.original_size = ipa_path.stat().st_size
        result.log.append(f"Starting patch of: {ipa_path.name}")
        result.log.append(f"Original size: {self._format_size(result.original_size)}")

        self.temp_dir = Path(tempfile.mkdtemp(prefix="mobiscan_ios_patch_"))
        work_dir = self.temp_dir / "ipa_content"
        result.log.append(f"Working directory: {work_dir}")

        try:
            # Step 1: Extract IPA
            result.log.append("=" * 50)
            result.log.append("STEP 1: Extracting IPA...")
            work_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(ipa_path, 'r') as zf:
                zf.extractall(work_dir)

            # Find .app directory
            payload_dir = work_dir / "Payload"
            app_dir = None
            if payload_dir.exists():
                for item in payload_dir.iterdir():
                    if item.suffix == '.app' and item.is_dir():
                        app_dir = item
                        break

            if not app_dir:
                result.message = "No .app bundle found in IPA"
                return result

            result.log.append(f"Found app bundle: {app_dir.name}")

            # Step 2: Apply patches
            result.log.append("=" * 50)
            result.log.append("STEP 2: Applying patches...")

            enabled_patches = {k: v for k, v in patches.items() if v}

            for patch_id, enabled in enabled_patches.items():
                if not enabled:
                    continue
                result.log.append(f"\n--- Applying: {patch_id} ---")
                try:
                    self._apply_patch(patch_id, app_dir, result, new_bundle_id)
                    result.patches_applied.append(patch_id)
                except Exception as e:
                    result.log.append(f"FAILED: {patch_id}: {str(e)}")
                    result.patches_failed.append(patch_id)

            if not result.patches_applied:
                result.message = "No patches were applied"
                return result

            # Step 3: Remove existing signatures
            result.log.append("=" * 50)
            result.log.append("STEP 3: Removing existing code signature...")
            sc_dir = app_dir / "_CodeSignature"
            if sc_dir.exists():
                shutil.rmtree(sc_dir)
                result.log.append("  Removed _CodeSignature directory")

            embedded_provs = list(app_dir.glob("*.mobileprovision"))
            for p in embedded_provs:
                p.unlink()
                result.log.append(f"  Removed: {p.name}")

            # Remove BundleCompressedPayloadSize if present (causes issues)
            # Remove any watch/extensions that would need separate signing

            # Step 4: Signing note (actual signing done by Sideloadly/AltStore)
            result.log.append("=" * 50)
            result.log.append("STEP 4: Signing...")
            self._sign_ipa(work_dir, app_dir, result)

            # Step 5: Repack IPA
            result.log.append("=" * 50)
            result.log.append("STEP 5: Repacking IPA...")
            if not output_name:
                timestamp = int(time.time())
                output_name = f"patched_{timestamp}.ipa"

            output_path = self.upload_dir / output_name
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for root, dirs, files in os.walk(work_dir):
                    for file in sorted(files):
                        file_path = Path(root) / file
                        arcname = str(file_path.relative_to(work_dir))
                        zf.write(file_path, arcname)

            result.patched_ipa_path = str(output_path)
            result.patched_size = output_path.stat().st_size
            result.log.append(f"Patched IPA: {output_path.name} ({self._format_size(result.patched_size)})")

            result.success = True
            result.message = (
                f"Successfully applied {len(result.patches_applied)} patch(es) to {ipa_path.name}. "
                f"Use Sideloadly or AltStore to sign and install on your device."
            )

        except Exception as e:
            result.message = f"Patching failed: {str(e)}"
            result.log.append(f"ERROR: {str(e)}")
            import traceback
            result.log.append(traceback.format_exc())

        finally:
            try:
                if self.temp_dir and self.temp_dir.exists():
                    shutil.rmtree(self.temp_dir, ignore_errors=True)
            except Exception:
                pass

        return result

    def _apply_patch(self, patch_id: str, app_dir: Path, result: IosPatchResult, new_bundle_id: str = None):
        """Apply a specific patch."""
        if patch_id == "bypass_jailbreak_detection":
            self._patch_jailbreak_detection(app_dir, result)
        elif patch_id == "bypass_ats":
            self._patch_ats(app_dir, result)
        elif patch_id == "inject_frida_gadget":
            self._patch_inject_frida(app_dir, result)
        elif patch_id == "modify_bundle_id":
            self._patch_bundle_id(app_dir, result, new_bundle_id)
        elif patch_id == "bypass_debugger_detection":
            self._patch_debugger_detection(app_dir, result)
        elif patch_id == "enable_keychain_access":
            self._patch_keychain(app_dir, result)

    def _patch_jailbreak_detection(self, app_dir: Path, result: IosPatchResult):
        """Patch jailbreak detection in the app binary."""
        patched = 0
        plist = self._read_plist(app_dir)
        binary_name = plist.get('CFBundleExecutable', '')

        if not binary_name:
            result.log.append("  No executable found in Info.plist")
            return

        binary_path = app_dir / binary_name
        if not binary_path.exists():
            result.log.append(f"  Binary not found: {binary_name}")
            return

        original = binary_path.read_bytes()
        modified = bytearray(original)

        for pattern in self.JAILBREAK_CHECK_PATTERNS:
            idx = 0
            while True:
                idx = modified.find(pattern, idx)
                if idx == -1:
                    break
                # Null out the first byte to break the string comparison
                modified[idx] = 0x00
                patched += 1
                result.log.append(f"  Patched jailbreak string at 0x{idx:08x}: {pattern[:40]}")
                idx += len(pattern)

        if modified != original:
            binary_path.write_bytes(bytes(modified))
            result.log.append(f"  Jailbreak detection: {patched} patches applied")

    def _patch_ats(self, app_dir: Path, result: IosPatchResult):
        """Disable App Transport Security in Info.plist."""
        plist_path = app_dir / "Info.plist"
        if not plist_path.exists():
            result.log.append("  Info.plist not found")
            return

        plist = plistlib.loads(plist_path.read_bytes())

        ats = plist.get('NSAppTransportSecurity', {})
        ats['NSAllowsArbitraryLoads'] = True
        ats['NSExceptionDomains'] = {
            'localhost': {
                'NSExceptionAllowsInsecureHTTPLoads': True,
                'NSExceptionMinimumTLSVersion': '1.0',
            }
        }
        plist['NSAppTransportSecurity'] = ats

        plist_path.write_bytes(plistlib.dumps(plist))
        result.log.append("  ATS disabled: NSAllowsArbitraryLoads=true")

    def _patch_inject_frida(self, app_dir: Path, result: IosPatchResult):
        """Inject FridaGadget.dylib into the app."""
        import shutil as _shutil
        gadget_dir = Path("uploads/tools")
        gadget_dir.mkdir(parents=True, exist_ok=True)
        gadget_path = gadget_dir / "FridaGadget.dylib"

        # Auto-download FridaGadget if not present
        if not gadget_path.exists():
            result.log.append("  FridaGadget.dylib not found locally, downloading from GitHub...")
            try:
                import urllib.request, json, lzma
                url = "https://api.github.com/repos/frida/frida/releases/latest"
                req = urllib.request.Request(url, headers={"User-Agent": "MobiScan"})
                data = json.loads(urllib.request.urlopen(req, timeout=15).read())
                version = data.get("tag_name", "unknown")
                result.log.append(f"  Latest Frida version: {version}")
                for asset in data.get("assets", []):
                    if asset["name"] == f"frida-gadget-{version}-ios-universal.dylib.xz":
                        dl_req = urllib.request.Request(asset["browser_download_url"], headers={"User-Agent": "MobiScan"})
                        compressed = urllib.request.urlopen(dl_req, timeout=120).read()
                        decompressed = lzma.decompress(compressed)
                        gadget_path.write_bytes(decompressed)
                        result.log.append(f"  Downloaded FridaGadget.dylib ({len(decompressed):,} bytes)")
                        break
                else:
                    result.log.append("  Could not find iOS FridaGadget in release assets")
                    return
            except Exception as e:
                result.log.append(f"  Download failed: {e}")
                return

        # Copy FridaGadget.dylib into app bundle
        dest = app_dir / "FridaGadget.dylib"
        _shutil.copy2(str(gadget_path), str(dest))
        result.log.append(f"  Copied FridaGadget.dylib to app bundle ({dest.stat().st_size:,} bytes)")

        # Inject LC_LOAD_DYLIB into the main binary using LIEF
        plist = self._read_plist(app_dir)
        binary_name = plist.get("CFBundleExecutable", "")
        if not binary_name:
            result.log.append("  No CFBundleExecutable in Info.plist")
            return

        binary_path = app_dir / binary_name
        if not binary_path.exists():
            result.log.append(f"  Binary not found: {binary_name}")
            return

        try:
            import lief
            macho = lief.parse(str(binary_path))
            if macho is None:
                result.log.append("  LIEF: Failed to parse Mach-O binary")
                return

            dylib_path = "@executable_path/FridaGadget.dylib"
            already_has = False
            for cmd in macho.commands:
                if hasattr(cmd, "command") and str(cmd.command) == "LOAD_DYLIB":
                    if hasattr(cmd, "name") and "FridaGadget" in str(cmd.name):
                        already_has = True
                        break

            if already_has:
                result.log.append("  FridaGadget.dylib already loaded in binary")
                return

            try:
                macho.add_library(dylib_path)
                result.log.append(f"  Injected LC_LOAD_DYLIB: {dylib_path}")
            except Exception as e:
                result.log.append(f"  LIEF add_library failed: {e}")
                result.log.append("  FridaGadget.dylib copied but load command not injected")
                result.log.append("  Use optool on macOS: optool install -c load -p @executable_path/FridaGadget.dylib -t <binary>")

        except ImportError:
            result.log.append("  LIEF not installed. pip install lief")
            result.log.append("  FridaGadget.dylib copied but not injected into binary")
        except Exception as e:
            result.log.append(f"  Mach-O injection error: {e}")

        plist["_FridaGadgetInjected"] = True
        app_dir.joinpath("Info.plist").write_bytes(plistlib.dumps(plist))

    def _patch_bundle_id(self, app_dir: Path, result: IosPatchResult, new_bundle_id: str = None):
        """Change the bundle identifier."""
        plist_path = app_dir / "Info.plist"
        if not plist_path.exists():
            return

        plist = plistlib.loads(plist_path.read_bytes())
        old_bid = plist.get('CFBundleIdentifier', 'Unknown')

        if new_bundle_id:
            plist['CFBundleIdentifier'] = new_bundle_id
        else:
            # Append '.patched' to the existing bundle ID
            plist['CFBundleIdentifier'] = f"{old_bid}.patched"

        plist_path.write_bytes(plistlib.dumps(plist))
        result.log.append(f"  Bundle ID: {old_bid} -> {plist['CFBundleIdentifier']}")

    def _patch_debugger_detection(self, app_dir: Path, result: IosPatchResult):
        """Patch debugger detection in binary."""
        patched = 0
        plist = self._read_plist(app_dir)
        binary_name = plist.get('CFBundleExecutable', '')

        if not binary_name:
            return

        binary_path = app_dir / binary_name
        if not binary_path.exists():
            return

        original = binary_path.read_bytes()
        modified = bytearray(original)

        for pattern in self.DEBUG_CHECK_PATTERNS:
            idx = 0
            while True:
                idx = modified.find(pattern, idx)
                if idx == -1:
                    break
                modified[idx] = 0x00
                patched += 1
                idx += len(pattern)

        if modified != original:
            binary_path.write_bytes(bytes(modified))
            result.log.append(f"  Debugger detection: {patched} patches applied")

    def _patch_keychain(self, app_dir: Path, result: IosPatchResult):
        """Add keychain-access-groups to entitlements."""
        plist = self._read_plist(app_dir)
        entitlements_path = app_dir / f"{plist.get('CFBundleExecutable', '')}.entitlements"

        if not entitlements_path.exists():
            # Create basic entitlements
            entitlements = {
                'keychain-access-groups': [
                    f"{plist.get('CFBundleIdentifier', '*')}.keychain",
                ]
            }
            plistlib.dump(entitlements, open(entitlements_path, 'wb'))
            result.log.append(f"  Created: {entitlements_path.name}")
        else:
            ent = plistlib.loads(entitlements_path.read_bytes())
            kc = ent.get('keychain-access-groups', [])
            bid = plist.get('CFBundleIdentifier', '*')
            if f"{bid}.keychain" not in kc:
                kc.append(f"{bid}.keychain")
                ent['keychain-access-groups'] = kc
                plistlib.dump(ent, open(entitlements_path, 'wb'))
            result.log.append(f"  Keychain groups: {kc}")

    def _sign_ipa(self, work_dir: Path, app_dir: Path, result: IosPatchResult):
        """Skip on-server signing. Sideloadly/AltStore handles re-signing."""
        result.log.append("  Signing handled by Sideloadly / AltStore (not on server)")
        result.log.append("")
        result.log.append("  ━━━ Install the patched IPA ━━━")
        result.log.append("")
        result.log.append("  1. Open Sideloadly (sideloadly.io) or AltStore (altstore.io)")
        result.log.append("  2. Connect your iPhone via USB")
        result.log.append("  3. Drag this patched IPA into the tool")
        result.log.append("  4. Enter your Apple ID -> Start / Install")
        result.log.append("")
        result.log.append("  The tool re-signs the app with your Apple ID certificate.")
        result.log.append("  Free Apple IDs: expires after 7 days. Developer account: 1 year.")



    def _read_plist(self, app_dir: Path) -> dict:
        """Read Info.plist from app bundle."""
        plist_path = app_dir / "Info.plist"
        if plist_path.exists():
            return plistlib.loads(plist_path.read_bytes())
        return {}

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        for unit in ["B", "KB", "MB", "GB"]:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} TB"
