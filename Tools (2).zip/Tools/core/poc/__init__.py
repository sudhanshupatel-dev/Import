"""
PoC Generator Module
Dynamically generates app-specific tapjacking and task hijacking PoC APKs
based on scan results.
"""
from core.poc.generator import PoCGenerator

__all__ = ['PoCGenerator']
