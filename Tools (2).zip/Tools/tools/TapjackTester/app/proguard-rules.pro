# TapjackTester ProGuard Rules
# Keep all classes for debugging/testing
-keep class com.mobiscan.tapjacktester.** { *; }
-keepclassmembers class com.mobiscan.tapjacktester.** { *; }
