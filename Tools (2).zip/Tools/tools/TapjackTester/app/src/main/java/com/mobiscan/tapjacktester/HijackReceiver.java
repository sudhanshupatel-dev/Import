package com.mobiscan.tapjacktester;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Broadcast receiver for triggering task hijack attacks remotely.
 * Can be triggered via:
 *   adb shell am broadcast -a com.mobiscan.HIJACK_TRIGGER --es target <package>
 */
public class HijackReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String target = intent.getStringExtra("target");
        String action = intent.getStringExtra("action");

        if (target == null) target = "com.example.app";
        if (action == null) action = "hijack";

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.putExtra("target_package", target);
        launchIntent.putExtra("attack_action", action);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launchIntent);
    }
}
