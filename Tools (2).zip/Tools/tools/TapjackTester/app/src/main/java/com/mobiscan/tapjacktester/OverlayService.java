package com.mobiscan.tapjacktester;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;

/**
 * Persistent overlay service - TYPE_SYSTEM_ALERT.
 * Used by TJ-03 for system alert window tapjacking test.
 * Runs as a foreground service to persist across app switches.
 */
public class OverlayService extends Service {

    private static final String CHANNEL_ID = "tapjack_overlay";
    private static final int NOTIFICATION_ID = 9999;

    private WindowManager windowManager;
    private View overlayView;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String mode = intent != null ? intent.getStringExtra("mode") : "system_alert";

        // Create notification channel (required for Android O+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Overlay Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Tapjacking overlay test service");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }

        // Start foreground service
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
                .setContentTitle("TapjackTester")
                .setContentText("Overlay test active")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .build();

        startForeground(NOTIFICATION_ID, notification);

        // Create overlay
        createOverlay();

        return START_NOT_STICKY;
    }

    private void createOverlay() {
        try {
            overlayView = new LinearLayout(this);
            ((LinearLayout) overlayView).setBackgroundColor(0x01000000);
            overlayView.setAlpha(0.01f);

            // Capture touches but let them pass through
            overlayView.setOnTouchListener((v, event) -> {
                // Log touch coordinates
                float x = event.getRawX();
                float y = event.getRawY();
                int action = event.getAction();
                // Touch logged — passes through to underlying app
                return false;
            });

            int type;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                @SuppressWarnings("deprecation")
                int t = WindowManager.LayoutParams.TYPE_PHONE;
                type = t;
            }

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.START;

            windowManager.addView(overlayView, params);

        } catch (Exception e) {
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayView != null && windowManager != null) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception ignored) {}
        }
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
