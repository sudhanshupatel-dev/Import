# 🎯 MobiScan Tapjack & Task Hijack Tester

**Advanced Mobile Security Testing Tool** for verifying OWASP MSTG-PLATFORM-4 (Tapjacking) and MSTG-PLATFORM-5 (Task Hijacking) vulnerabilities.

## ⚠️ WARNING

This tool is for **authorized security testing only**. Only test apps you have written permission to test. Unauthorized testing is illegal.

---

## Features

### 20 Attack Tests

| ID | Attack | Category | Severity |
|----|--------|----------|----------|
| TJ-01 | Invisible Overlay Attack | Tapjacking | Critical |
| TJ-02 | Fake Login Overlay | Tapjacking | Critical |
| TJ-03 | System Alert Window Overlay | Tapjacking | High |
| TJ-04 | Partial Screen Overlay | Tapjacking | Critical |
| TJ-05 | Dialog Overlay Attack | Tapjacking | High |
| TJ-06 | WebView Overlay Injection | Tapjacking | Critical |
| TJ-07 | Rapid Overlay Toggle | Tapjacking | Medium |
| TJ-08 | Multi-Layer Overlay | Tapjacking | Medium |
| TH-01 | allowTaskReparenting Exploit | Task Hijacking | Critical |
| TH-02 | Login Activity Hijack | Task Hijacking | Critical |
| TH-03 | Document Mode Abuse | Task Hijacking | High |
| TH-04 | Cross-Task Intent Injection | Task Hijacking | High |
| TH-05 | Recent Task Hijack | Task Hijacking | High |
| TH-06 | Credential Harvest via Task | Task Hijacking | Critical |
| TH-07 | Activity Lifecycle Exploit | Task Hijacking | Medium |
| TH-08 | Background Task Launch | Task Hijacking | High |
| ADV-01 | Overlay + Task Reparent Combo | Advanced | Critical |
| ADV-02 | Cross-App Tapjacking Chain | Advanced | High |
| ADV-03 | Deep Link Task Injection | Advanced | High |
| ADV-04 | Permission Bridge Attack | Advanced | Critical |

---

## How to Build

### Option 1: Android Studio
1. Open Android Studio
2. File → Open → Select `TapjackTester/` folder
3. Wait for Gradle sync
4. Build → Build APK(s)
5. APK will be at `app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Command Line (requires Android SDK)
```bash
cd TapjackTester

# Set SDK path if not already set
export ANDROID_HOME=/path/to/android/sdk

# Build debug APK
./gradlew assembleDebug

# APK output: app/build/outputs/apk/debug/app-debug.apk
```

### Option 3: Without Android Studio
1. Download Android command-line tools
2. Install build-tools and platform (API 34)
3. Run `gradlew assembleDebug`

---

## How to Use

### 1. Install on Device
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 2. Grant Permissions
- Open the app
- When prompted, grant **Overlay Permission** (SYSTEM_ALERT_WINDOW)
- This is required for overlay-based attacks

### 3. Enter Target Package
- Type the target app's package name (e.g., `com.example.bankapp`)
- Tap **🔍 Scan** to analyze the target

### 4. Run Tests
- Tap **🚀 RUN ALL 20 ATTACKS** to run everything
- Or tap individual test items to run specific tests
- Watch the log panel for real-time results

### 5. Review Results
- 🔴 **VULNERABLE** — Target is susceptible to this attack
- 🟢 **SAFE** — Target has protection against this attack
- ⚠️ **ERROR** — Test could not be completed

---

## What It Tests

### Tapjacking (MSTG-PLATFORM-4)
- **filterTouchesWhenObscured**: Checks if the target app sets this flag on sensitive views
- **Overlay detection**: Tests if the target detects transparent overlays
- **Touch event interception**: Verifies if touches pass through to the underlying app
- **WebView overlay injection**: Injects a transparent WebView to intercept JavaScript bridge calls
- **Rapid toggle bypass**: Tests timing-based overlay detection bypass
- **Multi-layer overlay**: Stacks multiple overlays to bypass single-layer detection

### Task Hijacking (MSTG-PLATFORM-5)
- **allowTaskReparenting**: Checks if target activities can be reparented to attacker's task
- **Activity launch mode**: Tests launch modes that create exploitable task instances
- **Document mode abuse**: Exploits documentLaunchMode to create shadow task instances
- **Cross-task intent injection**: Launches target activities with hijacking flags
- **Recent task hijack**: Manipulates the recents screen to swap tasks
- **Credential harvest**: Combines task reparenting with credential capture
- **Lifecycle exploit**: Exploits onPause/onStop transitions
- **Background launch**: Launches target activities from background

### Advanced Attacks
- **Overlay + Task combo**: Combines both attack vectors for maximum impact
- **Cross-app chain**: Chains tapjacking across multiple exported activities
- **Deep link injection**: Uses deep links to inject activities into task stack
- **Permission bridge**: Escalates permissions via task reparenting

---

## Detection Methods

The tester uses these techniques to verify vulnerabilities:

1. **Static Analysis**: Checks package manager for task flags, permissions, export settings
2. **Dynamic Analysis**: Actually launches overlay windows and monitors touch events
3. **Lifecycle Monitoring**: Tracks activity state changes during attacks
4. **Task Stack Inspection**: Examines recent tasks for hijackable entries
5. **Intent Resolution**: Tests all exported activities with hijacking intent flags

---

## Mitigation Guide

If your app is found vulnerable, here are the fixes:

### Tapjacking Fixes
```xml
<!-- Add to all sensitive views in XML -->
android:filterTouchesWhenObscured="true"
```
```java
// Or programmatically
view.setFilterTouchesWhenObscured(true);

// Detect overlays
view.setOnTouchListener((v, event) -> {
    if ((event.getFlags() & MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0) {
        // Touch is obscured — reject it
        return true;
    }
    return false;
});
```

### Task Hijacking Fixes
```xml
<!-- In AndroidManifest.xml for sensitive activities -->
<activity
    android:name=".LoginActivity"
    android:launchMode="singleTask"
    android:taskAffinity=""
    android:allowTaskReparenting="false"
    android:excludeFromRecents="true"
    android:documentLaunchMode="never" />
```
```java
// Validate task context
@Override
protected void onResume() {
    super.onResume();
    if (getTaskId() != mExpectedTaskId) {
        // Task was hijacked — finish the activity
        finish();
    }
}

// Validate calling package
String caller = getCallingPackage();
if (caller == null || !caller.equals(EXPECTED_PACKAGE)) {
    finish();
}
```

---

## Requirements

- Android 7.0+ (API 24)
- SYSTEM_ALERT_WINDOW permission (granted by user)
- Target app must be installed on same device

## Tech Stack

- Pure Java — no external dependencies
- Android SDK only
- Min SDK 24, Target SDK 34

---

## OWASP References

- [MSTG-PLATFORM-4: Testing for Tapjacking](https://mas.owasp.org/mstg/0x09h-Testing-Platform-Apps/)
- [MSTG-PLATFORM-5: Testing for Overlay Attacks](https://mas.owasp.org/mstg/0x09h-Testing-Platform-Apps/)
- [OWASP Mobile Security Testing Guide](https://mas.owasp.org/)
- [CWE-353: Missing Support for Integrity Check](https://cwe.mitre.org/data/definitions/353.html)
- [CWE-1021: Improper Restriction of Rendered UI Layers](https://cwe.mitre.org/data/definitions/1021.html)
