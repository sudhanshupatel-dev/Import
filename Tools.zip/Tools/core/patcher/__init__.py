"""
MobiScan Patcher Module
Pure Python APK/IPA patching for non-rooted/non-jailbroken device testing.
No apktool or Java required — uses androguard + cryptography.
"""
