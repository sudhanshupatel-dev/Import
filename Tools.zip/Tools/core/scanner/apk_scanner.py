"""
APK Static Analysis Scanner - Enhanced
Performs comprehensive OWASP MASTG static analysis on Android APKs.
Uses androguard for rich metadata when available.
Collects detailed evidence for every finding.
"""
import os
import re
import hashlib
import zipfile
import json
from pathlib import Path
from typing import Dict, List
from dataclasses import dataclass, field, asdict


@dataclass
class ScanResult:
    test_id: str
    test_name: str
    category: str
    severity: str
    status: str  # PASS, FAIL, WARNING, INFO
    description: str
    details: str
    recommendation: str
    evidence: list = field(default_factory=list)
    refs: list = field(default_factory=list)


class ApkScanner:
    """Scans Android APK files for OWASP MASTG violations."""

    DANGEROUS_PERMISSIONS = [
        "android.permission.READ_SMS", "android.permission.SEND_SMS",
        "android.permission.RECEIVE_SMS", "android.permission.READ_CONTACTS",
        "android.permission.READ_CALL_LOG", "android.permission.WRITE_CALL_LOG",
        "android.permission.CAMERA", "android.permission.RECORD_AUDIO",
        "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.READ_PHONE_STATE", "android.permission.READ_PHONE_NUMBERS",
        "android.permission.CALL_PHONE", "android.permission.PROCESS_OUTGOING_CALLS",
        "android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR",
        "android.permission.BODY_SENSORS", "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.POST_NOTIFICATIONS", "android.permission.NEARBY_WIFI_DEVICES",
    ]

    SENSITIVE_DATA_PATTERNS = [
        (r'(?:password|passwd|pwd)\s*[:=]\s*["\'][^"\']+["\']', "Hardcoded password"),
        (r'(?:api[_-]?key|apikey)\s*[:=]\s*["\'][^"\']+["\']', "Hardcoded API key"),
        (r'(?:secret|secret[_-]?key)\s*[:=]\s*["\'][^"\']+["\']', "Hardcoded secret"),
        (r'(?:access[_-]?token|auth[_-]?token)\s*[:=]\s*["\'][^"\']+["\']', "Hardcoded access token"),
        (r'(?:private[_-]?key)\s*[:=]\s*["\'][^"\']+["\']', "Hardcoded private key"),
        (r'(?:aws[_-]?access[_-]?key[_-]?id)\s*[:=]\s*["\'][^"\']+["\']', "AWS access key"),
        (r'(?:firebase[_-]?key|gcm[_-]?key)\s*[:=]\s*["\'][^"\']+["\']', "Firebase/GCM key"),
        (r'(?:client[_-]?secret)\s*[:=]\s*["\'][^"\']+["\']', "OAuth client secret"),
        (r'(?:encryption[_-]?key)\s*[:=]\s*["\'][^"\']+["\']', "Hardcoded encryption key"),
        (r'(?:jdbc|mysql|mongodb|redis|postgres)://[^\s"\']+', "Hardcoded database connection"),
    ]

    LOG_METHODS = ["Log.v", "Log.d", "Log.i", "Log.w", "Log.e"]

    def __init__(self):
        self.results: List[ScanResult] = []
        self.detections = {}
        self.apk = None

    def scan(self, apk_path: str) -> Dict:
        """Main scan entry point."""
        self.results = []
        self.detections = {}
        apk_path = Path(apk_path)

        if not apk_path.exists():
            return {"error": "APK file not found"}

        # Try androguard first
        try:
            from androguard.misc import AnalyzeAPK
            self.apk, self.dalvik, self.dex = AnalyzeAPK(str(apk_path))
        except Exception:
            self.apk = None

        try:
            with zipfile.ZipFile(apk_path, 'r') as zf:
                self._scan_manifest(zf)
                self._scan_permissions(zf)
                self._scan_java_sources(zf)
                self._scan_native_libs(zf)
                self._scan_resources(zf)
                self._scan_network_security_config(zf)
                self._scan_dex_files(zf)
                self._scan_debuggable(zf)
                self._scan_exported_components(zf)
                self._scan_intent_hijacking(zf)
                self._scan_backup_risk(zf)
                self._scan_cleartext_traffic(zf)
                self._scan_insecure_random(zf)
                self._scan_clipboard_usage(zf)
                self._scan_logging_statements(zf)
                self._scan_dynamic_loading(zf)
                self._scan_provider_security(zf)
                self._scan_deep_comprehensive(zf)
        except zipfile.BadZipFile:
            return {"error": "Invalid APK file"}

        # Build detections for Frida script generation.
        # Each flag = what the APP actually has.
        # Frida scripts are then generated to BYPASS those protections.
        self.detections = {
            # App has root detection -> generate root bypass script
            "has_root_detection": any(
                r.test_id == "MSTG-RESILIENCE-02" and r.status == "PASS"
                for r in self.results
            ),
            # App has SSL pinning -> generate SSL bypass script
            "has_ssl_pinning": any(
                r.test_id == "MSTG-NETWORK-04" and r.status == "PASS"
                for r in self.results
            ),
            # App has crypto usage -> generate key extraction script
            "has_crypto_issues": any(
                r.test_id == "MSTG-CRYPTO-01" and r.status == "FAIL"
                for r in self.results
            ),
            # App uses SharedPreferences -> generate storage monitor script
            "has_storage_issues": any(
                r.test_id == "MSTG-STORAGE-01"
                for r in self.results
            ),
            # App uses WebViews -> generate WebView monitor script
            "has_webviews": self.detections.get("has_webviews", False),
            # App has intent filters -> generate intent monitor script
            "has_intent_filters": self.detections.get("has_intent_filters", False),
            # App has anti-Frida -> generate Frida detection test script
            "has_anti_frida": any(
                r.test_id == "MSTG-RESILIENCE-04" and r.status == "PASS"
                for r in self.results
            ),
            "checks_network": True,
        }

        return self._compile_report(apk_path)

    # ─── Manifest Analysis ─────────────────────────────────────────────

    def _scan_manifest(self, zf: zipfile.ZipFile):
        """Analyze AndroidManifest.xml using androguard for reliable binary XML parsing."""
        # ---- Debuggable check (via androguard) ----
        if self.apk:
            try:
                debug_val = self.apk.get_attribute_value("application", "debuggable")
                is_debuggable = debug_val == "true"
                if is_debuggable:
                    self.results.append(ScanResult(
                        test_id="MSTG-CODE-01",
                        test_name="Testing for Debugging Symbols",
                        category="Code Quality", severity="High", status="FAIL",
                        description="Application is debuggable (android:debuggable=true).",
                        details="The application sets debuggable=true, allowing attackers to attach a debugger, inspect memory, and step through code execution.",
                        recommendation="Set android:debuggable='false' for release builds.",
                        evidence=["android:debuggable=true detected via androguard parsing of AndroidManifest.xml"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-1/"]
                    ))
                else:
                    self.results.append(ScanResult(
                        test_id="MSTG-CODE-01",
                        test_name="Testing for Debugging Symbols",
                        category="Code Quality", severity="Medium", status="PASS",
                        description="Application is not debuggable.",
                        details="android:debuggable is not set to true.",
                        recommendation="Keep debuggable disabled in production.",
                        evidence=[f"android:debuggable value = '{debug_val}' (not true)"] if debug_val else ["android:debuggable attribute not set (defaults to false)"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-1/"]
                    ))
            except Exception as e:
                self.results.append(ScanResult(
                    test_id="MSTG-CODE-01",
                    test_name="Testing for Debugging Symbols",
                    category="Code Quality", severity="Medium", status="INFO",
                    description="Could not determine debuggable status.",
                    details=f"Error: {e}",
                    recommendation="Verify android:debuggable is set to false.",
                    evidence=[],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-1/"]
                ))
        else:
            # No androguard — cannot reliably parse binary XML
            self.results.append(ScanResult(
                test_id="MSTG-CODE-01",
                test_name="Testing for Debugging Symbols",
                category="Code Quality", severity="Medium", status="INFO",
                description="Could not parse manifest (androguard unavailable).",
                details="androguard failed to load; binary XML cannot be reliably parsed with text matching.",
                recommendation="Install androguard for reliable manifest analysis.",
                evidence=[],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-1/"]
            ))

        # ---- allowBackup check (via androguard) ----
        if self.apk:
            try:
                backup_val = self.apk.get_attribute_value("application", "allowBackup")
                # allowBackup defaults to true if not specified
                is_backup_enabled = backup_val != "false"
                if is_backup_enabled:
                    evidence_text = f"allowBackup='{backup_val}'" if backup_val else "allowBackup not set (defaults to true)"
                    self.results.append(ScanResult(
                        test_id="MSTG-STORAGE-05",
                        test_name="Testing for Sensitive Data Backups",
                        category="Storage", severity="High", status="WARNING",
                        description="App allows ADB backup (android:allowBackup not disabled).",
                        details="When allowBackup is true (the default), an attacker with physical access or ADB can extract the entire app data directory using 'adb backup'.",
                        recommendation="Set android:allowBackup='false' in AndroidManifest.xml.",
                        evidence=[f"{evidence_text} detected via androguard"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-5/"]
                    ))
                else:
                    self.results.append(ScanResult(
                        test_id="MSTG-STORAGE-05",
                        test_name="Testing for Sensitive Data Backups",
                        category="Storage", severity="High", status="PASS",
                        description="ADB backup is disabled.",
                        details="android:allowBackup='false' is set in the manifest.",
                        recommendation="Keep allowBackup disabled.",
                        evidence=["allowBackup='false' detected via androguard"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-5/"]
                    ))
            except Exception:
                pass

        # ---- Permissions (via androguard) ----
        if self.apk:
            try:
                permissions = self.apk.get_permissions()
                unique_perms = list(set(permissions))
                dangerous = [p for p in unique_perms if p in self.DANGEROUS_PERMISSIONS]
                self.detections["total_permissions"] = len(unique_perms)
                self.detections["dangerous_permissions"] = dangerous
            except Exception:
                pass
        else:
            # Fallback to raw XML text matching (may miss things in binary XML)
            try:
                manifest = zf.read("AndroidManifest.xml")
                text = manifest.decode("latin-1", errors="ignore")
                perm_matches = re.findall(r'android\.permission\.(\w+)', text)
                if perm_matches:
                    unique_perms = list(set(perm_matches))
                    dangerous = [p for p in unique_perms if f"android.permission.{p}" in self.DANGEROUS_PERMISSIONS]
                    self.detections["total_permissions"] = len(unique_perms)
                    self.detections["dangerous_permissions"] = dangerous
            except Exception:
                pass

    # ─── Permissions ───────────────────────────────────────────────────

    def _scan_permissions(self, zf: zipfile.ZipFile):
        """Scan for dangerous permissions using androguard."""
        found_dangerous = []

        if self.apk:
            try:
                permissions = self.apk.get_permissions()
                for perm in permissions:
                    if perm in self.DANGEROUS_PERMISSIONS:
                        found_dangerous.append(perm)
            except Exception:
                pass

        if found_dangerous:
            evidence = [f"android.permission.{p.split('.')[-1]}" for p in found_dangerous]
            severity = "Critical" if len(found_dangerous) > 8 else "High" if len(found_dangerous) > 5 else "Medium"
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-01",
                test_name="Testing Local Storage for Sensitive Data (Permissions)",
                category="Storage", severity=severity, status="WARNING",
                description=f"App requests {len(found_dangerous)} dangerous permission(s).",
                details="Dangerous permissions found:\n" + "\n".join(f"  - {p}" for p in found_dangerous),
                recommendation="Minimize dangerous permissions. Request runtime permissions only when needed.",
                evidence=evidence,
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-1/"]
            ))

        if "android.permission.ACCESS_BACKGROUND_LOCATION" in found_dangerous:
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-08",
                test_name="Testing for Sensitive Data in Shared Storage",
                category="Storage", severity="High", status="FAIL",
                description="App requests ACCESS_BACKGROUND_LOCATION permission.",
                details="Background location access is a high-risk permission that can track user movements without their knowledge.",
                recommendation="Only request background location if absolutely necessary.",
                evidence=["android.permission.ACCESS_BACKGROUND_LOCATION declared in manifest"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-8/"]
            ))

    # ─── Smali / Java Sources ──────────────────────────────────────────

    def _scan_java_sources(self, zf: zipfile.ZipFile):
        """Scan smali/java sources for vulnerabilities with evidence."""
        sensitive_findings = []
        log_findings = []
        crypto_findings = []
        webview_findings = []
        sql_findings = []
        shared_prefs_findings = []
        root_detection_files = []
        ssl_pinning_files = []
        anti_frida_files = []
        clipboard_files = []
        reflection_files = []
        https_files = []
        http_urls = []

        for name in zf.namelist():
            if not (name.endswith(".smali") or name.endswith(".java") or name.endswith(".kt")):
                continue

            try:
                content = zf.read(name).decode("utf-8", errors="ignore")
            except Exception:
                continue

            # Sensitive data patterns
            for pattern, desc in self.SENSITIVE_DATA_PATTERNS:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches[:3]:
                    sensitive_findings.append(f"[{desc}] {name}: {match.strip()[:100]}")

            # Crypto patterns
            weak_crypto = {
                "DES": "DES cipher", "RC4": "RC4 stream cipher", "MD5": "MD5 hash",
                "SHA-1": "SHA-1 hash", "ECB": "ECB mode", "BASE64": "Base64 encoding"
            }
            for crypto, desc in weak_crypto.items():
                if crypto in content:
                    crypto_lines = [l.strip() for l in content.split('\n') if crypto in l][:2]
                    for line in crypto_lines:
                        crypto_findings.append(f"[{desc}] {name}: {line[:120]}")

            # WebView security
            if "addJavascriptInterface" in content:
                webview_findings.append(f"JavaScript interface exposed: {name}")
            if "setJavaScriptEnabled" in content and "true" in content:
                webview_findings.append(f"JavaScript enabled in WebView: {name}")
            if "setAllowFileAccess" in content:
                webview_findings.append(f"File access configured in WebView: {name}")
            if "setAllowUniversalAccessFromFileURLs" in content:
                webview_findings.append(f"Universal file access in WebView: {name}")
            if "loadUrl" in content and "WebView" in content:
                webview_findings.append(f"WebView.loadUrl call: {name}")
            if "evaluateJavascript" in content:
                webview_findings.append(f"evaluateJavascript call: {name}")
            if "setAllowContentAccess" in content:
                webview_findings.append(f"Content access in WebView: {name}")
            if "setSavePassword" in content:
                webview_findings.append(f"Password saving enabled in WebView: {name}")

            # SQL injection
            if "rawQuery" in content or "execSQL" in content:
                sql_lines = [l.strip() for l in content.split('\n')
                            if ('rawQuery' in l or 'execSQL' in l)][:3]
                for line in sql_lines:
                    sql_findings.append(f"Potential SQL injection: {name}: {line[:120]}")

            # SharedPreferences without encryption
            if "getSharedPreferences" in content:
                if "EncryptedSharedPreferences" not in content:
                    sp_lines = [l.strip() for l in content.split('\n') if 'getSharedPreferences' in l][:2]
                    for line in sp_lines:
                        shared_prefs_findings.append(f"Unencrypted SharedPreferences: {name}: {line[:120]}")

            # Log statements
            for log_method in self.LOG_METHODS:
                log_lines = [l.strip() for l in content.split('\n') if log_method in l][:3]
                for line in log_lines:
                    log_findings.append(f"{name}: {line[:120]}")

            # Root detection
            root_terms = ["/system/xbin/su", "/system/bin/su", "RootBeer", "isRooted", "test-keys",
                         "su", "/sbin/su", "SafetyNet"]
            if any(term in content for term in root_terms):
                self.detections["has_root_detection"] = True
                if name not in root_detection_files:
                    root_detection_files.append(name)

            # SSL pinning
            ssl_terms = ["CertificatePinner", "TrustManagerImpl", "X509TrustManager",
                        "SSLContext", "OkHttpClient", "HttpsURLConnection"]
            if any(term in content for term in ssl_terms):
                self.detections["has_ssl_pinning"] = True
                if name not in ssl_pinning_files:
                    ssl_pinning_files.append(name)

            # WebView detection
            if "WebView" in content:
                self.detections["has_webviews"] = True

            # Anti-frida / anti-debug
            frida_terms = ["frida", "Frida", "ptrace", "isDebuggerConnected",
                          "Debug.isDebuggerConnected", "android.os.Debug"]
            if any(term in content for term in frida_terms):
                self.detections["has_anti_frida"] = True
                if name not in anti_frida_files:
                    anti_frida_files.append(name)

            # Intent filters
            if "intent-filter" in content or "IntentFilter" in content:
                self.detections["has_intent_filters"] = True

            # Clipboard
            if "ClipboardManager" in content or "clipboard" in content.lower():
                if "clip" in content.lower():
                    clipboard_files.append(name)

            # Reflection / dynamic loading
            if "Class.forName" in content or "DexClassLoader" in content or "PathClassLoader" in content:
                reflection_files.append(name)

            # HTTP URLs (not HTTPS)
            http_pattern = re.findall(r'http://(?!localhost|127\.0\.0\.1|10\.|192\.168\.)[^\s"\'<>]+', content)
            for url in http_pattern[:3]:
                http_urls.append(f"HTTP URL: {name}: {url[:100]}")

            # HTTPS usage (for info)
            if "https://" in content:
                https_urls = re.findall(r'https://[^\s"\'<>]+', content)
                if https_urls:
                    https_files.append(name)

        # ─── Compile findings ───

        if sensitive_findings:
            self.results.append(ScanResult(
                test_id="MSTG-CRYPTO-01",
                test_name="Testing for Hardcoded Cryptographic Keys",
                category="Cryptography", severity="Critical", status="FAIL",
                description=f"Found {len(sensitive_findings)} hardcoded sensitive data entries.",
                details="Hardcoded secrets detected:\n" + "\n".join(sensitive_findings[:15]),
                recommendation="Remove all hardcoded secrets. Use Android Keystore or encrypted storage.",
                evidence=sensitive_findings[:10],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CRYPTO-1/"]
            ))

        if log_findings:
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-02",
                test_name="Testing for Sensitive Data in System Logs",
                category="Storage", severity="High", status="WARNING",
                description=f"Found {len(log_findings)} log statement(s) that may leak sensitive data.",
                details="Log statements found:\n" + "\n".join(log_findings[:15]),
                recommendation="Remove or strip all logging statements in production builds.",
                evidence=log_findings[:10],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-2/"]
            ))

        if crypto_findings:
            self.results.append(ScanResult(
                test_id="MSTG-CRYPTO-02",
                test_name="Testing for Weak Cryptographic Algorithms",
                category="Cryptography", severity="Critical", status="FAIL",
                description=f"Found {len(crypto_findings)} weak cryptographic algorithm usage(s).",
                details="Weak crypto found:\n" + "\n".join(crypto_findings[:10]),
                recommendation="Replace weak algorithms with AES-256-GCM, SHA-256+, ECDH.",
                evidence=crypto_findings[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CRYPTO-2/"]
            ))

        if webview_findings:
            self.results.append(ScanResult(
                test_id="MSTG-CODE-08",
                test_name="Testing for Trivial WebViews",
                category="Code Quality", severity="High", status="FAIL",
                description=f"Found {len(webview_findings)} WebView security issue(s).",
                details="WebView issues:\n" + "\n".join(webview_findings[:15]),
                recommendation="Disable JavaScript if not needed. Set file access to false. Validate all URLs.",
                evidence=webview_findings[:10],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-8/"]
            ))
        else:
            # No WebViews found - that's a PASS
            self.results.append(ScanResult(
                test_id="MSTG-CODE-08",
                test_name="Testing for Trivial WebViews",
                category="Code Quality", severity="High", status="PASS",
                description="No WebView security issues detected.",
                details="No JavaScript bridges or dangerous WebView configurations found.",
                recommendation="If WebViews are used, ensure JavaScript is disabled and file access is restricted.",
                evidence=["No WebView security issues found in smali/java sources"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-8/"]
            ))

        if sql_findings:
            self.results.append(ScanResult(
                test_id="MSTG-CODE-10",
                test_name="Testing for Object Relational Mapping (ORM) Issues",
                category="Code Quality", severity="High", status="FAIL",
                description=f"Found {len(sql_findings)} potential SQL injection point(s).",
                details="SQL injection risks:\n" + "\n".join(sql_findings[:10]),
                recommendation="Use parameterized queries. Avoid raw SQL with user input.",
                evidence=sql_findings[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-10/"]
            ))

        if shared_prefs_findings:
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-01",
                test_name="Testing Local Storage for Sensitive Data (SharedPrefs)",
                category="Storage", severity="High", status="FAIL",
                description=f"Found {len(shared_prefs_findings)} unencrypted SharedPreferences usage(s).",
                details="Unencrypted SharedPrefs:\n" + "\n".join(shared_prefs_findings[:15]),
                recommendation="Use EncryptedSharedPreferences for sensitive data storage.",
                evidence=shared_prefs_findings[:10],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-1/"]
            ))

        if reflection_files:
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-01",
                test_name="Testing Anti-Reverse Engineering",
                category="Resilience", severity="Medium", status="INFO",
                description=f"Found {len(reflection_files)} file(s) using reflection or dynamic class loading.",
                details="Reflection/dynamic loading found:\n" + "\n".join(f"  - {f}" for f in reflection_files[:10]),
                recommendation="Review reflection usage for security implications. Avoid loading untrusted code.",
                evidence=[f"Reflection/dynamic loading in: {f}" for f in reflection_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-1/"]
            ))

        if http_urls:
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-02",
                test_name="Testing for Unencrypted Communications (URLs)",
                category="Network", severity="Critical", status="FAIL",
                description=f"Found {len(http_urls)} hardcoded HTTP (non-TLS) URL(s) in source code.",
                details="HTTP URLs found:\n" + "\n".join(http_urls[:10]),
                recommendation="Replace all HTTP URLs with HTTPS. Use network_security_config.xml to enforce TLS.",
                evidence=http_urls[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-2/"]
            ))
        elif https_files:
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-02",
                test_name="Testing for Unencrypted Communications (URLs)",
                category="Network", severity="Critical", status="PASS",
                description="All URLs appear to use HTTPS.",
                details=f"Found HTTPS URLs in {len(https_files)} file(s).",
                recommendation="Continue using HTTPS for all communications.",
                evidence=[f"HTTPS URLs found in: {f}" for f in https_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-2/"]
            ))

        # Root detection present
        if root_detection_files:
            self.results.append(ScanResult(
                test_id="MSTG-CODE-14",
                test_name="Testing for Root Detection",
                category="Code Quality", severity="Medium", status="PASS",
                description=f"Root detection mechanisms found in {len(root_detection_files)} file(s).",
                details="Root detection files:\n" + "\n".join(f"  - {f}" for f in root_detection_files[:10]),
                recommendation="Ensure root detection cannot be bypassed with Frida/Xposed.",
                evidence=[f"Root detection found in: {f}" for f in root_detection_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-14/"]
            ))

        # SSL pinning present
        if ssl_pinning_files and not any(r.test_id == "MSTG-NETWORK-04" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-04",
                test_name="Testing for SSL/TLS Certificate Pinning",
                category="Network", severity="Medium", status="PASS",
                description=f"SSL pinning implementation detected in {len(ssl_pinning_files)} file(s).",
                details="SSL pinning files:\n" + "\n".join(f"  - {f}" for f in ssl_pinning_files[:10]),
                recommendation="Verify pinning covers all critical endpoints.",
                evidence=[f"SSL pinning found in: {f}" for f in ssl_pinning_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-4/"]
            ))

        # Anti-frida
        if anti_frida_files:
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-04",
                test_name="Testing Anti-Frida Detection",
                category="Resilience", severity="High", status="PASS",
                description=f"Anti-Frida/anti-debug mechanisms detected in {len(anti_frida_files)} file(s).",
                details="Anti-analysis files:\n" + "\n".join(f"  - {f}" for f in anti_frida_files[:10]),
                recommendation="Ensure anti-Frida cannot be bypassed.",
                evidence=[f"Anti-analysis found in: {f}" for f in anti_frida_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-4/"]
            ))

        if clipboard_files:
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-03",
                test_name="Testing for Sensitive Data in Clipboard",
                category="Storage", severity="Medium", status="INFO",
                description=f"Clipboard access detected in {len(clipboard_files)} file(s).",
                details="Clipboard usage files:\n" + "\n".join(f"  - {f}" for f in clipboard_files[:10]),
                recommendation="Avoid copying sensitive data to clipboard. Use custom buffers.",
                evidence=[f"Clipboard usage in: {f}" for f in clipboard_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-3/"]
            ))

    # ─── Native Libs ───────────────────────────────────────────────────

    def _scan_native_libs(self, zf: zipfile.ZipFile):
        """Scan native libraries for security issues."""
        native_libs = [n for n in zf.namelist() if n.startswith("lib/") and n.endswith(".so")]
        if native_libs:
            # Group by architecture
            arches = {}
            for lib in native_libs:
                parts = lib.split("/")
                if len(parts) >= 3:
                    arch = parts[1]
                    arches.setdefault(arch, []).append(lib)

            arch_info = [f"{arch}: {len(libs)} libs" for arch, libs in arches.items()]
            evidence = []
            for lib in native_libs[:10]:
                try:
                    size = len(zf.read(lib)) if lib in zf.namelist() else 0
                    evidence.append(f"{lib} ({size:,} bytes)")
                except Exception:
                    evidence.append(f"{lib} (size unknown)")

            self.results.append(ScanResult(
                test_id="MSTG-CODE-05",
                test_name="Testing for Unsafe JNI",
                category="Code Quality", severity="Medium", status="INFO",
                description=f"Found {len(native_libs)} native library(ies) across {len(arches)} architecture(s).",
                details="Architectures: " + ", ".join(arch_info) + "\n\nLibraries:\n" + "\n".join(f"  - {lib}" for lib in native_libs[:20]),
                recommendation="Audit native code for buffer overflows, format string vulnerabilities, and unsafe JNI usage.",
                evidence=evidence,
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-5/"]
            ))

            # Check for interesting native libs
            security_libs = [lib for lib in native_libs if any(term in lib.lower()
                           for term in ["frida", "xposed", "substrate", "hook", "debug", "anti"])]
            if security_libs:
                self.results.append(ScanResult(
                    test_id="MSTG-RESILIENCE-05",
                    test_name="Testing for Anti-Hooking",
                    category="Resilience", severity="High", status="PASS",
                    description=f"Security-related native libraries detected.",
                    details="Security libraries:\n" + "\n".join(f"  - {lib}" for lib in security_libs),
                    recommendation="Verify anti-hooking mechanisms are effective.",
                    evidence=[f"Security library: {lib}" for lib in security_libs],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-5/"]
                ))

    # ─── Resources ─────────────────────────────────────────────────────

    def _scan_resources(self, zf: zipfile.ZipFile):
        """Scan resources for sensitive data."""
        resource_findings = []
        for name in zf.namelist():
            if name.startswith("res/") and (name.endswith(".xml") or name.endswith(".json")):
                try:
                    content = zf.read(name).decode("utf-8", errors="ignore")
                    for pattern, desc in self.SENSITIVE_DATA_PATTERNS:
                        matches = re.findall(pattern, content, re.IGNORECASE)
                        for match in matches[:2]:
                            resource_findings.append(f"[{desc}] {name}: {match.strip()[:100]}")
                except Exception:
                    continue

        if resource_findings:
            self.results.append(ScanResult(
                test_id="MSTG-CRYPTO-01",
                test_name="Testing for Hardcoded Cryptographic Keys (Resources)",
                category="Cryptography", severity="Critical", status="FAIL",
                description=f"Found {len(resource_findings)} hardcoded secret(s) in resources.",
                details="Secrets in resources:\n" + "\n".join(resource_findings[:10]),
                recommendation="Remove hardcoded secrets from resources. Use secure storage.",
                evidence=resource_findings[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CRYPTO-1/"]
            ))

    # ─── Network Security Config ──────────────────────────────────────

    def _scan_network_security_config(self, zf: zipfile.ZipFile):
        """Scan network security configuration."""
        nsc_path = "res/xml/network_security_config.xml"
        if nsc_path in zf.namelist():
            try:
                content = zf.read(nsc_path).decode("utf-8")
                if 'cleartextTrafficPermitted="true"' in content:
                    self.results.append(ScanResult(
                        test_id="MSTG-NETWORK-02",
                        test_name="Testing for Unencrypted Communications (NSC)",
                        category="Network", severity="Critical", status="FAIL",
                        description="App allows cleartext (HTTP) traffic via network_security_config.xml.",
                        details="cleartextTrafficPermitted='true' found in network security config. This allows all HTTP traffic.",
                        recommendation="Set cleartextTrafficPermitted='false'. Use HTTPS everywhere.",
                        evidence=[f"Found in {nsc_path}: cleartextTrafficPermitted=\"true\""],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-2/"]
                    ))
                else:
                    self.results.append(ScanResult(
                        test_id="MSTG-NETWORK-02",
                        test_name="Testing for Unencrypted Communications (NSC)",
                        category="Network", severity="Critical", status="PASS",
                        description="Cleartext traffic appears to be disabled in NSC.",
                        details="network_security_config.xml found with cleartext disabled.",
                        recommendation="Continue using HTTPS-only configuration.",
                        evidence=[f"Found in {nsc_path}: cleartextTrafficPermitted not set to true"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-2/"]
                    ))

                if "pin-set" in content:
                    self.results.append(ScanResult(
                        test_id="MSTG-NETWORK-04",
                        test_name="Testing for SSL/TLS Certificate Pinning (NSC)",
                        category="Network", severity="Medium", status="PASS",
                        description="SSL pinning configured via network_security_config.xml.",
                        details="Certificate pinning found in network security configuration.",
                        recommendation="Ensure pinning covers all critical endpoints.",
                        evidence=[f"pin-set found in {nsc_path}"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-4/"]
                    ))
                else:
                    if not any(r.test_id == "MSTG-NETWORK-04" for r in self.results):
                        self.results.append(ScanResult(
                            test_id="MSTG-NETWORK-04",
                            test_name="Testing for SSL/TLS Certificate Pinning (NSC)",
                            category="Network", severity="Medium", status="WARNING",
                            description="No SSL pinning found in network_security_config.xml.",
                            details="Consider adding certificate pinning for critical API endpoints.",
                            recommendation="Implement certificate pinning for sensitive API endpoints.",
                            evidence=[f"No pin-set found in {nsc_path}"],
                            refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-4/"]
                        ))
            except Exception:
                pass

    # ─── DEX File Analysis ────────────────────────────────────────────

    def _scan_dex_files(self, zf: zipfile.ZipFile):
        """Scan DEX files for obfuscation and additional patterns."""
        dex_files = [n for n in zf.namelist() if n.endswith(".dex")]

        for dex_name in dex_files:
            try:
                content = zf.read(dex_name)
                text = content.decode("utf-8", errors="ignore")

                # Check for ProGuard obfuscation
                short_names = len(re.findall(r'[a-z]{2}/[a-z]{1,2};', text))

                # Count all class names for better context
                all_classes = re.findall(r'L([a-zA-Z][a-zA-Z0-9_/$]*);', text)
                total_classes = len(all_classes)

                if short_names > 50:
                    self.results.append(ScanResult(
                        test_id="MSTG-CODE-07",
                        test_name="Testing for Code Obfuscation",
                        category="Code Quality", severity="Low", status="PASS",
                        description=f"Code appears to be obfuscated (ProGuard/R8 detected) in {dex_name}.",
                        details=f"Found {short_names} short class names out of {total_classes} total classes, indicating obfuscation.",
                        recommendation="Continue using obfuscation for production builds.",
                        evidence=[f"Found {short_names}/{total_classes} obfuscated class names in {dex_name}"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-7/"]
                    ))
                else:
                    # Check if there are ANY obfuscated names at all
                    pct = (short_names / total_classes * 100) if total_classes > 0 else 0
                    self.results.append(ScanResult(
                        test_id="MSTG-CODE-07",
                        test_name="Testing for Code Obfuscation",
                        category="Code Quality", severity="Low", status="WARNING",
                        description=f"Limited code obfuscation in {dex_name}.",
                        details=f"Only {short_names}/{total_classes} ({pct:.1f}%) class names appear obfuscated. ProGuard/R8 may not be enabled.",
                        recommendation="Enable ProGuard/R8 with aggressive obfuscation settings for release builds.",
                        evidence=[f"Obfuscation ratio in {dex_name}: {short_names}/{total_classes} ({pct:.1f}%)"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-7/"]
                    ))

            except Exception:
                continue

    # ─── Debuggable Check ──────────────────────────────────────────────

    def _scan_debuggable(self, zf: zipfile.ZipFile):
        """Check debuggable — already handled in _scan_manifest. No-op here."""
        pass

    # ─── Exported Components ───────────────────────────────────────────

    def _scan_exported_components(self, zf: zipfile.ZipFile):
        """Check for exported components that can be exploited (via androguard)."""
        exported_components = []
        all_components = []

        if self.apk:
            try:
                # Get exported activities
                for act in self.apk.get_activities():
                    all_components.append(f"Activity: {act}")
                    # Check if exported
                    try:
                        exported = self.apk.get_attribute_value("activity", "exported", name=act)
                        if exported == "true":
                            exported_components.append(f"Activity: {act}")
                    except Exception:
                        pass

                # Get exported services
                for svc in self.apk.get_services():
                    all_components.append(f"Service: {svc}")
                    try:
                        exported = self.apk.get_attribute_value("service", "exported", name=svc)
                        if exported == "true":
                            exported_components.append(f"Service: {svc}")
                    except Exception:
                        pass

                # Get exported receivers
                for rcv in self.apk.get_receivers():
                    all_components.append(f"Receiver: {rcv}")
                    try:
                        exported = self.apk.get_attribute_value("receiver", "exported", name=rcv)
                        if exported == "true":
                            exported_components.append(f"Receiver: {rcv}")
                    except Exception:
                        pass
            except Exception:
                pass

        if exported_components:
            severity = "High" if len(exported_components) > 3 else "Medium"
            self.results.append(ScanResult(
                test_id="MSTG-PLATFORM-01",
                test_name="Testing for URL Handling",
                category="Platform", severity=severity, status="WARNING",
                description=f"Found {len(exported_components)} exported component(s) that may expose sensitive functionality.",
                details=f"Exported components can be invoked by other apps:\n" + chr(10).join(f"  - {c}" for c in exported_components[:20]),
                recommendation="Set exported='false' for components that don't need external access.",
                evidence=[f"Exported: {c}" for c in exported_components[:10]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-1/"]
            ))

    # ─── Intent Hijacking ──────────────────────────────────────────────

    def _scan_intent_hijacking(self, zf: zipfile.ZipFile):
        """Check for implicit intents that could be hijacked."""
        implicit_intents = []
        try:
            for name in zf.namelist():
                if not (name.endswith(".smali") or name.endswith(".java")):
                    continue
                content = zf.read(name).decode("utf-8", errors="ignore")
                # Check for implicit intents (no setComponent/setPackage)
                if "new Intent(" in content or "Intent(" in content:
                    if "setComponent" not in content and "setPackage" not in content:
                        implicit_intents.append(name)
        except Exception:
            pass

        if implicit_intents:
            self.results.append(ScanResult(
                test_id="MSTG-PLATFORM-03",
                test_name="Testing for Intent Sniffing",
                category="Platform", severity="Medium", status="INFO",
                description=f"Found {len(implicit_intents)} file(s) with potential implicit intent usage.",
                details="Implicit intents can be intercepted by malicious apps.",
                recommendation="Use explicit intents with setComponent() for sensitive operations.",
                evidence=[f"Potential implicit intent in: {f}" for f in implicit_intents[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-3/"]
            ))

    # ─── Backup Risk ──────────────────────────────────────────────────

    def _scan_backup_risk(self, zf: zipfile.ZipFile):
        """Additional backup checks beyond manifest."""
        # Already handled in _scan_manifest
        pass

    # ─── Cleartext Traffic ────────────────────────────────────────────

    def _scan_cleartext_traffic(self, zf: zipfile.ZipFile):
        """Check for cleartext traffic permission (via androguard)."""
        if any(r.test_id == "MSTG-NETWORK-02" for r in self.results):
            return  # Already handled

        if self.apk:
            try:
                cleartext = self.apk.get_attribute_value("application", "usesCleartextTraffic")
                if cleartext == "true":
                    self.results.append(ScanResult(
                        test_id="MSTG-NETWORK-02",
                        test_name="Testing for Unencrypted Communications",
                        category="Network", severity="High", status="WARNING",
                        description="App explicitly allows cleartext traffic.",
                        details="usesCleartextTraffic='true' allows HTTP connections.",
                        recommendation="Set usesCleartextTraffic='false' or remove the attribute.",
                        evidence=["usesCleartextTraffic='true' detected via androguard"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-2/"]
                    ))
                else:
                    self.results.append(ScanResult(
                        test_id="MSTG-NETWORK-02",
                        test_name="Testing for Unencrypted Communications",
                        category="Network", severity="High", status="PASS",
                        description="Cleartext traffic is not explicitly allowed.",
                        details=f"usesCleartextTraffic={cleartext or 'not set (default false)'}",
                        recommendation="Continue using HTTPS-only configuration.",
                        evidence=[f"usesCleartextTraffic='{cleartext}' via androguard"] if cleartext else ["usesCleartextTraffic not set (defaults to false)"],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-2/"]
                    ))
            except Exception:
                pass

    # ─── Insecure Random ──────────────────────────────────────────────

    def _scan_insecure_random(self, zf: zipfile.ZipFile):
        """Check for use of java.util.Random instead of SecureRandom."""
        insecure_random = []
        for name in zf.namelist():
            if not (name.endswith(".smali") or name.endswith(".java")):
                continue
            try:
                content = zf.read(name).decode("utf-8", errors="ignore")
                if "java.util.Random" in content and "SecureRandom" not in content:
                    lines = [l.strip() for l in content.split('\n')
                            if "java.util.Random" in l and "SecureRandom" not in l][:2]
                    for line in lines:
                        insecure_random.append(f"{name}: {line[:120]}")
            except Exception:
                continue

        if insecure_random:
            self.results.append(ScanResult(
                test_id="MSTG-CRYPTO-03",
                test_name="Testing for Insecure Cryptographic Implementation",
                category="Cryptography", severity="High", status="FAIL",
                description=f"Found {len(insecure_random)} usage(s) of insecure random number generator.",
                details="java.util.Random is not cryptographically secure:\n" + "\n".join(insecure_random[:10]),
                recommendation="Use java.security.SecureRandom for all security-sensitive random number generation.",
                evidence=insecure_random[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CRYPTO-3/"]
            ))

    # ─── Clipboard Usage ──────────────────────────────────────────────

    def _scan_clipboard_usage(self, zf: zipfile.ZipFile):
        """Check for clipboard usage that may leak sensitive data."""
        # Handled in _scan_java_sources
        pass

    # ─── Logging Statements ───────────────────────────────────────────

    def _scan_logging_statements(self, zf: zipfile.ZipFile):
        """Check for excessive logging."""
        # Handled in _scan_java_sources
        pass

    # ─── Dynamic Loading ──────────────────────────────────────────────

    def _scan_dynamic_loading(self, zf: zipfile.ZipFile):
        """Check for dynamic code loading."""
        dynamic_loaders = []
        for name in zf.namelist():
            if not (name.endswith(".smali") or name.endswith(".java")):
                continue
            try:
                content = zf.read(name).decode("utf-8", errors="ignore")
                dangerous_loaders = ["DexClassLoader", "PathClassLoader", "InMemoryDexClassLoader",
                                    "loadClass", "Class.forName", "Runtime.getRuntime().exec"]
                found = [dl for dl in dangerous_loaders if dl in content]
                if found:
                    for dl in found[:1]:
                        lines = [l.strip() for l in content.split('\n') if dl in l][:1]
                        for line in lines:
                            dynamic_loaders.append(f"[{dl}] {name}: {line[:120]}")
            except Exception:
                continue

        if dynamic_loaders:
            self.results.append(ScanResult(
                test_id="MSTG-CODE-13",
                test_name="Testing for Local Encryption Keys",
                category="Code Quality", severity="High", status="WARNING",
                description=f"Found {len(dynamic_loaders)} dynamic code loading usage(s).",
                details="Dynamic code loading can be used to load malicious code at runtime:\n" + "\n".join(dynamic_loaders[:10]),
                recommendation="Avoid dynamic code loading. If necessary, validate all loaded code.",
                evidence=dynamic_loaders[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-13/"]
            ))

    # ─── Provider Security ────────────────────────────────────────────

    def _scan_provider_security(self, zf: zipfile.ZipFile):
        """Check ContentProvider security (via androguard)."""
        if self.apk:
            try:
                providers = self.apk.get_providers()
                exported_providers = []
                for p in providers:
                    try:
                        exported = self.apk.get_attribute_value("provider", "exported", name=p)
                        if exported == "true":
                            exported_providers.append(p)
                    except Exception:
                        pass

                if exported_providers:
                    self.results.append(ScanResult(
                        test_id="MSTG-STORAGE-07",
                        test_name="Testing for Exposed IPC Interfaces",
                        category="Storage", severity="High", status="WARNING",
                        description=f"Found {len(exported_providers)} exported ContentProvider(s).",
                        details="Exported providers can be accessed by other apps:\n" + chr(10).join(f"  - {p}" for p in exported_providers),
                        recommendation="Set exported='false' for providers. Add permissions if export is needed.",
                        evidence=[f"Exported provider: {p}" for p in exported_providers],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-7/"]
                    ))
                elif providers:
                    self.results.append(ScanResult(
                        test_id="MSTG-STORAGE-07",
                        test_name="Testing for Exposed IPC Interfaces",
                        category="Storage", severity="High", status="PASS",
                        description=f"Found {len(providers)} ContentProvider(s), none explicitly exported.",
                        details="ContentProviders: " + ", ".join(providers),
                        recommendation="Verify providers are not accessible without explicit permissions.",
                        evidence=[f"Provider: {p} (not exported)" for p in providers[:5]],
                        refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-7/"]
                    ))
            except Exception:
                pass

    # ─── Deep Comprehensive Analysis ─────────────────────────────────

    def _scan_deep_comprehensive(self, zf: zipfile.ZipFile):
        """Deep analysis covering all MASTG categories with real evidence."""
        # Collect all source code — try smali first, fall back to DEX strings via androguard
        all_smali = {}
        for name in zf.namelist():
            if name.endswith(".smali"):
                try:
                    all_smali[name] = zf.read(name).decode("utf-8", errors="ignore")
                except Exception:
                    continue

        # If no smali, extract strings from androguard's DEX analysis
        if not all_smali and self.dex:
            try:
                # Extract method names, class names, and string references from DEX
                all_classes = []
                for dex_analysis in (self.dex if isinstance(self.dex, list) else [self.dex]):
                    if hasattr(dex_analysis, 'get_classes'):
                        for cls in dex_analysis.get_classes():
                            cls_name = cls.name if hasattr(cls, 'name') else str(cls)
                            all_classes.append(cls_name)
                            if hasattr(cls, 'get_methods'):
                                for method in cls.get_methods():
                                    if hasattr(method, 'get_source'):
                                        try:
                                            source = method.get_source()
                                            if source:
                                                all_smali[f"{cls_name}/{method.name}"] = source
                                        except Exception:
                                            pass
            except Exception:
                pass

        # If still no source, extract raw strings from DEX files
        if not all_smali:
            for name in zf.namelist():
                if name.endswith(".dex"):
                    try:
                        dex_bytes = zf.read(name)
                        # Extract ASCII strings from DEX binary
                        strings = re.findall(rb'[\x20-\x7e]{8,200}', dex_bytes)
                        combined = "\n".join(s.decode('ascii', errors='ignore') for s in strings)
                        all_smali[name] = combined
                    except Exception:
                        continue

        if not all_smali:
            return

        combined_smali = "\n".join(all_smali.values())

        # ─── STORAGE TESTS ───────────────────────────────────
        # MSTG-STORAGE-01: Local Storage for Sensitive Data
        sp_files = []
        encrypted_sp = []
        sqlite_files = []
        for name, content in all_smali.items():
            if "getSharedPreferences" in content:
                if "EncryptedSharedPreferences" in content:
                    encrypted_sp.append(name)
                else:
                    lines = [l.strip() for l in content.split('\n') if 'getSharedPreferences' in l][:2]
                    for l in lines:
                        sp_files.append(f"{name}: {l[:100]}")
            if "SQLiteDatabase" in content or "sqlite" in name.lower():
                if "openOrCreateDatabase" in content or "rawQuery" in content or "execSQL" in content:
                    sqlite_files.append(name)

        if sp_files:
            # Check if NOT in results already
            if not any(r.test_id == "MSTG-STORAGE-01" for r in self.results):
                self.results.append(ScanResult(
                    test_id="MSTG-STORAGE-01",
                    test_name="Testing Local Storage for Sensitive Data",
                    category="Storage", severity="High", status="WARNING",
                    description=f"Found {len(sp_files)} unencrypted SharedPreferences usage(s).",
                    details="SharedPreferences without encryption:\n" + "\n".join(sp_files[:10]),
                    recommendation="Use EncryptedSharedPreferences for sensitive data.",
                    evidence=sp_files[:8],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-1/"]
                ))
        elif encrypted_sp and not sp_files:
            if not any(r.test_id == "MSTG-STORAGE-01" for r in self.results):
                self.results.append(ScanResult(
                    test_id="MSTG-STORAGE-01",
                    test_name="Testing Local Storage for Sensitive Data",
                    category="Storage", severity="High", status="PASS",
                    description=f"App uses EncryptedSharedPreferences in {len(encrypted_sp)} file(s).",
                    details="EncryptedSharedPreferences usage found.",
                    recommendation="Continue using encrypted storage.",
                    evidence=[f"EncryptedSharedPreferences in: {f}" for f in encrypted_sp[:5]],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-1/"]
                ))

        # MSTG-STORAGE-03: Clipboard Usage
        clipboard_files = []
        for name, content in all_smali.items():
            if "ClipboardManager" in content or "setPrimaryClip" in content:
                clipboard_files.append(name)
        if clipboard_files and not any(r.test_id == "MSTG-STORAGE-03" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-03",
                test_name="Testing for Sensitive Data in Clipboard",
                category="Storage", severity="Medium", status="WARNING",
                description=f"Clipboard access found in {len(clipboard_files)} file(s).",
                details="ClipboardManager usage detected — sensitive data may be copied.",
                recommendation="Use setPrimaryClip(null) or custom clipboard for sensitive fields.",
                evidence=[f"Clipboard access in: {f}" for f in clipboard_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-3/"]
            ))
        elif not clipboard_files and not any(r.test_id == "MSTG-STORAGE-03" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-03",
                test_name="Testing for Sensitive Data in Clipboard",
                category="Storage", severity="Medium", status="PASS",
                description="No clipboard usage detected.",
                details="No ClipboardManager calls found.",
                recommendation="If clipboard is used later, ensure sensitive data is excluded.",
                evidence=["No clipboard usage found in smali/DEX sources"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-3/"]
            ))

        # ─── WebView Detection from DEX strings ───
        # Always check — may override a false PASS from _scan_java_sources (smali-only)
        webview_findings = []
        for name, content in all_smali.items():
            if "addJavascriptInterface" in content:
                webview_findings.append(f"JavaScript interface exposed: {name}")
            if "setJavaScriptEnabled" in content:
                webview_findings.append(f"JavaScript enabled in WebView: {name}")
            if "loadUrl" in content and "WebView" in content:
                webview_findings.append(f"WebView.loadUrl call: {name}")
            if "setAllowUniversalAccessFromFileURLs" in content:
                webview_findings.append(f"Universal file access in WebView: {name}")
            if "evaluateJavascript" in content:
                webview_findings.append(f"evaluateJavascript call: {name}")
            if "setAllowFileAccess" in content:
                webview_findings.append(f"File access in WebView: {name}")

        has_any_webview = any("WebView" in content for content in all_smali.values())
        if has_any_webview:
            self.detections["has_webviews"] = True

        # If we found WebViews, override any existing MSTG-CODE-08 PASS (from smali scan)
        if has_any_webview or webview_findings:
            # Remove previous false PASS if it said "no WebView issues"
            self.results = [r for r in self.results if not (r.test_id == "MSTG-CODE-08" and r.status == "PASS")]

            if webview_findings:
                self.results.append(ScanResult(
                    test_id="MSTG-CODE-08",
                    test_name="Testing for Trivial WebViews",
                    category="Code Quality", severity="High", status="FAIL",
                    description=f"Found {len(webview_findings)} WebView security issue(s).",
                    details="WebView issues:\n" + "\n".join(webview_findings[:15]),
                    recommendation="Disable JavaScript if not needed. Set file access to false. Validate all URLs.",
                    evidence=webview_findings[:10],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-8/"]
                ))
            else:
                self.results.append(ScanResult(
                    test_id="MSTG-CODE-08",
                    test_name="Testing for Trivial WebViews",
                    category="Code Quality", severity="High", status="INFO",
                    description="WebView usage detected but no specific security issues found in DEX strings.",
                    details="WebView class references found in DEX.",
                    recommendation="Review WebView configurations for JavaScript, file access, and URL validation.",
                    evidence=["WebView references found in DEX sources"],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-8/"]
                ))

        # MSTG-STORAGE-04: Temp Files
        temp_files = []
        for name, content in all_smali.items():
            if "createTempFile" in content or "cacheDir" in content or "getCacheDir" in content:
                temp_files.append(name)
        if temp_files and not any(r.test_id == "MSTG-STORAGE-04" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-04",
                test_name="Testing for Sensitive Data in Temp Files",
                category="Storage", severity="Medium", status="WARNING",
                description=f"Temp file / cache usage in {len(temp_files)} file(s).",
                details="Cache and temp file operations found.",
                recommendation="Ensure temp files don't contain sensitive data. Delete after use.",
                evidence=[f"Cache/temp usage in: {f}" for f in temp_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-4/"]
            ))

        # MSTG-STORAGE-06: Keyboard Cache
        ime_fields = []
        for name, content in all_smali.items():
            if "inputType" in content and ("textPassword" in content or "textVisiblePassword" in content or "numberPassword" in content):
                ime_fields.append(name)
        # This is more about XML layouts, but we can check for textNoSuggestions in smali

        # MSTG-STORAGE-08: Shared Storage (external)
        ext_storage = []
        for name, content in all_smali.items():
            if "getExternalStorageDirectory" in content or "getExternalFilesDir" in content:
                ext_storage.append(name)
        if ext_storage and not any(r.test_id == "MSTG-STORAGE-08" for r in self.results):
            has_sensitive = any(t in combined_smali for t in ["password", "token", "secret", "key", "credential"])
            self.results.append(ScanResult(
                test_id="MSTG-STORAGE-08",
                test_name="Testing for Sensitive Data in Shared Storage",
                category="Storage", severity="High" if has_sensitive else "Medium",
                status="WARNING" if has_sensitive else "INFO",
                description=f"External storage access in {len(ext_storage)} file(s).",
                details="External storage is accessible by other apps with READ_EXTERNAL_STORAGE.",
                recommendation="Use app-specific storage (getExternalFilesDir) or internal storage.",
                evidence=[f"External storage access in: {f}" for f in ext_storage[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-8/"]
            ))

        # ─── CRYPTO TESTS ───────────────────────────────────
        # MSTG-CRYPTO-04: Key storage
        key_storage = []
        for name, content in all_smali.items():
            if "SharedPreferences" in content and ("SecretKey" in content or "AES" in content or "encrypt" in content.lower()):
                key_storage.append(name)
        if key_storage and not any(r.test_id == "MSTG-CRYPTO-04" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-CRYPTO-04",
                test_name="Testing for Insufficiently Protected Keys",
                category="Cryptography", severity="High", status="WARNING",
                description=f"Crypto key storage in {len(key_storage)} file(s) may not use Android Keystore.",
                details="Keys may be stored in SharedPreferences.",
                recommendation="Store cryptographic keys in Android Keystore system.",
                evidence=[f"Key storage concern in: {f}" for f in key_storage[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CRYPTO-4/"]
            ))

        # ─── NETWORK TESTS ───────────────────────────────────
        # MSTG-NETWORK-01: Data Exfiltration / tracking
        # Separate standard SDKs (Firebase/GMS) from actual trackers (ad SDKs)
        standard_sdks = []
        ad_trackers = []
        standard_terms = ["com.google.android.gms", "com.google.firebase"]
        tracker_terms = ["com.facebook.sdk", "com.appsflyer", "com.branch",
                        "io.branch", "com.adjust.sdk", "com.inmobi",
                        "com.startapp", "com.tapjoy", "com.unity3d.ads",
                        "com.chartboost", "com.mopub", "com.admob"]
        for name, content in all_smali.items():
            for sdk in standard_terms:
                if sdk in content:
                    standard_sdks.append(sdk)
                    break
            for tracker in tracker_terms:
                if tracker in content:
                    ad_trackers.append(f"{tracker} in {name}")
                    break

        if ad_trackers and not any(r.test_id == "MSTG-NETWORK-01" for r in self.results):
            unique_trackers = list(set(ad_trackers))
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-01",
                test_name="Testing for Data Exfiltration",
                category="Network", severity="Medium", status="WARNING",
                description=f"Found {len(unique_trackers)} third-party advertising/tracking SDK(s).",
                details="Tracking SDKs found:\n" + "\n".join(f"  - {t}" for t in unique_trackers[:15]),
                recommendation="Audit all third-party SDK data collection. Disclose in privacy policy.",
                evidence=unique_trackers[:10],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-1/"]
            ))
        elif standard_sdks and not ad_trackers and not any(r.test_id == "MSTG-NETWORK-01" for r in self.results):
            # Only standard SDKs (Firebase/GMS) found — informational only
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-01",
                test_name="Testing for Data Exfiltration",
                category="Network", severity="Low", status="INFO",
                description=f"Standard SDK(s) found: {', '.join(set(standard_sdks))}.",
                details="Standard Google/Firebase SDKs are common in Android apps.",
                recommendation="Review data collection policies of all SDKs.",
                evidence=[f"Standard SDK: {s}" for s in set(standard_sdks)],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-1/"]
            ))

        # MSTG-NETWORK-03: Unencrypted Sensitive Data
        http_secrets = []
        for name, content in all_smali.items():
            http_urls = re.findall(r'http://[^"]+', content)
            for url in http_urls:
                if any(term in url.lower() for term in ["login", "auth", "password", "token", "api", "user"]):
                    http_secrets.append(f"{name}: {url[:100]}")
        if http_secrets and not any(r.test_id == "MSTG-NETWORK-03" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-03",
                test_name="Testing for Unencrypted Sensitive Data Transmission",
                category="Network", severity="Critical", status="FAIL",
                description=f"Found {len(http_secrets)} HTTP endpoint(s) handling sensitive data.",
                details="HTTP endpoints with sensitive data:\n" + "\n".join(http_secrets[:10]),
                recommendation="Migrate all sensitive endpoints to HTTPS.",
                evidence=http_secrets[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-3/"]
            ))

        # MSTG-NETWORK-04: Certificate Pinning
        pinning_files = []
        for name, content in all_smali.items():
            if "CertificatePinner" in content or "TrustManagerImpl" in content or "X509TrustManager" in content:
                pinning_files.append(name)
        no_pinning = not pinning_files and not any(
            "pin-set" in str(r.evidence) for r in self.results if r.test_id == "MSTG-NETWORK-04"
        )
        if pinning_files and not any(r.test_id == "MSTG-NETWORK-04" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-04",
                test_name="Testing for SSL/TLS Certificate Pinning",
                category="Network", severity="Medium", status="PASS",
                description=f"Certificate pinning detected in {len(pinning_files)} file(s).",
                details="SSL pinning implementation found.",
                recommendation="Verify pinning covers all critical endpoints.",
                evidence=[f"Pinning found in: {f}" for f in pinning_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-4/"]
            ))
        elif no_pinning:
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-04",
                test_name="Testing for SSL/TLS Certificate Pinning",
                category="Network", severity="Medium", status="WARNING",
                description="No SSL/TLS certificate pinning detected.",
                details="No CertificatePinner or TrustManagerImpl found in smali.",
                recommendation="Implement certificate pinning for critical API endpoints.",
                evidence=["No certificate pinning found in smali sources"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-4/"]
            ))

        # MSTG-NETWORK-05: Outdated TLS
        tls_usage = []
        for name, content in all_smali.items():
            if "TLSv1" in content and "TLSv1.2" not in content and "TLSv1.3" not in content:
                tls_usage.append(name)
            if "SSLv3" in content:
                tls_usage.append(f"{name} (SSLv3!)" )
        if tls_usage and not any(r.test_id == "MSTG-NETWORK-05" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-NETWORK-05",
                test_name="Testing for Outdated TLS Versions",
                category="Network", severity="High", status="WARNING",
                description=f"Potentially outdated TLS usage in {len(tls_usage)} file(s).",
                details="Files using outdated TLS:",
                recommendation="Enforce TLS 1.2+ minimum. Use strong cipher suites.",
                evidence=[f"TLS concern in: {f}" for f in tls_usage[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-NETWORK-5/"]
            ))

        # ─── PLATFORM TESTS ───────────────────────────────────
        # MSTG-PLATFORM-02: Custom URL Schemes
        url_schemes = []
        for name, content in all_smali.items():
            if "Uri.parse" in content or "getIntent().getData" in content:
                url_schemes.append(name)
        if url_schemes and not any(r.test_id == "MSTG-PLATFORM-02" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-PLATFORM-02",
                test_name="Testing for Custom URL Schemes",
                category="Platform", severity="Medium", status="WARNING",
                description=f"Custom URL scheme handling in {len(url_schemes)} file(s).",
                details="Files that parse URI data from intents.",
                recommendation="Validate all URL data. Don't pass sensitive data in URL scheme parameters.",
                evidence=[f"URL parsing in: {f}" for f in url_schemes[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-2/"]
            ))

        # MSTG-PLATFORM-03: Intent Sniffing
        implicit_intents = []
        for name, content in all_smali.items():
            if "sendBroadcast" in content or "startActivity" in content:
                if "setPackage" not in content and "setComponent" not in content:
                    implicit_intents.append(name)
        if implicit_intents and not any(r.test_id == "MSTG-PLATFORM-03" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-PLATFORM-03",
                test_name="Testing for Intent Sniffing",
                category="Platform", severity="Medium", status="WARNING",
                description=f"Found {len(implicit_intents)} file(s) with potential implicit intent usage.",
                details="Implicit intents can be intercepted by malicious apps.",
                recommendation="Use explicit intents with setComponent() for sensitive operations.",
                evidence=[f"Implicit intent in: {f}" for f in implicit_intents[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-3/"]
            ))
        elif not implicit_intents and not any(r.test_id == "MSTG-PLATFORM-03" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-PLATFORM-03",
                test_name="Testing for Intent Sniffing",
                category="Platform", severity="Medium", status="PASS",
                description="No obvious implicit intent usage found.",
                details="All broadcasts/activities appear to use explicit targeting.",
                recommendation="Continue using explicit intents for sensitive data.",
                evidence=["No implicit intents found in smali sources"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-3/"]
            ))

        # MSTG-PLATFORM-04: Tapjacking
        tapjacking = []
        for name, content in all_smali.items():
            if "filterTouchesWhenObscured" in content:
                tapjacking.append(name)
        # Check XML for tapjacking protection in layout files
        if not tapjacking and not any(r.test_id == "MSTG-PLATFORM-04" for r in self.results):
            # Likely no protection
            self.results.append(ScanResult(
                test_id="MSTG-PLATFORM-04",
                test_name="Testing for Tapjacking",
                category="Platform", severity="Medium", status="INFO",
                description="No tapjacking protection (filterTouchesWhenObscured) detected.",
                details="App may be vulnerable to overlay/tapjacking attacks on sensitive screens.",
                recommendation="Use android:filterTouchesWhenObscured='true' on sensitive views.",
                evidence=["filterTouchesWhenObscured not found in smali sources"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-PLATFORM-4/"]
            ))

        # ─── CODE QUALITY TESTS ───────────────────────────────
        # MSTG-CODE-02: Debugging Code
        # NOTE: isDebuggerConnected = ANTI-DEBUG (app detects debuggers = GOOD)
        # Debug.waitForDebugger = actual debug artifact (BAD in production)
        anti_debug_terms = ["isDebuggerConnected", "Debug.isDebuggerConnected"]
        debug_artifacts = []
        anti_debug_found = []
        real_debug_terms = ["Debug.waitForDebugger", "Debug.attachJdwpTimeout", "setTargetEmulator"]
        for name, content in all_smali.items():
            for term in anti_debug_terms:
                if term in content:
                    anti_debug_found.append(f"{term} in {name}")
            for term in real_debug_terms:
                if term in content:
                    debug_artifacts.append(f"{term} in {name}")

        if anti_debug_found and not any(r.test_id == "MSTG-CODE-02" for r in self.results):
            # App has anti-debug = GOOD
            self.results.append(ScanResult(
                test_id="MSTG-CODE-02",
                test_name="Testing for Debugging Code",
                category="Code Quality", severity="Medium", status="PASS",
                description=f"Anti-debug mechanism(s) detected in {len(anti_debug_found)} location(s).",
                details="App uses isDebuggerConnected to detect debuggers.",
                recommendation="Verify anti-debug cannot be bypassed.",
                evidence=[f"Anti-debug found: {d}" for d in anti_debug_found[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-2/"]
            ))
        elif debug_artifacts and not any(r.test_id == "MSTG-CODE-02" for r in self.results):
            # Actual debug code found = BAD
            self.results.append(ScanResult(
                test_id="MSTG-CODE-02",
                test_name="Testing for Debugging Code",
                category="Code Quality", severity="Medium", status="WARNING",
                description=f"Found {len(debug_artifacts)} debug artifact(s) that should not be in production.",
                details="Debug artifacts found:\n" + "\n".join(f"  - {d}" for d in debug_artifacts[:10]),
                recommendation="Remove all debug code. Use build variants for debug/release.",
                evidence=debug_artifacts[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-2/"]
            ))

        # MSTG-CODE-06: Input Validation
        raw_queries = []
        for name, content in all_smali.items():
            if "rawQuery" in content or "execSQL" in content:
                lines = [l.strip() for l in content.split('\n') if 'rawQuery' in l or 'execSQL' in l][:2]
                for l in lines:
                    raw_queries.append(f"{name}: {l[:100]}")
        if raw_queries and not any(r.test_id == "MSTG-CODE-06" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-CODE-06",
                test_name="Testing for Input Validation",
                category="Code Quality", severity="High", status="WARNING",
                description=f"Found {len(raw_queries)} raw SQL query(es) that may lack input validation.",
                details="Raw queries found:\n" + "\n".join(raw_queries[:10]),
                recommendation="Use parameterized queries. Validate all input.",
                evidence=raw_queries[:8],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-6/"]
            ))

        # MSTG-CODE-12: Sensitive Data in Debug Mode
        if self.apk and self.apk.get_attribute_value("application", "debuggable") == "true":
            if not any(r.test_id == "MSTG-CODE-12" for r in self.results):
                self.results.append(ScanResult(
                    test_id="MSTG-CODE-12",
                    test_name="Testing for Sensitive Data in Debug Mode",
                    category="Code Quality", severity="High", status="WARNING",
                    description="App is debuggable — sensitive data may be exposed in debug mode.",
                    details="Debug mode allows memory inspection and step-through debugging.",
                    recommendation="Set debuggable=false for release builds.",
                    evidence=["debuggable=true means all app data is accessible via debugger"],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-12/"]
                ))

        # MSTG-CODE-13: Encryption Key Management
        hardcoded_keys = []
        for name, content in all_smali.items():
            # Look for hardcoded byte arrays that might be keys
            if "SecretKeySpec" in content and ("SharedPreferences" in content or "getPreferences" in content):
                hardcoded_keys.append(name)
        if hardcoded_keys and not any(r.test_id == "MSTG-CODE-13" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-CODE-13",
                test_name="Testing for Local Encryption Keys",
                category="Code Quality", severity="High", status="WARNING",
                description=f"Potential hardcoded key usage in {len(hardcoded_keys)} file(s).",
                details="SecretKeySpec with SharedPreferences found.",
                recommendation="Use Android Keystore for key management.",
                evidence=[f"Key concern in: {f}" for f in hardcoded_keys[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-CODE-13/"]
            ))

        # ─── RESILIENCE TESTS ─────────────────────────────────
        # MSTG-RESILIENCE-01: Anti-Reverse Engineering
        proguard_files = []
        for name in zf.namelist():
            if name.endswith("proguard") or name.endswith("proguard-rules.pro") or "proguard" in name.lower():
                proguard_files.append(name)
        # Already detected obfuscation in _scan_dex_files — add if not present

        # MSTG-RESILIENCE-02: Root Detection
        root_terms = ["/system/xbin/su", "/system/bin/su", "RootBeer", "isRooted",
                     "test-keys", "/sbin/su", "SafetyNet", "PlayIntegrity"]
        root_files = []
        for name, content in all_smali.items():
            if any(term in content for term in root_terms):
                root_files.append(name)
        if root_files and not any(r.test_id == "MSTG-RESILIENCE-02" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-02",
                test_name="Testing for Root Detection Bypass",
                category="Resilience", severity="Medium", status="PASS",
                description=f"Root detection mechanism(s) found in {len(root_files)} file(s).",
                details="Root detection implementation present.",
                recommendation="Ensure root detection cannot be bypassed with Frida/Xposed.",
                evidence=[f"Root detection in: {f}" for f in root_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-2/"]
            ))
        elif not root_files and not any(r.test_id == "MSTG-RESILIENCE-02" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-02",
                test_name="Testing for Root Detection Bypass",
                category="Resilience", severity="Medium", status="WARNING",
                description="No root detection mechanism detected.",
                details="App does not appear to check for rooted devices.",
                recommendation="Implement multi-layered root detection.",
                evidence=["No root detection found in smali sources"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-2/"]
            ))

        # MSTG-RESILIENCE-03: Code Integrity Checks
        integrity_terms = ["PackageManager.GET_SIGNATURES", "Signature",
                          "checkSignature", "getPackageInfo"]
        integrity_files = []
        for name, content in all_smali.items():
            if any(term in content for term in integrity_terms):
                if "Signature" in content:
                    integrity_files.append(name)
        if integrity_files and not any(r.test_id == "MSTG-RESILIENCE-03" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-03",
                test_name="Testing for Code Integrity Checks",
                category="Resilience", severity="Medium", status="PASS",
                description=f"Signature verification found in {len(integrity_files)} file(s).",
                details="App performs signature/integrity checking.",
                recommendation="Verify integrity checks cover all critical code paths.",
                evidence=[f"Integrity check in: {f}" for f in integrity_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-3/"]
            ))

        # MSTG-RESILIENCE-04: Anti-Frida
        frida_terms = ["frida", "FRIDA", "frida-agent", "linjector",
                      "/data/local/tmp/re.frida.server"]
        frida_files = []
        for name, content in all_smali.items():
            if any(term in content for term in frida_terms):
                frida_files.append(name)
        if frida_files and not any(r.test_id == "MSTG-RESILIENCE-04" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-04",
                test_name="Testing Anti-Frida Detection",
                category="Resilience", severity="High", status="PASS",
                description=f"Anti-Frida detection found in {len(frida_files)} file(s).",
                details="App checks for Frida artifacts.",
                recommendation="Ensure anti-Frida cannot be trivially bypassed.",
                evidence=[f"Anti-Frida in: {f}" for f in frida_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-4/"]
            ))
        elif not frida_files and not any(r.test_id == "MSTG-RESILIENCE-04" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-04",
                test_name="Testing Anti-Frida Detection",
                category="Resilience", severity="High", status="WARNING",
                description="No anti-Frida detection found.",
                details="App does not appear to detect Frida hooking.",
                recommendation="Implement Frida detection and anti-tampering.",
                evidence=["No anti-Frida mechanisms found"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-4/"]
            ))

        # MSTG-RESILIENCE-05: Anti-Hooking
        hook_terms = ["ptrace", "XposedBridge", "de.robv.android.xposed",
                     "isXposedActive", "substrate"]
        hook_files = []
        for name, content in all_smali.items():
            if any(term in content for term in hook_terms):
                hook_files.append(name)
        if hook_files and not any(r.test_id == "MSTG-RESILIENCE-05" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-05",
                test_name="Testing for Anti-Hooking",
                category="Resilience", severity="High", status="PASS",
                description=f"Anti-hooking mechanism(s) found in {len(hook_files)} file(s).",
                details="App detects hooking frameworks.",
                recommendation="Ensure anti-hooking cannot be bypassed.",
                evidence=[f"Anti-hooking in: {f}" for f in hook_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-5/"]
            ))
        elif not hook_files and not frida_files and not any(r.test_id == "MSTG-RESILIENCE-05" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-05",
                test_name="Testing for Anti-Hooking",
                category="Resilience", severity="High", status="WARNING",
                description="No anti-hooking protection detected.",
                details="App does not check for Xposed/Substrate hooking frameworks.",
                recommendation="Implement anti-hooking with ptrace and framework detection.",
                evidence=["No anti-hooking mechanisms found"],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-5/"]
            ))

        # MSTG-RESILIENCE-06: Anti-Repackaging
        repack_terms = ["PackageManager.GET_SIGNING_CERTIFICATES",
                       "PackageManager.GET_SIGNATURES", "Signature[]"]
        repack_files = []
        for name, content in all_smali.items():
            if any(term in content for term in repack_terms):
                repack_files.append(name)
        if repack_files and not any(r.test_id == "MSTG-RESILIENCE-06" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-06",
                test_name="Testing for Anti-Repackaging",
                category="Resilience", severity="Medium", status="PASS",
                description=f"Signature verification found in {len(repack_files)} file(s) — may detect repackaging.",
                details="App verifies its own signature.",
                recommendation="Verify signature checks are in critical code paths.",
                evidence=[f"Signature check in: {f}" for f in repack_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-6/"]
            ))

        # MSTG-RESILIENCE-07: Anti-Tampering
        tamper_terms = ["FileIntegrityChecker", "MessageDigest", "checksum",
                       "hashcode", "verifyIntegrity"]
        tamper_files = []
        for name, content in all_smali.items():
            lower = content.lower()
            if any(term.lower() in lower for term in tamper_terms):
                tamper_files.append(name)
        if tamper_files and not any(r.test_id == "MSTG-RESILIENCE-07" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-07",
                test_name="Testing for Anti-Tampering",
                category="Resilience", severity="Medium", status="PASS",
                description=f"Integrity/tamper detection found in {len(tamper_files)} file(s).",
                details="App may verify file integrity.",
                recommendation="Ensure integrity checks cover critical application files.",
                evidence=[f"Tamper detection in: {f}" for f in tamper_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-7/"]
            ))

        # MSTG-RESILIENCE-08: Anti-Dynamic Analysis
        dyn_analysis_terms = ["Debug.isDebuggerConnected", "isDebuggerConnected",
                            "android.os.Debug", "TracerPid"]
        dyn_files = []
        for name, content in all_smali.items():
            if any(term in content for term in dyn_analysis_terms):
                dyn_files.append(name)
        if dyn_files and not any(r.test_id == "MSTG-RESILIENCE-08" for r in self.results):
            self.results.append(ScanResult(
                test_id="MSTG-RESILIENCE-08",
                test_name="Testing for Anti-Dynamic Analysis",
                category="Resilience", severity="High", status="PASS",
                description=f"Anti-debugging/dynamic analysis found in {len(dyn_files)} file(s).",
                details="App detects dynamic analysis tools.",
                recommendation="Ensure detection cannot be bypassed.",
                evidence=[f"Anti-debug in: {f}" for f in dyn_files[:5]],
                refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-8/"]
            ))
        elif not dyn_files and not any(r.test_id == "MSTG-RESILIENCE-08" for r in self.results):
            if self.apk and self.apk.get_attribute_value("application", "debuggable") == "true":
                self.results.append(ScanResult(
                    test_id="MSTG-RESILIENCE-08",
                    test_name="Testing for Anti-Dynamic Analysis",
                    category="Resilience", severity="High", status="FAIL",
                    description="No anti-dynamic analysis protection and app is debuggable.",
                    details="App is debuggable and has no dynamic analysis detection.",
                    recommendation="Implement anti-debugging and detect dynamic analysis tools.",
                    evidence=["debuggable=true with no anti-debug checks"],
                    refs=["https://mas.owasp.org/MASVS/controls/MASVS-RESILIENCE-8/"]
                ))

    # ─── Compile Report ───────────────────────────────────────────────

    def _compile_report(self, apk_path: Path) -> Dict:
        """Compile final scan report with correct severity counting."""
        apk_info = self._extract_apk_info(apk_path)

        # Count statuses
        status_counts = {"FAIL": 0, "WARNING": 0, "PASS": 0, "INFO": 0}
        for r in self.results:
            status_counts[r.status] = status_counts.get(r.status, 0) + 1

        # Do NOT inject fake PASS results for untested MASTG IDs.
        # Only results backed by real analysis are shown.

        # ── SEVERITY COUNTS: Only FAIL + WARNING ──
        issue_severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
        total_severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}

        for r in self.results:
            total_severity_counts[r.severity] = total_severity_counts.get(r.severity, 0) + 1
            if r.status in ("FAIL", "WARNING"):
                issue_severity_counts[r.severity] = issue_severity_counts.get(r.severity, 0) + 1

        # Risk score from FAIL/WARNING only
        risk_score = 0
        for r in self.results:
            if r.status == "FAIL":
                risk_score += {"Critical": 10, "High": 5, "Medium": 2, "Low": 1}.get(r.severity, 0)
            elif r.status == "WARNING":
                risk_score += {"Critical": 5, "High": 3, "Medium": 1, "Low": 1}.get(r.severity, 0)

        return {
            "platform": "Android",
            "file_info": apk_info,
            "results": [asdict(r) for r in self.results],
            "severity_counts": issue_severity_counts,  # Only FAIL/WARNING
            "total_severity_counts": total_severity_counts,  # All tests
            "status_counts": status_counts,
            "risk_score": risk_score,
            "risk_level": "Critical" if risk_score > 50 else "High" if risk_score > 25 else "Medium" if risk_score > 10 else "Low",
            "detections": self.detections,
            "total_tests": len(self.results),
        }

    def _extract_apk_info(self, apk_path: Path) -> Dict:
        """Extract APK info using androguard, falling back to basic extraction."""
        info = {
            "file_name": apk_path.name,
            "file_size": apk_path.stat().st_size,
            "file_hash": hashlib.sha256(apk_path.read_bytes()).hexdigest(),
        }

        if self.apk:
            try:
                info["package_name"] = self.apk.get_package() or "Unknown"
                info["version_name"] = self.apk.get_androidversion_name() or "Unknown"
                info["version_code"] = str(self.apk.get_androidversion_code() or "Unknown")
                info["app_name"] = self.apk.get_app_name() or apk_path.stem
                info["min_sdk"] = str(self.apk.get_min_sdk_version() or "Unknown")
                info["target_sdk"] = str(self.apk.get_target_sdk_version() or "Unknown")
                info["permissions"] = self.apk.get_permissions()
                info["main_activity"] = self.apk.get_main_activity() or "Unknown"
                info["debuggable"] = self.apk.get_attribute_value("application", "debuggable") == "true"

                activities = list(self.apk.get_activities())
                info["activities"] = activities[:50]
                info["services"] = self.apk.get_services()[:20]
                info["receivers"] = self.apk.get_receivers()[:20]
                info["providers"] = self.apk.get_providers()[:20]

                return info
            except Exception as e:
                info["androguard_error"] = str(e)

        # Fallback
        try:
            with zipfile.ZipFile(apk_path) as zf:
                manifest = zf.read("AndroidManifest.xml")
                text = manifest.decode("latin-1", errors="ignore")
                strings = re.findall(r'[a-zA-Z][a-zA-Z0-9_.]{5,60}', text)
                for s in strings:
                    if '.' in s and not s.startswith('android.') and not s.startswith('java.'):
                        if "package_name" not in info:
                            info["package_name"] = s
                            break

                info["app_name"] = apk_path.stem
                info["version_name"] = "Unknown"
                info["version_code"] = "Unknown"
                info["min_sdk"] = "Unknown"
                info["target_sdk"] = "Unknown"
        except Exception:
            pass

        return info
