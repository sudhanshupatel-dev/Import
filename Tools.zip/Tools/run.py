"""
MobiScan - Start the OWASP MASTG Scanner
Run this script to start the web server
"""
import sys
import os

# Fix encoding on Windows when output is redirected
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Ensure we're in the right directory
os.chdir(os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    import uvicorn

    host = os.environ.get("MOBISCAN_HOST", "0.0.0.0")
    port = int(os.environ.get("MOBISCAN_PORT", "8000"))

    print(f"""
=== MobiScan - OWASP MASTG Mobile Security Scanner ===

  Starting on: http://{host}:{port}

  Features:
  - OWASP MASTG Static Analysis (Android & iOS)
  - Auto-generated Frida Scripts
  - App Version Comparison
  - Activity/Screen Diff Analysis
  - PSS ID & Test Owner Tracking

  Access from your network at: http://<YOUR-IP>:{port}

========================================================
""")

    uvicorn.run(
        "app:app",
        host=host,
        port=port,
        reload=False,
        log_level="info",
    )
