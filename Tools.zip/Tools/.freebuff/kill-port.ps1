$ErrorActionPreference = "SilentlyContinue"
Get-NetTCPConnection -LocalPort 8000 | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
Start-Sleep -Seconds 2
Write-Host "Port 8000 cleared"
