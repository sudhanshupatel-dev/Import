## How to reproduce artifacts

No build step needed — pure Python.

1. Install dependencies (once):
   ```
   pip install fastapi uvicorn python-multipart aiofiles jinja2 peewee pydantic pyyaml lxml markdown rich httpx androguard
   ```

## How to run the server

```
python run.py
```

This starts uvicorn on `http://0.0.0.0:8000`. Other machines on the network access it at `http://<YOUR-IP>:8000`.

To use a different port:
```
set MOBISCAN_PORT=9000
python run.py
```

## Current server state

- **PID**: 8416 (started 2026-08-21)
- **Port**: 8000
- **Database**: `uploads/codehunter.db` (has existing scan data)
