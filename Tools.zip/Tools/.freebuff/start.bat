@echo off
cd /d C:\Users\Windows\Downloads\Tools
python -m uvicorn app:app --host 127.0.0.1 --port 8000
