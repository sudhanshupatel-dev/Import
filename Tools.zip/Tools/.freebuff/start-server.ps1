Set-Location "C:\Users\Windows\Downloads\Tools"
$p = Start-Process -FilePath "python.exe" -ArgumentList "-m","uvicorn","app:app","--host","127.0.0.1","--port","8000" -RedirectStandardOutput "C:\Users\Windows\Downloads\Tools\.freebuff\preview-86060ef3-2f75-42f7-85df-421a50340ba8.log" -RedirectStandardError "C:\Users\Windows\Downloads\Tools\.freebuff\preview-86060ef3-2f75-42f7-85df-421a50340ba8.log.err" -WindowStyle Hidden -PassThru
Write-Output $p.Id
