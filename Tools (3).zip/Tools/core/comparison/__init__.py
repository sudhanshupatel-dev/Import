"""
App Comparison Module
Compares two versions of the same app and generates diff reports
"""
import json
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict


@dataclass
class TestDiff:
    test_id: str
    test_name: str
    category: str
    status_a: str
    status_b: str
    change: str  # "improved", "regressed", "unchanged", "new", "removed"
    severity: str


class AppComparator:
    """Compare two scan results of the same app."""

    def compare(self, scan_a: Dict, scan_b: Dict) -> Dict:
        """Compare two scan reports and generate a diff."""
        results_a = {r["test_id"]: r for r in scan_a.get("results", [])}
        results_b = {r["test_id"]: r for r in scan_b.get("results", [])}

        all_test_ids = set(results_a.keys()) | set(results_b.keys())
        diffs = []

        for test_id in sorted(all_test_ids):
            ra = results_a.get(test_id)
            rb = results_b.get(test_id)

            if ra and rb:
                # Both versions have this test
                change = "unchanged"
                if ra["status"] != rb["status"]:
                    # Determine if it improved or regressed
                    severity_order = {"FAIL": 0, "WARNING": 1, "PASS": 2, "INFO": 3}
                    a_score = severity_order.get(ra["status"], 1)
                    b_score = severity_order.get(rb["status"], 1)
                    if b_score > a_score:
                        change = "improved"
                    else:
                        change = "regressed"

                diffs.append(TestDiff(
                    test_id=test_id,
                    test_name=ra["test_name"],
                    category=ra["category"],
                    status_a=ra["status"],
                    status_b=rb["status"],
                    change=change,
                    severity=ra["severity"],
                ))
            elif ra:
                diffs.append(TestDiff(
                    test_id=test_id,
                    test_name=ra["test_name"],
                    category=ra["category"],
                    status_a=ra["status"],
                    status_b="N/A",
                    change="removed",
                    severity=ra["severity"],
                ))
            elif rb:
                diffs.append(TestDiff(
                    test_id=test_id,
                    test_name=rb["test_name"],
                    category=rb["category"],
                    status_a="N/A",
                    status_b=rb["status"],
                    change="new",
                    severity=rb["severity"],
                ))

        # Calculate comparison summary
        improved = sum(1 for d in diffs if d.change == "improved")
        regressed = sum(1 for d in diffs if d.change == "regressed")
        unchanged = sum(1 for d in diffs if d.change == "unchanged")

        # Risk score comparison
        risk_a = scan_a.get("risk_score", 0)
        risk_b = scan_b.get("risk_score", 0)
        risk_change = risk_b - risk_a

        return {
            "scan_a": {
                "id": scan_a.get("file_info", {}).get("file_name", "Unknown"),
                "version": scan_a.get("file_info", {}).get("version_name",
                         scan_a.get("file_info", {}).get("version", "Unknown")),
                "risk_score": risk_a,
                "risk_level": scan_a.get("risk_level", "Unknown"),
            },
            "scan_b": {
                "id": scan_b.get("file_info", {}).get("file_name", "Unknown"),
                "version": scan_b.get("file_info", {}).get("version_name",
                         scan_b.get("file_info", {}).get("version", "Unknown")),
                "risk_score": risk_b,
                "risk_level": scan_b.get("risk_level", "Unknown"),
            },
            "diffs": [asdict(d) for d in diffs],
            "summary": {
                "total_tests": len(diffs),
                "improved": improved,
                "regressed": regressed,
                "unchanged": unchanged,
                "new": sum(1 for d in diffs if d.change == "new"),
                "removed": sum(1 for d in diffs if d.change == "removed"),
                "risk_change": risk_change,
                "risk_trend": "improved" if risk_change < 0 else "regressed" if risk_change > 0 else "unchanged",
            }
        }

    def compare_activities(self, scan_a: Dict, scan_b: Dict) -> Dict:
        """Compare exported activities/screens between two versions."""
        activities_a = set()
        activities_b = set()

        for r in scan_a.get("results", []):
            details = r.get("details", "")
            evidence = r.get("evidence", [])
            for line in details.split("\n"):
                line = line.strip()
                if line.startswith("Activity:") or line.startswith("  - Activity:"):
                    name = line.replace("  - ", "").replace("Activity: ", "").strip()
                    if name:
                        activities_a.add(name)
            for ev in evidence:
                ev_str = str(ev)
                if "Activity:" in ev_str:
                    name = ev_str.split("Activity:")[-1].strip()
                    if name:
                        activities_a.add(name)

        for r in scan_b.get("results", []):
            details = r.get("details", "")
            evidence = r.get("evidence", [])
            for line in details.split("\n"):
                line = line.strip()
                if line.startswith("Activity:") or line.startswith("  - Activity:"):
                    name = line.replace("  - ", "").replace("Activity: ", "").strip()
                    if name:
                        activities_b.add(name)
            for ev in evidence:
                ev_str = str(ev)
                if "Activity:" in ev_str:
                    name = ev_str.split("Activity:")[-1].strip()
                    if name:
                        activities_b.add(name)

        added = activities_b - activities_a
        removed = activities_a - activities_b

        return {
            "version_a": scan_a.get("file_info", {}).get("version_name", "Unknown"),
            "version_b": scan_b.get("file_info", {}).get("version_name", "Unknown"),
            "total_a": len(activities_a),
            "total_b": len(activities_b),
            "added": sorted(added),
            "removed": sorted(removed),
            "common": sorted(activities_a & activities_b),
            "added_count": len(added),
            "removed_count": len(removed),
        }

    def _extract_components(self, scan_data: Dict) -> Dict[str, set]:
        """Extract all component types, permissions, deep links, and UI elements from scan results."""
        components = {
            "activities": set(),
            "services": set(),
            "receivers": set(),
            "providers": set(),
            "permissions": set(),
            "dangerous_permissions": set(),
            "deep_links": set(),
            "url_schemes": set(),
            "intent_filters": set(),
            "exported_components": set(),
            "native_libs": set(),
            "urls_endpoints": set(),
            "buttons_ui": set(),
            "shared_prefs_keys": set(),
            "classes_with_webview": set(),
            "security_libs": set(),
        }

        file_info = scan_data.get("file_info", {})

        # Extract from file_info (package metadata)
        all_activities = file_info.get("all_activities", [])
        all_services = file_info.get("all_services", [])
        all_receivers = file_info.get("all_receivers", [])
        all_providers = file_info.get("all_providers", [])
        all_permissions = file_info.get("all_permissions", [])
        deeplinks = file_info.get("deeplinks", [])
        url_schemes = file_info.get("url_schemes", [])
        exported = file_info.get("exported_components", [])

        for a in all_activities:
            components["activities"].add(a)
        for s in all_services:
            components["services"].add(s)
        for r in all_receivers:
            components["receivers"].add(r)
        for p in all_providers:
            components["providers"].add(p)
        for p in all_permissions:
            components["permissions"].add(p)
        for d in deeplinks:
            components["deep_links"].add(d)
        for u in url_schemes:
            components["url_schemes"].add(u)
        for e in exported:
            components["exported_components"].add(e)

        # Extract from scan results evidence and details
        for r in scan_data.get("results", []):
            details = r.get("details", "")
            evidence = r.get("evidence", [])
            test_name = r.get("test_name", "")

            all_text = details + " " + " ".join(str(e) for e in evidence)

            # Extract components from evidence lines
            for ev in evidence:
                ev_str = str(ev)
                if "Activity:" in ev_str:
                    name = ev_str.split("Activity:")[-1].strip()
                    if name:
                        components["activities"].add(name)
                        if "Exported" in ev_str:
                            components["exported_components"].add(f"Activity: {name}")
                elif "Service:" in ev_str:
                    name = ev_str.split("Service:")[-1].strip()
                    if name:
                        components["services"].add(name)
                        if "Exported" in ev_str:
                            components["exported_components"].add(f"Service: {name}")
                elif "Receiver:" in ev_str:
                    name = ev_str.split("Receiver:")[-1].strip()
                    if name:
                        components["receivers"].add(name)
                        if "Exported" in ev_str:
                            components["exported_components"].add(f"Receiver: {name}")

            # Extract permissions
            for ev in evidence:
                ev_str = str(ev)
                if "android.permission." in ev_str:
                    perm = ev_str.strip()
                    if not perm.startswith("android.permission."):
                        idx = perm.find("android.permission.")
                        perm = perm[idx:]
                    components["permissions"].add(perm)

            # Extract deep links / URL schemes from details
            import re
            if "Deep Link" in test_name or "URL" in test_name or "Scheme" in test_name or "Intent" in test_name:
                urls = re.findall(r'https?://[\w.\-/:]+', all_text)
                for u in urls:
                    components["urls_endpoints"].add(u)
                schemes = re.findall(r'([a-z][a-z0-9+.-]+://[\w.\-/:]*)', all_text)
                for s in schemes:
                    components["url_schemes"].add(s)
                intents = re.findall(r'android:scheme="([^"]+)"', all_text)
                for i in intents:
                    components["url_schemes"].add(f"{i}://")

            # Extract native libraries
            if "native" in test_name.lower() or "JNI" in test_name:
                libs = re.findall(r'(lib/[\w\-]+/lib[\w\-]+\.so)', all_text)
                for lib in libs:
                    components["native_libs"].add(lib)

            # Extract security libraries
            if "Security library" in all_text or "Anti-Frida" in all_text or "Root detection" in all_text:
                sec_libs = re.findall(r'(lib/[\w\-]+/lib[\w\-]+\.so)', all_text)
                for lib in sec_libs:
                    components["security_libs"].add(lib)

            # Extract SharedPreferences keys
            if "SharedPreferences" in all_text:
                keys = re.findall(r'getSharedPreferences|SharedPreferencesImpl|SharedPref', all_text)
                if keys:
                    components["shared_prefs_keys"].add(f"Used in: {r.get('test_id', 'unknown')}")

            # Extract WebView usage
            if "WebView" in all_text or "webview" in all_text:
                wv_classes = set(re.findall(r'([\w.]+)\.loadUrl|([\w.]+)\.addJavascriptInterface', all_text))
                for w in wv_classes:
                    if w:
                        components["classes_with_webview"].add(w)

            # Extract buttons/UI elements from strings
            if "Button" in all_text or "onClick" in all_text:
                btns = re.findall(r'android:text="([^"]+)"|text_btn|button_label', all_text)
                for b in btns:
                    if b and len(b) > 1:
                        components["buttons_ui"].add(b)

        return components

    def compare_components(self, scan_a: Dict, scan_b: Dict) -> Dict:
        """Full component comparison: activities, services, receivers, providers, permissions, deep links, UI elements."""
        comp_a = self._extract_components(scan_a)
        comp_b = self._extract_components(scan_b)

        result = {}
        for key in comp_a:
            added = comp_b[key] - comp_a[key]
            removed = comp_a[key] - comp_b[key]
            common = comp_a[key] & comp_b[key]
            result[key] = {
                "added": sorted(added),
                "removed": sorted(removed),
                "common": sorted(common),
                "added_count": len(added),
                "removed_count": len(removed),
                "total_a": len(comp_a[key]),
                "total_b": len(comp_b[key]),
            }

        # Also extract permissions that are dangerous
        dangerous_perms_a = set()
        dangerous_perms_b = set()
        DANGEROUS = {
            "android.permission.READ_SMS", "android.permission.SEND_SMS",
            "android.permission.READ_CONTACTS", "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO", "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION", "android.permission.READ_PHONE_STATE",
            "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.CALL_PHONE", "android.permission.READ_CALL_LOG",
            "android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR",
            "android.permission.BODY_SENSORS", "android.permission.POST_NOTIFICATIONS",
        }
        for p in comp_a["permissions"]:
            if p in DANGEROUS:
                dangerous_perms_a.add(p)
        for p in comp_b["permissions"]:
            if p in DANGEROUS:
                dangerous_perms_b.add(p)

        result["dangerous_permissions"] = {
            "added": sorted(dangerous_perms_b - dangerous_perms_a),
            "removed": sorted(dangerous_perms_a - dangerous_perms_b),
            "added_count": len(dangerous_perms_b - dangerous_perms_a),
            "removed_count": len(dangerous_perms_a - dangerous_perms_b),
        }

        # Summary
        total_added = sum(v["added_count"] for v in result.values() if isinstance(v, dict) and "added_count" in v)
        total_removed = sum(v["removed_count"] for v in result.values() if isinstance(v, dict) and "removed_count" in v)
        result["summary"] = {
            "total_added": total_added,
            "total_removed": total_removed,
            "has_new_screens": result.get("activities", {}).get("added_count", 0) > 0,
            "has_new_services": result.get("services", {}).get("added_count", 0) > 0,
            "has_new_receivers": result.get("receivers", {}).get("added_count", 0) > 0,
            "has_new_permissions": result.get("permissions", {}).get("added_count", 0) > 0,
            "has_new_deep_links": result.get("deep_links", {}).get("added_count", 0) > 0 or result.get("url_schemes", {}).get("added_count", 0) > 0,
            "has_new_exported": result.get("exported_components", {}).get("added_count", 0) > 0,
            "has_new_ui": result.get("buttons_ui", {}).get("added_count", 0) > 0,
        }

        return result
